<?php 

//Template Name: Home Blog One

if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

get_header();

$blog_sidebar = paprika_option('blog-sidebar', false, 'right-sidebar');
	$grid_column = 'col-md-12';
	
	if ($blog_sidebar == 'right-sidebar') :
		$grid_column = (is_active_sidebar('paprika-blog-sidebar')) ? 'col-md-8 col-sm-8' : $grid_column;
	elseif ($blog_sidebar == 'left-sidebar') :
		$grid_column = (is_active_sidebar('paprika-blog-sidebar')) ? 'col-md-8 col-md-push-4 col-sm-8 col-sm-push-4' : $grid_column;
	endif;
?>

<?php get_template_part('template-parts/slider'); ?>

<?php 
	if( paprika_option('promo-visibility', false, true) ) :
		get_template_part('template-parts/promo'); 
	endif;	
?>

<?php 

	$paged = ( get_query_var( 'paged' ) ) ? absint( get_query_var( 'paged' ) ) : 1;
	$args = array(
		'post_type' => 'post',
		'get' => 'posts_per_page',
		'paged' => $paged
	);
	$wp_query = new WP_Query($args);
?>
<div class="blog-wrapper">
	<div class="container">
		<div class="row">
			<div class="<?php echo esc_attr($grid_column); ?>">
				<div id="main" class="posts-content" role="main">
					<?php if ( $wp_query -> have_posts() ) : 
						$count = 1;
					?>

						<?php /* Start the Loop */ ?>
						<?php while ( $wp_query -> have_posts() ) : $wp_query -> the_post(); ?>

							<?php
							/*
                             * Include the Post-Format-specific template for the content.
                             * If you want to override this in a child theme, then include a file
                             * called content-___.php (where ___ is the Post Format name) and that will be used instead.
                             */
							get_template_part( 'template-parts/content', get_post_format() );?>
							
							<?php /* Post Top Ad */ ?>
							<?php if ($count == paprika_option('pt-ad-position')): ?>
								
								<div class="advertise-section">
									<?php paprika_ads('post-top-ad');?>
								</div>
								
							<?php endif; ?>
							
							<?php /* Post Middle Ad */ ?>
							<?php if ( ($count == paprika_option('pm-ad-position')) and (paprika_option('pm-ad-visibility') == 1) ): ?>
								
								<div class="advertise-section">
									<?php paprika_ads('post-middle-ad');?>
								</div>
								
							<?php endif; ?>
							
							<?php /* Post Bottom Ad */ ?>
							<?php if ( ($count == paprika_option('pb-ad-position')) and (paprika_option('pb-ad-visibility') == 1) ): ?>
								
								<div class="advertise-section">
									<?php paprika_ads('post-bottom-ad');?>
								</div>
								
							<?php endif; ?>
							
						<?php 
						$count++;
						endwhile; ?>

						<?php 
							paprika_posts_pagination();
						?>
						
						<?php wp_reset_postdata(); ?>

					<?php else : ?>

						<?php get_template_part( 'template-parts/content', 'none' ); ?>

					<?php endif; ?>
				</div><!-- .posts-content -->
			</div> <!-- .col-## -->

			<!-- Sidebar -->
			<?php get_sidebar(); ?>

		</div> <!-- .row -->
	</div><!-- .container -->
</div> <!-- .blog-wrapper -->

<?php get_template_part('template-parts/instagram-feed'); ?>

<?php get_footer(); ?>