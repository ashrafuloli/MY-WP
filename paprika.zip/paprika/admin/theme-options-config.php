<?php

    if ( ! defined( 'ABSPATH' ) ) :
        exit; // Exit if accessed directly
    endif;

    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // ReduxFramework  Config File
    // For full documentation, please visit: https://docs.reduxframework.com
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // This is your option name where all the Redux data is stored.
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

    $opt_name = "paprika_theme_option";

    /**
     * SET ARGUMENTS
     * All the possible arguments for Redux.
     * For full documentation on arguments, please refer to: https://github.com/ReduxFramework/ReduxFramework/wiki/Arguments
     * */

    $theme = wp_get_theme(); // For use with some settings. Not necessary.

    $args = array(
        // TYPICAL -> Change these values as you need/desire
        'opt_name'             => $opt_name,
        // This is where your data is stored in the database and also becomes your global variable name.
        'display_name'         => $theme->get( 'Name' ),
        // Name that appears at the top of your panel
        'display_version'      => $theme->get( 'Version' ),
        // Version that appears at the top of your panel
        'menu_type'            => 'menu',
        //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
        'allow_sub_menu'       => TRUE,
        // Show the sections below the admin menu item or not
        'menu_title'           => sprintf( esc_html__( '%s Options', 'paprika' ), $theme->get( 'Name' ) ),
        'page_title'           => sprintf( esc_html__( '%s Theme Options', 'paprika' ), $theme->get( 'Name' ) ),
        // You will need to generate a Google API key to use this feature.
        // Please visit: https://developers.google.com/fonts/docs/developer_api#Auth
        'google_api_key'       => '',
        // Set it you want google fonts to update weekly. A google_api_key value is required.
        'google_update_weekly' => FALSE,
        // Must be defined to add google fonts to the typography module
        'async_typography'     => TRUE,
        // Use a asynchronous font on the front end or font string
        //'disable_google_fonts_link' => true,                    // Disable this in case you want to create your own google fonts loader
        'admin_bar'            => TRUE,
        // Show the panel pages on the admin bar
        'admin_bar_icon'       => 'dashicons-admin-generic',
        // Choose an icon for the admin bar menu
        'admin_bar_priority'   => 50,
        // Choose an priority for the admin bar menu
        'global_variable'      => '',
        // Set a different name for your global variable other than the opt_name
        'dev_mode'             => FALSE,
        // Show the time the page took to load, etc
        'update_notice'        => TRUE,
        // If dev_mode is enabled, will notify developer of updated versions available in the GitHub Repo
        'customizer'           => TRUE,
        // Enable basic customizer support
        //'open_expanded'     => true,                    // Allow you to start the panel in an expanded way initially.
        //'disable_save_warn' => true,                    // Disable the save warning when a user changes a field

        // OPTIONAL -> Give you extra features
        'page_priority'        => '40',
        // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
        'page_parent'          => 'themes.php',
        // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
        'page_permissions'     => 'manage_options',
        // Permissions needed to access the options panel.
        'menu_icon'            => '',
        // Specify a custom URL to an icon
        'last_tab'             => '',
        // Force your panel to always open to a specific tab (by id)
        'page_icon'            => 'icon-themes',
        // Icon displayed in the admin panel next to your menu_title
        'page_slug'            => '',
        // Page slug used to denote the panel, will be based off page title then menu title then opt_name if not provided
        'save_defaults'        => TRUE,
        // On load save the defaults to DB before user clicks save or not
        'default_show'         => FALSE,
        // If true, shows the default value next to each field that is not the default value.
        'default_mark'         => '',
        // What to print by the field's title if the value shown is default. Suggested: *
        'show_import_export'   => TRUE,
        // Shows the Import/Export panel when not used as a field.

        // CAREFUL -> These options are for advanced use only
        'transient_time'       => 60 * MINUTE_IN_SECONDS,
        'output'               => TRUE,
        // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
        'output_tag'           => TRUE,
        // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
        'footer_credit'        => sprintf( esc_html__( '%s Theme Options', 'paprika' ), $theme->get( 'Name' ) ),
        // Disable the footer credit of Redux. Please leave if you can help it.

        // FUTURE -> Not in use yet, but reserved or partially implemented. Use at your own risk.
        'database'             => '',
        // possible: options, theme_mods, theme_mods_expanded, transient. Not fully functional, warning!
        'use_cdn'              => TRUE,
        // If you prefer not to use the CDN for Select2, Ace Editor, and others, you may download the Redux Vendor Support plugin yourself and run locally or embed it in your code.

        // HINTS
        'hints'                => array(
            'icon'          => 'el el-question-sign',
            'icon_position' => 'right',
            'icon_color'    => 'lightgray',
            'icon_size'     => 'normal',
            'tip_style'     => array(
                'color'   => 'red',
                'shadow'  => TRUE,
                'rounded' => FALSE,
                'style'   => '',
            ),
            'tip_position'  => array(
                'my' => 'top left',
                'at' => 'bottom right',
            ),
            'tip_effect'    => array(
                'show' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'mouseover',
                ),
                'hide' => array(
                    'effect'   => 'slide',
                    'duration' => '500',
                    'event'    => 'click mouseleave',
                ),
            ),
        )
    );

    Redux::setArgs( $opt_name, $args );

    /*
    * ---> END ARGUMENTS
    */


    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // START SECTIONS
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Logo settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-slideshare',
        'title'  => esc_html__('Logo Settings', 'paprika'),
        'fields' => array(
            array(
                'id'       => 'logo-type',
                'type'     => 'switch',
                'title'    => esc_html__('Logo Type', 'paprika'),
                'subtitle' => esc_html__('You can set text or image logo', 'paprika'),
                'on'       => esc_html__('Image Logo', 'paprika'),
                'off'      => esc_html__('Text Logo', 'paprika'),
                'default'  => TRUE,
            ),
            array(
                'id'       => 'text-logo',
                'type'     => 'text',
                'required' => array('logo-type', '=', '0'),
                'title'    => esc_html__('Logo Text', 'paprika'),
                'subtitle' => esc_html__('Change your logo text', 'paprika')
            ),
            array(
                'id'       => 'logo',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('logo-type', '=', '1'),
                'title'    => esc_html__('Site Logo.', 'paprika'),
                'subtitle' => esc_html__('Change Site logo dimension: 145px &times; 55px', 'paprika')
            ),
            array(
                'id'       => 'retina-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('logo-type', '=', '1'),
                'title'    => esc_html__('Retina Logo Image (High Density)', 'paprika'),
                'subtitle' => esc_html__('Change Retina logo dimension: 290px &times; 110px', 'paprika'),
                'desc'     => esc_html__('Add a 290px &times; 110px pixels image that will be used as the logo in the header section. For the Retina Logo Image the even number of pixels is less important because it will be hardly noticable', 'paprika'),
            ),
            array(
                'id'       => 'mobile-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('logo-type', '=', '1'),
                'title'    => esc_html__('Site Mobile Logo.', 'paprika'),
                'subtitle' => esc_html__('Change site mobile logo dimension: 145px &times; 55px', 'paprika')
            ),
            array(
                'id'       => 'retina-mobile-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('logo-type', '=', '1'),
                'title'    => esc_html__('Retina Mobile Logo Image (High Density)', 'paprika'),
                'subtitle' => esc_html__('Change retina mobile logo dimension: 290px &times; 110px', 'paprika'),
                'desc'     => esc_html__('Add a 290px &times; 110px pixels image that will be used as the logo in the header section. For the Retina Logo Image the even number of pixels is less important because it will be hardly noticable', 'paprika'),
            ),
            array(
                'id'       => 'sticky-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('logo-type', '=', '1'),
                'title'    => esc_html__('Site Sticky Logo.', 'paprika'),
                'subtitle' => esc_html__('Change site sticky logo dimension: 145px &times; 55px', 'paprika')
            ),
            array(
                'id'       => 'retina-sticky-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('logo-type', '=', '1'),
                'title'    => esc_html__('Retina Sticky Logo Image (High Density)', 'paprika'),
                'subtitle' => esc_html__('Change retina sticky logo dimension: 290px &times; 110px', 'paprika'),
                'desc'     => esc_html__('Add a 290px &times; 110px pixels image that will be used as the logo in the header section. For the Retina Logo Image the even number of pixels is less important because it will be hardly noticable', 'paprika'),
            ),
            array(
                'id'       => 'sticky-mobile-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('logo-type', '=', '1'),
                'title'    => esc_html__('Site Sticky Mobile Logo.', 'paprika'),
                'subtitle' => esc_html__('Change site sticky mobile logo dimension: 145px &times; 55px', 'paprika')
            ),
            array(
                'id'       => 'retina-sticky-mobile-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array('logo-type', '=', '1'),
                'title'    => esc_html__('Retina Sticky Mobile Logo Image (High Density)', 'paprika'),
                'subtitle' => esc_html__('Change retina sticky mobile logo dimension: 290px &times; 110px', 'paprika'),
                'desc'     => esc_html__('Add a 290px &times; 110px pixels image that will be used as the logo in the header section. For the Retina Logo Image the even number of pixels is less important because it will be hardly noticable', 'paprika'),
            ),
            array(
                'id'             => 'logo-margin',
                'type'           => 'spacing',
                'output'         => array('.is-sticky span.site-text-logo'),
                'mode'           => 'margin',
                'units'          => array('px', 'em'),
                'units_extended' => 'false',
                'title'          => esc_html__('Logo Margin Option', 'paprika'),
                'subtitle'       => esc_html__('You can change logo margin if needed.', 'paprika'),
                'desc'           => esc_html__('Change top, right, bottom and left value in px, e.g: 10', 'paprika'),  
            )
        )
    ));

    // Header settings
    Redux::setSection( $opt_name, array(
        'icon'   => 'el el-website',
        'title'  => esc_html__( 'Header Settings', 'paprika' ),
        'fields' => array(
            array(
                'id'             => 'navbar-margin',
                'type'           => 'spacing',
                'output'         => array('.main-menu-wrapper'),
                'mode'           => 'padding',
                'units'          => 'px',
                'units_extended' => 'false',
                'title'          => esc_html__('Main menu margin option', 'paprika'),
                'subtitle'       => esc_html__('You can change main menu margin if needed.', 'paprika'),
                'desc'           => esc_html__('Change top, right, bottom and left value in px, e.g: 10', 'paprika')
            ),
            // menu background color
            array(
                'id'       => 'menu-bg-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Menu background color', 'paprika' ),
                'subtitle' => esc_html__( 'Pick color for menu background.', 'paprika' )
            ),

            // menu color
            array(
                'id'       => 'menu-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Menu font color', 'paprika' ),
                'subtitle' => esc_html__( 'Pick color for menu.', 'paprika' )
            ),
            // menu hover color
            array(
                'id'       => 'menu-hover-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Menu hover and active color', 'paprika' ),
                'subtitle' => esc_html__( 'Pick color for menu hover.', 'paprika' )
            ),
            // mobile menu background color
            array(
                'id'       => 'mobile-menu-bg-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Mobile menu background color', 'paprika' ),
                'subtitle' => esc_html__( 'Pick color for mobile menu background.', 'paprika' )
            ),
            // mobile menu color
            array(
                'id'       => 'mobile-menu-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Mobile menu font color', 'paprika' ),
                'subtitle' => esc_html__( 'Pick color for mobile menu.', 'paprika' )
            ),
            // mobile menu hover color
            array(
                'id'       => 'mobile-menu-hover-color',
                'type'     => 'color',
                'title'    => esc_html__( 'Mobile menu hover color', 'paprika' ),
                'subtitle' => esc_html__( 'Pick color for mobile menu hover.', 'paprika' )
            ),
            // sticky menu visibility
            array(
                'id'       => 'sticky-menu-visibility',
                'type'     => 'switch',
                'title'    => esc_html__('Sticky menu visibility', 'paprika'),
                'subtitle' => esc_html__('Visible or Hidden sticky menu', 'paprika'),
                'on'       => esc_html__('Visible', 'paprika'),
                'off'      => esc_html__('Hidden', 'paprika'),
                'default'  => TRUE,
            ),
            // sticky menu background color
            array(
                'id'       => 'sticky-menu-bg-color',
                'type'     => 'color',
                'required' => array('sticky-menu-visibility', '=', '1'),
                'title'    => esc_html__( 'Sticky menu background color', 'paprika' ),
                'subtitle' => esc_html__( 'Pick color for sticky menu background.', 'paprika' )
            ),
            // sticky menu color
            array(
                'id'       => 'sticky-menu-color',
                'type'     => 'color',
                'required' => array('sticky-menu-visibility', '=', '1'),
                'title'    => esc_html__( 'Sticky menu font color', 'paprika' ),
                'subtitle' => esc_html__( 'Pick color for sticky menu.', 'paprika' )
            ),
            // sticky menu color
            array(
                'id'       => 'sticky-menu-hover-color',
                'type'     => 'color',
                'required' => array('sticky-menu-visibility', '=', '1'),
                'title'    => esc_html__( 'Sticky menu hover and active color', 'paprika' ),
                'subtitle' => esc_html__( 'Pick color for sticky menu.', 'paprika' )
            ),
            // header search visibility
            array(
                'id'       => 'search-visibility',
                'type'     => 'switch',
                'title'    => esc_html__('Search visibility', 'paprika'),
                'subtitle' => esc_html__('Visible or Hidden search button', 'paprika'),
                'on'       => esc_html__('Visible', 'paprika'),
                'off'      => esc_html__('Hidden', 'paprika'),
                'default'  => TRUE,
            ),
            // header top wrapper
            array(
                'id'       => 'header-top-visibility',
                'type'     => 'switch',
                'title'    => esc_html__('Header topbar visibility', 'paprika'),
                'subtitle' => esc_html__('Visible or Hidden header topbar', 'paprika'),
                'on'       => esc_html__('Visible', 'paprika'),
                'off'      => esc_html__('Hidden', 'paprika'),
                'default'  => FALSE,
            ),
            // header social button
            array(
                'id'       => 'header-social-button',
                'type'     => 'switch',
                'required' => array('header-top-visibility', '=', '1'),
                'title'    => esc_html__('Header social button visibility', 'paprika'),
                'subtitle' => esc_html__('Visible or Hidden header social button', 'paprika'),
                'on'       => esc_html__('Visible', 'paprika'),
                'off'      => esc_html__('Hidden', 'paprika'),
                'default'  => TRUE,
            )
        )
    ));

    
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Presets settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-brush',
        'title'  => esc_html__('Preset color', 'paprika'),
        'fields' => array(
            
            array(
                'id'       => 'accent-color',
                'type'     => 'color',
                'title'    => __( 'Site Accent Color', 'paprika' ),
                'subtitle' => __( 'Pick color for the theme accent color (default: #003754).', 'paprika' ),
                'default'  => '#003754',
            ),

            array(
                'id'       => 'link-color',
                'type'     => 'color',
                'title'    => __( 'Site Link Color', 'paprika' ),
                'subtitle' => __( 'Pick color for all link (default: #003754).', 'paprika' ),
                'default'  => '#003754',
            )

        )
    ));



    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Typography
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-font',
        'title'  => esc_html__('Typography', 'paprika'),
        'fields' => array(
            
            // body typography
            array(
                'id'       => 'body-typography',
                'type'     => 'typography',
                'title'    => __( 'Body Font', 'paprika' ),
                'subtitle' => __( 'Specify the body font properties.', 'paprika' ),
                'google'   => true,
                'all_styles' => true,
                'text-align' => false,
                'default'  => array(
                    'color'       => '#999999',
                    'font-size'   => '16px',
                    'font-family' => 'Lato',
                    'font-weight' => '400',
                    'line-height' => '24px',
                ),
            ),

            // menu typography
            array(
                'id'       => 'menu-typography',
                'type'     => 'typography',
                'title'    => __( 'Menu Font', 'paprika' ),
                'subtitle' => __( 'Specify the menu font properties.', 'paprika' ),
                'google'   => true,
                'all_styles' => true,
                'text-align' => false,
                'color'     => false,
                'default'  => array(
                    'font-size'   => '15px',
                    'font-family' => 'Roboto Slab',
                    'font-weight' => '600',
                    'line-height' => '24px'
                ),
            ),


            // Heading all typography
            array(
                'id'       => 'heading-typography',
                'type'     => 'typography',
                'title'    => __( 'Heading Font', 'paprika' ),
                'subtitle' => __( 'This settings for all heading font (h1, h2, h3, h4, h5, h6)', 'paprika' ),
                'google'   => true,
                'all_styles' => true,
                'text-align' => false,
                'font-size' => false,
                'line-height' => false,
                'default'  => array(
                    'color'       => '#212121',
                    'font-family' => 'Roboto Slab',
                    'font-weight' => '800',
                ),
            ),

            // only H1 typography
            array(
                'id'       => 'h1-typography',
                'type'     => 'typography',
                'title'    => __( 'H1 (Heading one)', 'paprika' ),
                'subtitle' => __( 'This settings only for H1', 'paprika' ),
                'font-family' => false,
                'google'   => false,
                'text-align' => false,
                'font-size' => true,
                'line-height' => true,
                'color' => false,
                'font-weight' => false,
                'font-style' => false,
                'default'  => array(
                    'font-size'   => '35px',
                    'line-height' => '44px'
                ),
            ),


            // only H2 typography
            array(
                'id'       => 'h2-typography',
                'type'     => 'typography',
                'title'    => __( 'H2 (Heading two)', 'paprika' ),
                'subtitle' => __( 'This settings only for H2', 'paprika' ),
                'font-family' => false,
                'google'   => false,
                'text-align' => false,
                'font-size' => true,
                'line-height' => true,
                'color' => false,
                'font-weight' => false,
                'font-style' => false,
                'default'  => array(
                    'font-size'   => '25px',
                    'line-height' => '30px'
                ),
            ),


            // only H3 typography
            array(
                'id'       => 'h3-typography',
                'type'     => 'typography',
                'title'    => __( 'H3 (Heading three)', 'paprika' ),
                'subtitle' => __( 'This settings only for H3', 'paprika' ),
                'font-family' => false,
                'google'   => false,
                'text-align' => false,
                'font-size' => true,
                'line-height' => true,
                'color' => false,
                'font-weight' => false,
                'font-style' => false,
                'default'  => array(
                    'font-size'   => '20px',
                    'line-height' => '25px'
                ),
            ),

            // only H4 typography
            array(
                'id'       => 'h4-typography',
                'type'     => 'typography',
                'title'    => __( 'H4 (Heading four)', 'paprika' ),
                'subtitle' => __( 'This settings only for H4', 'paprika' ),
                'font-family' => false,
                'google'   => false,
                'text-align' => false,
                'font-size' => true,
                'line-height' => true,
                'color' => false,
                'font-weight' => false,
                'font-style' => false,
                'default'  => array(
                    'font-size'   => '18px',
                    'line-height' => '20px'
                ),
            ),

            // only H5 typography
            array(
                'id'       => 'h5-typography',
                'type'     => 'typography',
                'title'    => __( 'H5 (Heading five)', 'paprika' ),
                'subtitle' => __( 'This settings only for H5', 'paprika' ),
                'font-family' => false,
                'google'   => false,
                'text-align' => false,
                'font-size' => true,
                'line-height' => true,
                'color' => false,
                'font-weight' => false,
                'font-style' => false,
                'default'  => array(
                    'font-size'   => '16px',
                    'line-height' => '18px'
                ),
            ),

            // only H6 typography
            array(
                'id'       => 'h6-typography',
                'type'     => 'typography',
                'title'    => __( 'H6 (Heading six)', 'paprika' ),
                'subtitle' => __( 'This settings only for H6', 'paprika' ),
                'font-family' => false,
                'google'   => false,
                'text-align' => false,
                'font-size' => true,
                'line-height' => true,
                'color' => false,
                'font-weight' => false,
                'font-style' => false,
                'default'  => array(
                    'font-size'   => '14px',
                    'line-height' => '16px'
                ),
            ),

        )
    ));


    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Blog settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-file-edit',
        'title'  => esc_html__('Blog Settings', 'paprika'),
        'fields' => array(

            array(
                'id'       => 'blog-sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__('Blog sidebar setting', 'paprika'),
                'subtitle' => esc_html__('Select blog sidebar', 'paprika'),
                'options'  => array(
                    'no-sidebar'    => array(
                        'alt' => 'No sidebar',
                        'img' => ReduxFramework::$_url . 'assets/img/1col.png'
                    ),
                    'left-sidebar'  => array(
                        'alt' => 'Left sidebar',
                        'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                    ),
                    'right-sidebar' => array(
                        'alt' => 'Right sidebar',
                        'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                    )
                ),
                'default'  => 'right-sidebar'
            ),

            array(
                'id'       => 'post-lightbox-visibility',
                'type'     => 'switch',
                'title'    => esc_html__('Post lightbox', 'paprika'),
                'subtitle' => esc_html__('Check to show post lightbox for standard and gallery post only', 'paprika'),
                'on'       => esc_html__('Show', 'paprika'),
                'off'      => esc_html__('Hide', 'paprika'),
                'default'  => FALSE
            ),

            array(
                'id'       => 'tt-post-meta',
                'type'     => 'checkbox',
                'title'    => esc_html__( 'Post meta options', 'paprika' ),
                'subtitle' => esc_html__( 'Check to show post meta', 'paprika' ),
                'options'  => array(
                    'post-date'         => esc_html__( 'Post Date', 'paprika' ),
                    'post-author'       => esc_html__( 'Post Author', 'paprika' ),
                    'post-category'     => esc_html__( 'Post Category', 'paprika' ),
                    'post-comment'      => esc_html__( 'Post Comment', 'paprika' )
                ),
                'default'  => array(
                    'post-date' => '1',
                    'post-author'  => '1',
                    'post-category'   => '1',
                    'post-comment' => '1'
                )
            ),

            array(
                'id'       => 'show-share-button',
                'type'     => 'switch',
                'title'    => esc_html__('Post Share Button Visibility', 'paprika'),
                'subtitle' => esc_html__('Show or hide share button', 'paprika'),
                'on'       => esc_html__('Show', 'paprika'),
                'off'      => esc_html__('Hide', 'paprika'),
                'default'  => TRUE
            ),

            array(
                'id'       => 'show-print-button',
                'type'     => 'switch',
                'title'    => esc_html__('Post Print Button Visibility', 'paprika'),
                'subtitle' => esc_html__('Show or hide post print button', 'paprika'),
                'on'       => esc_html__('Show', 'paprika'),
                'off'      => esc_html__('Hide', 'paprika'),
                'default'  => TRUE
            ),
            
            array(
                'id'       => 'show-bookmarks-button',
                'type'     => 'switch',
                'title'    => esc_html__('Post Bookmarks Button Visibility', 'paprika'),
                'subtitle' => esc_html__('Show or hide post Bookmarks button', 'paprika'),
                'on'       => esc_html__('Show', 'paprika'),
                'off'      => esc_html__('Hide', 'paprika'),
                'default'  => TRUE
            ),
            
            array(
                'id'       => 'tt-share-button',
                'type'     => 'checkbox',
                'required' => array( 'show-share-button', '=', '1' ),
                'title'    => esc_html__( 'Share button', 'paprika' ),
                'subtitle' => esc_html__( 'Check to show share button', 'paprika' ),
                'options'  => array(
                    'facebook' => esc_html__( 'Facebook', 'paprika' ),
                    'twitter'  => esc_html__( 'Twitter', 'paprika' ),
                    'google'   => esc_html__( 'Google+', 'paprika' ),
                    'linkedin' => esc_html__( 'Linkedin', 'paprika' ),
                    'pinterest' => esc_html__( 'Pinterest', 'paprika' )
                ),
                'default'  => array(
                    'facebook' => '1',
                    'twitter'  => '1',
                    'google'   => '1',
                    'linkedin' => '1',
                    'pinterest' => '1'
                )
            ),

            array(
                'id'       => 'blog-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Blog Logo.', 'paprika'),
                'subtitle' => esc_html__('This logo option only for blog related page, logo dimension: 145px &times; 55px', 'paprika')
            ),

            array(
                'id'       => 'blog-mobile-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Blog Mobile Logo.', 'paprika'),
                'subtitle' => esc_html__('This logo option only for blog related page,logo dimension: 145px &times; 55px', 'paprika')
            ),

            array(
                'id'       => 'blog-sticky-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Blog Sticky Logo.', 'paprika'),
                'subtitle' => esc_html__('This logo option only for blog related page,logo dimension: 145px &times; 55px', 'paprika')
            ),

            array(
                'id'       => 'blog-sticky-mobile-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Blog Sticky Mobile Logo.', 'paprika'),
                'subtitle' => esc_html__('This logo option only for blog related page,logo dimension: 145px &times; 55px', 'paprika')
            ),

            //start blog post list item documentation:
            array(
                   'id' => 'blog-post-list-item-section-start',
                   'type' => 'section',
                   'title' => esc_html__('Blog post list item style documentation', 'paprika'),
                   'indent' => true 
            ),
            
            array(
                'id'       => 'blog-list-one',
                'type'     => 'image_select',
                'title'    => esc_html__('Blog post list style one', 'paprika'),
                'subtitle'    => esc_html__('You can use this style in a post', 'paprika'),
                'desc' => esc_html__('If you want this style in a post then follow this instruction: Add ul class="list-item" and add li class = "del" for delete specific items', 'paprika'),
                'options'  => array(
                    'bloglist-one'    => array(
                        'alt' => 'Blog post list-style',
                        'img' => esc_url( get_template_directory_uri() ) . '/images/list-style/list-style-one.jpg'
                    )
                ),
            ),

            array(
                'id'       => 'blog-list-two',
                'type'     => 'image_select',
                'title'    => esc_html__('Blog post list style two', 'paprika'),
                'subtitle'    => esc_html__('You can use this style in a post', 'paprika'),
                'desc' => esc_html__('If you want this style in a post then follow this instruction: Add ol class="list-number" for this style.', 'paprika'),
                'options'  => array(
                    'bloglist-one'    => array(
                        'alt' => 'Blog post list-style',
                        'img' => esc_url( get_template_directory_uri() ) . '/images/list-style/list-style-two.jpg'
                    )
                ),
            ),


            array(
                'id'     => 'section-end',
                'type'   => 'section',
                'indent' => false,
            ),
            //end blog post list item documentation:
            
        )
    ));


    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Page settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-file-edit',
        'title'  => esc_html__('Page Settings', 'paprika'),
        'fields' => array(

            array(
                'id'       => 'page-sidebar',
                'type'     => 'image_select',
                'title'    => esc_html__('Page Sidebar', 'paprika'),
                'subtitle' => esc_html__('Select page sidebar', 'paprika'),
                'options'  => array(
                    'no-sidebar'    => array(
                        'alt' => 'No sidebar',
                        'img' => ReduxFramework::$_url . 'assets/img/1col.png'
                    ),
                    'left-sidebar'  => array(
                        'alt' => 'Left sidebar',
                        'img' => ReduxFramework::$_url . 'assets/img/2cl.png'
                    ),
                    'right-sidebar' => array(
                        'alt' => 'Right sidebar',
                        'img' => ReduxFramework::$_url . 'assets/img/2cr.png'
                    )
                ),
                'default'  => 'right-sidebar'
            ),

            array(
                'id'       => 'page-comment-visibility',
                'type'     => 'switch',
                'title'    => esc_html__('Page comment visibility', 'paprika'),
                'subtitle' => esc_html__('Show or hide page comment globally', 'paprika'),
                'on'       => esc_html__('Visible', 'paprika'),
                'off'      => esc_html__('Hidden', 'paprika'),
                'default'  => FALSE,
            )
        )
    ));


    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Preloader settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-repeat-alt',
        'title'  => esc_html__('Preloader Settings', 'paprika'),
        'fields' => array(
            array(
                'id'       => 'page-preloader',
                'type'     => 'switch',
                'title'    => esc_html__('Page Preloader', 'paprika'),
                'subtitle' => esc_html__('You can enable or disable page preloader from here.', 'paprika'),
                'on'       => esc_html__('Enable', 'paprika'),
                'off'      => esc_html__('Disable', 'paprika'),
                'default'  => TRUE,
            ),

            array(
                'id'       => 'loader-bg-color',
                'type'     => 'color',
                'required' => array( 'page-preloader', '=', '1' ),
                'title'    => __( 'Preloader background color', 'paprika' ),
                'subtitle' => __( 'Pick color for preloader background (default: #ffffff).', 'paprika' ),
                'default'  => '#ffffff',
            ),

            array(
                'id'       => 'tt-loader',
                'type'     => 'media',
                'preview'  => 'true',
                'required' => array( 'page-preloader', '=', '1' ),
                'title'    => esc_html__('Animation file', 'paprika'),
                'subtitle' => esc_html__('Upload loader gif animation file', 'paprika')
            )
        )
    ));


	
	//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Social Icon settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'      => 'el-icon-googleplus',
        'customizer_width' => '450px',
        'title'     => esc_html__('Social icon Settings', 'paprika')
    ));
	

   
	//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Social icon settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-facebook',
        'title'  => esc_html__('Topbar Social Icon', 'paprika'),
		'subsection'       => true,
        'fields' => array(
            
            array(
                'id'       => 'social-icon-visibility',
                'type'     => 'switch',
                'title'    => esc_html__('Social icon visibility', 'paprika'),
                'subtitle' => esc_html__('Shor or hide social icon from footer', 'paprika'),
                'on'       => esc_html__('Show', 'paprika'),
                'off'      => esc_html__('Hide', 'paprika'),
                'default'  => TRUE,
            ),

            array(
                'id'       => 'facebook-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Facebook Link', 'paprika'),
                'subtitle' => esc_html__('Enter facebook page or profile link. Leave blank to hide icon.', 'paprika'),
                'default'  => "#"
            ),
            array(
                'id'       => 'twitter-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Twitter Link', 'paprika'),
                'subtitle' => esc_html__('Enter twitter link. Leave blank to hide icon.', 'paprika'),
                'default'  => "#"
            ),
            array(
                'id'       => 'google-plus-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Google Plus Link', 'paprika'),
                'subtitle' => esc_html__('Enter google plus page or profile link. Leave blank to hide icon.', 'paprika'),
                'default'  => "#"
            ),
            array(
                'id'       => 'youtube-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Youtube Link', 'paprika'),
                'subtitle' => esc_html__('Enter youtube chanel link. Leave blank to hide icon.', 'paprika'),
            ),
            array(
                'id'       => 'pinterest-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Pinterest Link', 'paprika'),
                'subtitle' => esc_html__('Enter pinterest link. Leave blank to hide icon.', 'paprika'),
                'default'  => "#"
            ),
            array(
                'id'       => 'flickr-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Flickr Link', 'paprika'),
                'subtitle' => esc_html__('Enter flicker link. Leave blank to hide icon.', 'paprika'),
            ),
            array(
                'id'       => 'linkedin-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Linkedin Link', 'paprika'),
                'subtitle' => esc_html__('Enter linkedin profile link. Leave blank to hide icon.', 'paprika'),
            ),
            array(
                'id'       => 'vimeo-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Vimeo Link', 'paprika'),
                'subtitle' => esc_html__('Enter vimeo chanel link. Leave blank to hide icon.', 'paprika'),
            ),
            array(
                'id'       => 'instagram-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Instagram Link', 'paprika'),
                'subtitle' => esc_html__('Enter instagram page or profile link. Leave blank to hide icon.', 'paprika'),
            ),
            array(
                'id'       => 'dribbble-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Dribbble Link', 'paprika'),
                'subtitle' => esc_html__('Enter dribbble profile link. Leave blank to hide icon.', 'paprika'),
            ),
            array(
                'id'       => 'behance-link',
                'type'     => 'text',
                'required' => array('social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Behance Link', 'paprika'),
                'subtitle' => esc_html__('Enter behance profile link. Leave blank to hide icon.', 'paprika'),
            ),
        )
    ));
	
	
	//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Footer Social Icon settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-twitter',
        'title'  => esc_html__('Footer Social Icon', 'paprika'),
		'subsection'       => true,
        'fields' => array(
            //Social icon items
            
           
            array(
                'id'       => 'footer-social-icon-visibility',
                'type'     => 'switch',
                'title'    => esc_html__('Social icon visibility', 'paprika'),
                'subtitle' => esc_html__('Show or hide social icon from footer', 'paprika'),
                'on'       => esc_html__('Show', 'paprika'),
                'off'      => esc_html__('Hide', 'paprika'),
                'default'  => TRUE,
            ),

            array(
                'id'       => 'footer-facebook-link',
                'type'     => 'text',
                'required' => array('footer-social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Facebook Link', 'paprika'),
                'subtitle' => esc_html__('Enter facebook page or profile link. Leave blank to hide icon.', 'paprika'),
                'default'  => "#"
            ),
			
			
            array(
                'id'       => 'footer-twitter-link',
                'type'     => 'text',
                'required' => array('footer-social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Twitter Link', 'paprika'),
                'subtitle' => esc_html__('Enter twitter link. Leave blank to hide icon.', 'paprika'),
                'default'  => "#"
            ),
            array(
                'id'       => 'footer-google-plus-link',
                'type'     => 'text',
                'required' => array('footer-social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Google Plus Link', 'paprika'),
                'subtitle' => esc_html__('Enter google plus page or profile link. Leave blank to hide icon.', 'paprika'),
                'default'  => "#"
            ),
            array(
                'id'       => 'footer-youtube-link',
                'type'     => 'text',
                'required' => array('footer-social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Youtube Link', 'paprika'),
                'subtitle' => esc_html__('Enter youtube chanel link. Leave blank to hide icon.', 'paprika'),
            ),
            array(
                'id'       => 'footer-pinterest-link',
                'type'     => 'text',
                'required' => array('footer-social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Pinterest Link', 'paprika'),
                'subtitle' => esc_html__('Enter pinterest link. Leave blank to hide icon.', 'paprika'),
                'default'  => "#"
            ),
            array(
                'id'       => 'footer-flickr-link',
                'type'     => 'text',
                'required' => array('footer-social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Flickr Link', 'paprika'),
                'subtitle' => esc_html__('Enter flicker link. Leave blank to hide icon.', 'paprika'),
            ),
            array(
                'id'       => 'footer-linkedin-link',
                'type'     => 'text',
                'required' => array('footer-social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Linkedin Link', 'paprika'),
                'subtitle' => esc_html__('Enter linkedin profile link. Leave blank to hide icon.', 'paprika'),
            ),
            array(
                'id'       => 'footer-vimeo-link',
                'type'     => 'text',
                'required' => array('footer-social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Vimeo Link', 'paprika'),
                'subtitle' => esc_html__('Enter vimeo chanel link. Leave blank to hide icon.', 'paprika'),
            ),
            array(
                'id'       => 'footer-instagram-link',
                'type'     => 'text',
                'required' => array('footer-social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Instagram Link', 'paprika'),
                'subtitle' => esc_html__('Enter instagram page or profile link. Leave blank to hide icon.', 'paprika'),
            ),
            array(
                'id'       => 'footer-dribbble-link',
                'type'     => 'text',
                'required' => array('footer-social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Dribbble Link', 'paprika'),
                'subtitle' => esc_html__('Enter dribbble profile link. Leave blank to hide icon.', 'paprika'),
            ),
            array(
                'id'       => 'footer-behance-link',
                'type'     => 'text',
                'required' => array('footer-social-icon-visibility', '=', '1'),
                'title'    => esc_html__('Behance Link', 'paprika'),
                'subtitle' => esc_html__('Enter behance profile link. Leave blank to hide icon.', 'paprika'),
            ),
        )
    ));

   
	//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // ads settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'      => 'el-icon-repeat-alt',
        'customizer_width' => '450px',
        'title'     => esc_html__('Ads Settings', 'paprika')
    ));
	
	//Post Top Ad 
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Post Top Ad', 'paprika' ),
        'subsection'       => true,
        'customizer_width' => '450px',
        'desc'             => esc_html__( 'Post top ads management', 'paprika'),
        'fields'           => array(
		
            array(
                'id'        => 'pt-ad-visibility',
                'type'      => 'switch',
                'title'     => esc_html__('Visibility Post top ad', 'paprika'),
                'subtitle'  => esc_html__('You can enable or disable ad from article top', 'paprika'),
                'on'        => esc_html__('Enable', 'paprika'),
                'off'       => esc_html__('Disable', 'paprika'),
                'default'   => FALSE,
            ),

            array(
                'id'        => 'pt-ad-type',
                'type'      => 'select',
                'required'=> array('pt-ad-visibility', '=', '1'),
                'title'     => esc_html__( 'Select ad type', 'paprika' ),
                'options'   => array(
                    'image-ad'      => esc_html__( 'Image Ad', 'paprika' ),
                    'adsense-ad'    => esc_html__( 'Adsense Ad', 'paprika' )
                ),
                'default'   => 'image-ad'
            ),

            array(
                'id'        => 'pt-image-ad-opt',
                'type'      => 'media',
                'preview'   => 'true',
                'required'  => array('pt-ad-type', '=', 'image-ad'),
                'title'     => esc_html__('Image Ad', 'paprika'),
                'desc'      => esc_html__('Choose a post top ad, size is 730x90', 'paprika')
            ),

            array(
                'id'        => 'pt-image-link',
                'type'      => 'text',
                'required'  => array('pt-ad-type', '=', 'image-ad'),
                'title'     => esc_html__( 'Image custom link', 'paprika' ),
                'subtitle'  => esc_html__( 'Paste the custom url here, leave blank for no link', 'paprika' )
            ),

            array(
                'id'        => 'pt-ad-codes',
                'type'      => 'textarea',
                'required'  => array('pt-ad-type', '=', 'adsense-ad'),
                'title'     => esc_html__( 'Your article top ad', 'paprika' ),
                'subtitle'  => esc_html__( 'Paste your ad code here. Google adsense will be made responsive automatically.', 'paprika' )
            ),
			
			

            array(
                'id'    => 'article_bottom_sizes',
                'type'  => 'info',
                'required'=> array('pt-ad-visibility', '=', '1'),
                'title' => esc_html__('All supported ad sizes for article top:', 'paprika'),
                'desc'  => '<span>leaderboard (730x90)<br>
                            banner (468x60)<br>
                            half banner (234x60)<br>
                            mobile banner (320x50)<br>
                            large leaderboard (970x90)</span>',
            ),

            array(
                'id'        => 'pt-ad-title',
                'type'      => 'text',
                'required'=> array('pt-ad-visibility', '=', '1'),
                'title'     => esc_html__( 'Add title', 'paprika' ),
                'subtitle'  => esc_html__( 'A title for the Ad, e.g - Advertisement.', 'paprika' )
            ),
			
			array(
                'id'       => 'pt-ad-position',
                'type'     => 'text',
                'required'=> array('pt-ad-visibility', '=', '1'),
                'title'    => esc_html__('Ad position', 'paprika'),
                'subtitle' => esc_html__('You can set ad position by post', 'paprika'),
                'default'  => 1,
            ),

            array(
                'id'        => 'pt-desktop-lg-visibility',
                'type'      => 'switch',
                'required'=> array('pt-ad-visibility', '=', '1'),
                'title'     => esc_html__('Disable on large screen ?', 'paprika'),
                'subtitle'  => esc_html__('You can enable or disable ad from desktop device', 'paprika'),
                'on'        => esc_html__('Enable', 'paprika'),
                'off'       => esc_html__('Disable', 'paprika'),
                'default'   => TRUE,
            ),

            array(
                'id'       => 'pt-desktop-md-visibility',
                'type'     => 'switch',
                'required'=> array('pt-ad-visibility', '=', '1'),
                'title'    => esc_html__('Disable on medium screen ?', 'paprika'),
                'subtitle' => esc_html__('You can enable or disable ad from desktop medium device', 'paprika'),
                'on'       => esc_html__('Enable', 'paprika'),
                'off'      => esc_html__('Disable', 'paprika'),
                'default'  => TRUE,
            ),

            array(
                'id'       => 'pt-tablet-visibility',
                'type'     => 'switch',
                'required'=> array('pt-ad-visibility', '=', '1'),
                'title'    => esc_html__('Disable on tablet ?', 'paprika'),
                'subtitle' => esc_html__('You can enable or disable ad from tablet device', 'paprika'),
                'on'       => esc_html__('Enable', 'paprika'),
                'off'      => esc_html__('Disable', 'paprika'),
                'default'  => TRUE,
            ),

            array(
                'id'       => 'pt-mobile-visibility',
                'type'     => 'switch',
                'required'=> array('pt-ad-visibility', '=', '1'),
                'title'    => esc_html__('Disable on mobile ?', 'paprika'),
                'subtitle' => esc_html__('You can enable or disable ad from mobile device', 'paprika'),
                'on'       => esc_html__('Enable', 'paprika'),
                'off'      => esc_html__('Disable', 'paprika'),
                'default'  => TRUE,
            ),
			
           
			
			

        )
    ));
	
	
	//Post Middle Ad 
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Post Middle Ad', 'paprika' ),
        'subsection'       => true,
        'customizer_width' => '450px',
        'desc'             => esc_html__( 'Post middle ads management', 'paprika'),
        'fields'           => array(
		
            array(
                'id'        => 'pm-ad-visibility',
                'type'      => 'switch',
                'title'     => esc_html__('Visibility article top ad', 'paprika'),
                'subtitle'  => esc_html__('You can enable or disable ad from article top', 'paprika'),
                'on'        => esc_html__('Enable', 'paprika'),
                'off'       => esc_html__('Disable', 'paprika'),
                'default'   => FALSE,
            ),

            array(
                'id'        => 'pm-ad-type',
                'type'      => 'select',
                'required'=> array('pm-ad-visibility', '=', '1'),
                'title'     => esc_html__( 'Select ad type', 'paprika' ),
                'options'   => array(
                    'image-ad'      => esc_html__( 'Image Ad', 'paprika' ),
                    'adsense-ad'    => esc_html__( 'Adsense Ad', 'paprika' )
                ),
                'default'   => 'image-ad'
            ),

            array(
                'id'        => 'pm-image-ad-opt',
                'type'      => 'media',
                'preview'   => 'true',
                'required'  => array('pm-ad-type', '=', 'image-ad'),
                'title'     => esc_html__('Image Ad', 'paprika'),
                'desc'      => esc_html__('Choose a post top ad, size is 730x90', 'paprika')
            ),

            array(
                'id'        => 'pm-image-link',
                'type'      => 'text',
                'required'  => array('pm-ad-type', '=', 'image-ad'),
                'title'     => esc_html__( 'Image custom link', 'paprika' ),
                'subtitle'  => esc_html__( 'Paste the custom url here, leave blank for no link', 'paprika' )
            ),

            array(
                'id'        => 'pm-ad-codes',
                'type'      => 'textarea',
                'required'  => array('pm-ad-type', '=', 'adsense-ad'),
                'title'     => esc_html__( 'Your article top ad', 'paprika' ),
                'subtitle'  => esc_html__( 'Paste your ad code here. Google adsense will be made responsive automatically.', 'paprika' )
            ),

            array(
                'id'    => 'article_bottom_sizes',
                'type'  => 'info',
                'required'=> array('pm-ad-visibility', '=', '1'),
                'title' => esc_html__('All supported ad sizes for article top:', 'paprika'),
                'desc'  => '<span>leaderboard (730x90)<br>
                            banner (468x60)<br>
                            half banner (234x60)<br>
                            mobile banner (320x50)<br>
                            large leaderboard (970x90)</span>',
            ),

            array(
                'id'        => 'pm-ad-title',
                'type'      => 'text',
                'required'=> array('pm-ad-visibility', '=', '1'),
                'title'     => esc_html__( 'Add title', 'paprika' ),
                'subtitle'  => esc_html__( 'A title for the Ad, e.g - Advertisement.', 'paprika' )
            ),
			
			array(
                'id'       => 'pm-ad-position',
                'type'     => 'text',
                'required'=> array('pm-ad-visibility', '=', '1'),
                'title'    => esc_html__('Ad position', 'paprika'),
                'subtitle' => esc_html__('You can set ad position by post', 'paprika'),
                'default'  => 5,
            ),

            array(
                'id'        => 'pm-desktop-lg-visibility',
                'type'      => 'switch',
                'required'=> array('pm-ad-visibility', '=', '1'),
                'title'     => esc_html__('Disable on large screen ?', 'paprika'),
                'subtitle'  => esc_html__('You can enable or disable ad from desktop device', 'paprika'),
                'on'        => esc_html__('Enable', 'paprika'),
                'off'       => esc_html__('Disable', 'paprika'),
                'default'   => TRUE,
            ),

            array(
                'id'       => 'pm-desktop-md-visibility',
                'type'     => 'switch',
                'required'=> array('pm-ad-visibility', '=', '1'),
                'title'    => esc_html__('Disable on medium screen ?', 'paprika'),
                'subtitle' => esc_html__('You can enable or disable ad from desktop medium device', 'paprika'),
                'on'       => esc_html__('Enable', 'paprika'),
                'off'      => esc_html__('Disable', 'paprika'),
                'default'  => TRUE,
            ),

            array(
                'id'       => 'pm-tablet-visibility',
                'type'     => 'switch',
                'required'=> array('pm-ad-visibility', '=', '1'),
                'title'    => esc_html__('Disable on tablet ?', 'paprika'),
                'subtitle' => esc_html__('You can enable or disable ad from tablet device', 'paprika'),
                'on'       => esc_html__('Enable', 'paprika'),
                'off'      => esc_html__('Disable', 'paprika'),
                'default'  => TRUE,
            ),

            array(
                'id'       => 'pm-mobile-visibility',
                'type'     => 'switch',
                'required'=> array('pm-ad-visibility', '=', '1'),
                'title'    => esc_html__('Disable on mobile ?', 'paprika'),
                'subtitle' => esc_html__('You can enable or disable ad from mobile device', 'paprika'),
                'on'       => esc_html__('Enable', 'paprika'),
                'off'      => esc_html__('Disable', 'paprika'),
                'default'  => TRUE,
            )
			

        )
    ));
	
	
	
	//Post Bottom Ad 
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Post Bottom Ad', 'paprika' ),
        'subsection'       => true,
        'customizer_width' => '450px',
        'desc'             => esc_html__( 'Post Bottom ads management', 'paprika'),
        'fields'           => array(
		
            array(
                'id'        => 'pb-ad-visibility',
                'type'      => 'switch',
                'title'     => esc_html__('Visibility article top ad', 'paprika'),
                'subtitle'  => esc_html__('You can enable or disable ad from article top', 'paprika'),
                'on'        => esc_html__('Enable', 'paprika'),
                'off'       => esc_html__('Disable', 'paprika'),
                'default'   => FALSE,
            ),

            array(
                'id'        => 'pb-ad-type',
                'type'      => 'select',
                'required'=> array('pb-ad-visibility', '=', '1'),
                'title'     => esc_html__( 'Select ad type', 'paprika' ),
                'options'   => array(
                    'image-ad'      => esc_html__( 'Image Ad', 'paprika' ),
                    'adsense-ad'    => esc_html__( 'Adsense Ad', 'paprika' )
                ),
                'default'   => 'image-ad'
            ),

            array(
                'id'        => 'pb-image-ad-opt',
                'type'      => 'media',
                'preview'   => 'true',
                'required'  => array('pb-ad-type', '=', 'image-ad'),
                'title'     => esc_html__('Image Ad', 'paprika'),
                'desc'      => esc_html__('Choose a post top ad, size is 730x90', 'paprika')
            ),

            array(
                'id'        => 'pb-image-link',
                'type'      => 'text',
                'required'  => array('pb-ad-type', '=', 'image-ad'),
                'title'     => esc_html__( 'Image custom link', 'paprika' ),
                'subtitle'  => esc_html__( 'Paste the custom url here, leave blank for no link', 'paprika' )
            ),

            array(
                'id'        => 'pb-ad-codes',
                'type'      => 'textarea',
                'required'  => array('pb-ad-type', '=', 'adsense-ad'),
                'title'     => esc_html__( 'Your article top ad', 'paprika' ),
                'subtitle'  => esc_html__( 'Paste your ad code here. Google adsense will be made responsive automatically.', 'paprika' )
            ),

            array(
                'id'    => 'article_bottom_sizes',
                'type'  => 'info',
                'required'=> array('pb-ad-visibility', '=', '1'),
                'title' => esc_html__('All supported ad sizes for article top:', 'paprika'),
                'desc'  => '<span>leaderboard (730x90)<br>
                            banner (468x60)<br>
                            half banner (234x60)<br>
                            mobile banner (320x50)<br>
                            large leaderboard (970x90)</span>',
            ),

            array(
                'id'        => 'pb-ad-title',
                'type'      => 'text',
                'required'=> array('pb-ad-visibility', '=', '1'),
                'title'     => esc_html__( 'Add title', 'paprika' ),
                'subtitle'  => esc_html__( 'A title for the Ad, e.g - Advertisement.', 'paprika' )
            ),
			
			array(
                'id'       => 'pb-ad-position',
                'type'     => 'text',
                'required'=> array('pb-ad-visibility', '=', '1'),
                'title'    => esc_html__('Ad position', 'paprika'),
                'subtitle' => esc_html__('You can set ad position by post', 'paprika'),
                'default'  => 10,
            ),

            array(
                'id'        => 'pb-desktop-lg-visibility',
                'type'      => 'switch',
                'required'=> array('pb-ad-visibility', '=', '1'),
                'title'     => esc_html__('Disable on large screen ?', 'paprika'),
                'subtitle'  => esc_html__('You can enable or disable ad from desktop device', 'paprika'),
                'on'        => esc_html__('Enable', 'paprika'),
                'off'       => esc_html__('Disable', 'paprika'),
                'default'   => TRUE,
            ),

            array(
                'id'       => 'pb-desktop-md-visibility',
                'type'     => 'switch',
                'required'=> array('pb-ad-visibility', '=', '1'),
                'title'    => esc_html__('Disable on medium screen ?', 'paprika'),
                'subtitle' => esc_html__('You can enable or disable ad from desktop medium device', 'paprika'),
                'on'       => esc_html__('Enable', 'paprika'),
                'off'      => esc_html__('Disable', 'paprika'),
                'default'  => TRUE,
            ),

            array(
                'id'       => 'pb-tablet-visibility',
                'type'     => 'switch',
                'required'=> array('pb-ad-visibility', '=', '1'),
                'title'    => esc_html__('Disable on tablet ?', 'paprika'),
                'subtitle' => esc_html__('You can enable or disable ad from tablet device', 'paprika'),
                'on'       => esc_html__('Enable', 'paprika'),
                'off'      => esc_html__('Disable', 'paprika'),
                'default'  => TRUE,
            ),

            array(
                'id'       => 'pb-mobile-visibility',
                'type'     => 'switch',
                'required'=> array('pb-ad-visibility', '=', '1'),
                'title'    => esc_html__('Disable on mobile ?', 'paprika'),
                'subtitle' => esc_html__('You can enable or disable ad from mobile device', 'paprika'),
                'on'       => esc_html__('Enable', 'paprika'),
                'off'      => esc_html__('Disable', 'paprika'),
                'default'  => TRUE,
            )
			

        )
    ));
	
	
	
	
	
	
	
	
	
	
	//All site banner, slider settings
	
	Redux::setSection( $opt_name, array(
        'icon'      => 'el el-graph',
        'customizer_width' => '450px',
        'title'     => esc_html__('Banner settings', 'paprika')
    ));
	
	
	//Slider settings
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Slider Settings', 'paprika' ),
        'customizer_width' => '450px',
		'subsection'       => true,
        'desc'             => esc_html__( 'Site slider management', 'paprika'),
        'fields'           => array(
		
			array(
                'id'        => 'slider-visibility',
                'type'      => 'switch',
                'title'     => esc_html__('Visibility slider', 'paprika'),
                'subtitle'  => esc_html__('You can enable or disable slider', 'paprika'),
                'on'        => esc_html__('Enable', 'paprika'),
                'off'       => esc_html__('Disable', 'paprika'),
                'default'   => FALSE,
            ),
			
            array(
				'id'       => 'post-source',
				'type'     => 'select',
				'required' => array('slider-visibility', '=', '1'),
				'title'    => esc_html__('Select post source', 'paprika'),
				'options'  => array(
					'latest-post' => 'Latest Post',
					'selected-post' => 'Selected Post',
					'category-post' => 'From Category'
				),
				'default'  => 'latest-post',
				'subtitle' => esc_html__('Select post source', 'paprika'),
			),

			array(
				'id'       => 'post-lists',
				'type'     => 'select',
				'required' => array('post-source', '=', 'selected-post'),
				'title'    => esc_html__('Select posts', 'paprika'),
				'data'     => 'posts',
				'args'		=> array('post_type' => 'post', 'posts_per_page'=> -1),
				'multi'    => true,
				'subtitle' => esc_html__('Select post to show on breaking news', 'paprika'),
			),

			array(
				'id'       => 'category-lists',
				'type'     => 'select',
				'required' => array('post-source', '=', 'category-post'),
				'title'    => esc_html__('Select a category', 'paprika'),
				'data'     => 'categories',
				'subtitle' => esc_html__('Select a cateogry to show selected category post', 'paprika'),
			),

			array(
				'id'       => 'post-limit',
				'type'     => 'text',
				'required' => array('post-source', '=', array('category-post', 'latest-post')),
				'title'    => esc_html__('Breaking news limit', 'paprika'),
				'subtitle' => esc_html__('Change post limit for breaking news', 'paprika'),
				'default'  => 5
			)
						

        )
    ));
	
	
	
	
	//homepage promo settings 
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Promo Settings', 'paprika' ),
        'customizer_width' => '450px',
		'subsection'       => true,
        'desc'             => esc_html__( 'Welcome page promotions settings', 'paprika'),
        'fields'           => array(
		
			array(
                'id'        => 'promo-visibility',
                'type'      => 'switch',
                'title'     => esc_html__('Promotions visibility', 'paprika'),
                'subtitle'  => esc_html__('You can enable or disable promotion box', 'paprika'),
                'on'        => esc_html__('Enable', 'paprika'),
                'off'       => esc_html__('Disable', 'paprika'),
                'default'   => FALSE,
            ),
			
			//About me section start
			array(
				   'id' => 'about-me-section-start',
				   'type' => 'section',
				   'title' => esc_html__('About Me', 'paprika'),
				   'subtitle' => esc_html__('This is About Me section, you can edit and update content about you', 'paprika'),
				   'required' => array('promo-visibility', '=', '1'),
				   'indent' => true 
			   ),
			
			
				array(
					'id'        => 'about-us-photo',
					'type'      => 'media',
					'preview'   => 'true',
					'title'     => esc_html__('Upload Your Image', 'paprika'),
					'subtitle'  => esc_html__('Upload about us image. Image size will be 370px x 250px', 'paprika'),
					'required' => array('promo-visibility', '=', '1'),
				),
				
				array(
					'id'        => 'about-me-title',
					'type'      => 'text',
					'title'     => esc_html__('About me title', 'paprika'),
					'default'	=> 'About Me',
					'subtitle'  => esc_html__('Write some word about you', 'paprika'),
					'required' => array('promo-visibility', '=', '1'),
				),
				array(
					'id'        => 'about-url',
					'type'      => 'text',
					'title'     => esc_html__('Pest your profile link', 'paprika'),
					'subtitle'  => esc_html__('Pest your profile link', 'paprika'),
					'required' => array('promo-visibility', '=', '1'),
				),
			
			//About me section end
			array(
				'id'     => 'about-me-section-end',
				'type'   => 'section',
				'required' => array('promo-visibility', '=', '1'),
				'indent' => false,
			),
			
					
			//instagram section start
			array(
				   'id' => 'instagram-section-start',
				   'type' => 'section',
				   'title' => esc_html__('Instagram setting', 'paprika'),
				   'subtitle' => esc_html__('This is Instagram setting section.', 'paprika'),
				   'required' => array('promo-visibility', '=', '1'),
				   'indent' => true 
			   ),
			
			
				array(
					'id'        => 'instagram-photo',
					'type'      => 'media',
					'preview'   => 'true',
					'title'     => esc_html__('Upload Photo', 'paprika'),
					'subtitle'  => esc_html__('Upload A photo. Image size will be 370px x 250px', 'paprika'),
					'required' => array('promo-visibility', '=', '1'),
				),
				
				array(
					'id'        => 'instagram-url',
					'type'      => 'text',
					'title'     => esc_html__('Pest instagram profile link', 'paprika'),
					'subtitle'  => esc_html__('Pest your instagram profile link', 'paprika'),
					'required' => array('promo-visibility', '=', '1'),
				),
				array(
					'id'        => 'instagram-btn-text',
					'type'      => 'text',
					'title'     => esc_html__('Instagram Title', 'paprika'),
					'subtitle'  => esc_html__('Write Instagram Title', 'paprika'),
					'required' => array('promo-visibility', '=', '1'),
					'default'	=> 'Follow Me @ Instagram'
				),
			
			//section end
			array(
				'id'     => 'instragram-section-end',
				'type'   => 'section',
				'required' => array('promo-visibility', '=', '1'),
				'indent' => false,
			),
					
			//Custom Link section start
			array(
				   'id' => 'custom-section-start',
				   'type' => 'section',
				   'title' => esc_html__('Custom Link setting', 'paprika'),
				   'subtitle' => esc_html__('This is Custom Link setting section.', 'paprika'),
				   'required' => array('promo-visibility', '=', '1'),
				   'indent' => true 
			   ),
			
			
				array(
					'id'        => 'custom-link-photo',
					'type'      => 'media',
					'preview'   => 'true',
					'title'     => esc_html__('Upload Photo', 'paprika'),
					'required' => array('promo-visibility', '=', '1'),
					'subtitle'  => esc_html__('Upload A photo. Image size will be 370px x 250px', 'paprika'),
				),
				
				array(
					'id'        => 'custom-link-photo-url',
					'type'      => 'text',
					'title'     => esc_html__('Pest Custom Link', 'paprika'),
					'required' => array('promo-visibility', '=', '1'),
					'subtitle'  => esc_html__('Pest your Custom Link', 'paprika'),
				),
				array(
					'id'        => 'custom-link-photo-btn-text',
					'type'      => 'text',
					'title'     => esc_html__('Custom Title', 'paprika'),
					'subtitle'  => esc_html__('Write Custom Link Button Name or title', 'paprika'),
					'required' => array('promo-visibility', '=', '1'),
					'default'	=> 'Visit The Shop'
				),
			
			//section end
			array(
				'id'     => 'instragram-section-end',
				'type'   => 'section',
				'required' => array('promo-visibility', '=', '1'),
				'indent' => false,
			),
			
						

        )
    ));
	
	
	//Instagram Feed settings 
    Redux::setSection( $opt_name, array(
        'title'            => esc_html__( 'Instagram Feed', 'paprika' ),
        'customizer_width' => '450px',
        'desc'             => esc_html__( 'Instagram Feed settings', 'paprika'),
        'fields'           => array(
		
			array(
                'id'        => 'instagram-visibility',
                'type'      => 'switch',
                'title'     => esc_html__('Instagram visibility', 'paprika'),
                'subtitle'  => esc_html__('You can enable or disable instagram feed', 'paprika'),
                'on'        => esc_html__('Enable', 'paprika'),
                'off'       => esc_html__('Disable', 'paprika'),
                'default'   => TRUE,
            ),
			
			array(
				'id'        => 'instagram-user-name',
				'type'      => 'text',
				'title'     => esc_html__('User name', 'paprika'),
				'subtitle'  => esc_html__('Write your user name', 'paprika'),
				'desc' 		=> 'eg. JohnDoe',
				'required' => array('instagram-visibility', '=', '1'),
			),
			array(
				'id'        => 'instagram-id',
				'type'      => 'text',
				'title'     => esc_html__('Instagram id', 'paprika'),
				'default'	=> 2963143209,
				'subtitle'  => esc_html__('Pest your instagram id here', 'paprika'),
				'desc' 		=> 'eg. 2963143209',
				'required' => array('instagram-visibility', '=', '1'),
			),
			array(
				'id'        => 'access-token',
				'type'      => 'text',
				'title'     => esc_html__('Access token', 'paprika'),
				'subtitle'  => esc_html__('Pest your instagram access token here', 'paprika'),
				'required' => array('instagram-visibility', '=', '1'),
				'desc' => 'eg. 2963143209.1677ed0.6cf28ac3f9c041759202e3e1af8baa46'
			),
            array(
                'id'        => 'instagram-limit',
                'title'     => esc_html__('Photo Limit', 'paprika'),
                'subtitle'  => esc_html__('You can set instagram photo limit', 'paprika'),
                'required' => array('instagram-visibility', '=', '1'),
                'type'     => 'spinner', 
                'desc'     => __('Photo limit description. Min:4, max: 10, step:2, default value: 6', 'redux-framework-demo'),
                'default'  => '6',
                'min'      => '4',
                'step'     => '2',
                'max'      => '10',
            ),

			array(
				'id'        => 'instagram-resolution',
				'title'     => esc_html__('Instagram Resolution', 'paprika'),
				'subtitle'  => esc_html__('You can choose instagram photo resolution from here', 'paprika'),
				'required' => array('instagram-visibility', '=', '1'),
				'type'     => 'select', 
                'options'  => array(
                    'thumbnail' => 'Thumbnail',
                    'low_resolution' => 'Low Resolution',
                    'standard_resolution' => 'Standard Resolution'
                ),
                'default'  => 'thumbnail',
			),



			array(
                'id'    => 'instagram-info',
                'type'  => 'info',
                'required' => array('instagram-visibility', '=', '1'),
                'title' => esc_html__('HOW TO CREATE A VALID INSTAGRAM ID TO USE:', 'paprika'),
                'desc'  => '<h2>Instrauction:</h2>
							You need your user name and your access token for use Instagram API. Login to Instagram <a href="https://www.instagram.com"> Click here </a> <br>
							You can get your user ID <a href="https://smashballoon.com/instagram-feed/find-instagram-user-id/"> from here</a><br>
							Get your access token <a href="http://jelled.com/instagram/access-token">from here</a> and folow the instruction<br>
							You can also generate access token <a href="http://instagram.pixelunion.net/">from here</a>
							Use your userId and accessToken as below instead!
							',
            ),

        )
    ));
	
	
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    // Footer settings
    //-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
    Redux::setSection( $opt_name, array(
        'icon'   => 'el-icon-photo',
        'title'  => esc_html__('Footer Settings', 'paprika'),
        'fields' => array(
            // footer style
            
            array(
                'id'       => 'footer-logo',
                'type'     => 'media',
                'preview'  => 'true',
                'title'    => esc_html__('Footer Logo.', 'paprika'),
                'subtitle' => esc_html__('Change footer logo dimension: 150px &times; 30px', 'paprika')
            ),
           
            array(
                'id'       => 'footer-about-text',
                'type'     => 'editor',
                'title'    => esc_html__('Footer About Text', 'markety'),
                'subtitle' => esc_html__('Write footer about text here.', 'markety'),
                'default' => esc_html__('An elegant weapon for a more civilized time. For over a thousand generations the Jedi Knights were the guardians of peace and justice in the Old Republic.', 'markety')
            ),
            array(
                'id'       => 'copyright-text',
                'type'     => 'editor',
                'title'    => esc_html__('Footer Copyright Text', 'paprika'),
                'subtitle' => esc_html__('Write footer copyright text here.', 'paprika'),
                'default' => esc_html__('© TrendyTheme. All rights reserved.', 'markety')
            ),
            
            array(
                'id'       => 'authorize-text',
                'type'     => 'editor',
                'title'    => esc_html__('Footer Authorize Text', 'paprika'),
                'subtitle' => esc_html__('Write Footer Authorize text here.', 'paprika'),
                'default' => esc_html__('Carefully crafted by TrendyTheme', 'markety')
            ),
        )
    ));
        
        
	
    /*
     * <--- END SECTIONS
     */