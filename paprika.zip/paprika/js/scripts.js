/*
Theme Name: Paprika
Author: TrendyTheme
*/

/* ======= TABLE OF CONTENTS ================================== 
    # Preloader
    # Enable bootstrap tooltip
    # Detect IE version
    # Mobile Dropdown Menu
    # Dropdown menu offest
    # Sticky Menu 
    # Full Screen Background
    # Magnific Popup for blog post
    # Instagram Photo Feed
    # Slider-v2-wrapper owl-carousel
    # Back to top activation
    # Print jquery
    # Bookmark jquery
    # Fidbits active
    # Homepage slide active
    # Search button customization
========================================================= */

jQuery(function ($) {

    'use strict';

    /* ======= Preloader ======= */
    (function () {
        $('#status').fadeOut();
        $('#preloader').delay(200).fadeOut('slow');
    }());


    /* ======= Enable bootstrap tooltip ======= */
    (function () {
        $('[data-toggle="tooltip"]').tooltip()
    }());


    /* === Detect IE version === */
    (function () {
        
        function getIEVersion() {
            var match = navigator.userAgent.match(/(?:MSIE |Trident\/.*; rv:)(\d+)/);
            return match ? parseInt(match[1], 10) : false;
        }

        if( getIEVersion() ){
            $('html').addClass('ie'+getIEVersion());
        }

    }());


    /* === Mobile Dropdown Menu === */
    (function(){
        $('.dropdown-menu-trigger').each(function() {
            $(this).on('click', function(e){
                $(this).toggleClass('menu-collapsed');
            });
        });
    }());


    /* === Dropdown menu offest === */
    $(window).on('load resize', function () {
        $(".dropdown-wrapper > ul > li").each(function() {
            var $this = $(this),
                $win = $(window);

            if ($this.offset().left + 195 > $win.width() + $win.scrollLeft() - $this.width()) {
                $this.addClass("dropdown-inverse");
            } else {
                $this.removeClass("dropdown-inverse");
            }
        });
    });


    /* === Sticky Menu === */
    (function () {
        if (paprikaJSObject.paprika_sticky_menu == true) {
            var nav = $('.header-wrapper');
            var scrolled = false;

            $(window).on('scroll', function () {

                if (140 < $(window).scrollTop() && !scrolled) {
                    nav.addClass('is-sticky').animate({ 'margin-top': '0px' });
                    scrolled = true;
                }

                if (140 > $(window).scrollTop() && scrolled) {
                    nav.removeClass('is-sticky').css('margin-top', '0px');
                    scrolled = false;
                }
            });
        }
    }());


    /* ======= Full Screen Background ======= */
    $(".tt-fullHeight").height($(window).height());
    $(window).resize(function(){
        $(".tt-fullHeight").height($(window).height());
    });


    /* ======= Magnific Popup for blog post ======= */
    $('.blog-popup').magnificPopup({
        type: 'image',
        mainClass: 'mfp-fade',
        removalDelay: 160,
        fixedContentPos: false,
        gallery:{
            enabled:false
        }
    });

	
   /* === Instagram Photo Feed === */

    /**
    * ### HOW TO CREATE A VALID INSTAGRAM ID TO USE: ###
    * You need your user name and your access token for use Instagram API. Login to Instagram https://www.instagram.com 
    * You can get your user ID from here: https://smashballoon.com/instagram-feed/find-instagram-user-id/
    * Get your access token from http://jelled.com/instagram/access-token and folow the instruction
    * You can also generate access token from here: http://instagram.pixelunion.net/.
    * Use your userId and accessToken as below instead!
    */

    if ($('#myinstafeed').length > 0) {
		var userId = paprikaJSObject.paprika_instagram_id;
		var	accessToken = paprikaJSObject.access_token;
		var	instagramLimit = paprikaJSObject.instagram_limit;
		var	instagramResolution = paprikaJSObject.instagram_resolution;
		
        var feed = new Instafeed({
            target: 'myinstafeed', //The ID of a DOM element you want to add the images to
            limit: instagramLimit,
            get: 'user',
			resolution: instagramResolution,
            userId: userId,
            accessToken: ''+accessToken+''
        });
        feed.run();
    }

    
    /* === Slider-v2-wrapper owl-carousel === */

	$('.slider-v2-owl-carousel').owlCarousel({
		items:3,
		lazyLoad:true,
		loop:true,
		autoplay:true,
		autoplayTimeout:5000,
		margin:30,
		nav: true,
        navText: ["<i class='fa fa-arrow-left'></i>", "<i class='fa fa-arrow-right'></i>"],
		autoplayHoverPause:true,
		responsive: {
		  0: {
			items: 1
		  },
		  320: {
			items: 1
		  },
		  640: {
			items: 2
		  },
		  960: {
			items: 3
		  },
		  1200: {
			items: 3
		  }
		}
	});
	
	
	/* === Back to top activation === */

	$(document).ready(function(){ 
		
		$('.scrollup').click(function(){
			$("html, body").animate({ scrollTop: 0 }, 600);
			return false;
		});

	});
	

	/* === Print jquery === */

	$("article.post-wrapper").find('.print-post').on('click', function() {
		//Print ele4 with custom options
		$("article.post-wrapper").print({
			//Use Global styles
			globalStyles : false,
			//Add link with attrbute media=print
			mediaPrint : false,
			//Custom stylesheet
			stylesheet : "https://fonts.googleapis.com/css?family=Lato",
			//Print in a hidden iframe
			iframe : false,
			//Don't print this
			noPrintSelector : ".single-page-mata, .entry-meta, .entry-footer",
			//Add this at top
			prepend : "Welcome to Paprika",
			//Add this on bottom
			append : "<br/>Bye Bye!",
			//Log to console when printing is done via a deffered callback
			deferred: $.Deferred().done(function() { console.log('Printing done', arguments); })
		});
	});
	

	/* === Bookmark jquery === */

	jQuery(function($) {
	  $('a.bookmark-post').click(function(e) {
		var bookmarkURL = window.location.href;
		var bookmarkTitle = document.title;

		if ('addToHomescreen' in window && addToHomescreen.isCompatible) {
		  // Mobile browsers
		  addToHomescreen({ autostart: false, startDelay: 0 }).show(true);
		} else if (window.sidebar && window.sidebar.addPanel) {
		  // Firefox <=22
		  window.sidebar.addPanel(bookmarkTitle, bookmarkURL, '');
		} else if ((window.sidebar && /Firefox/i.test(navigator.userAgent)) || (window.opera && window.print)) {
		  // Firefox 23+ and Opera <=14
		  $(this).attr({
			href: bookmarkURL,
			title: bookmarkTitle,
			rel: 'sidebar'
		  }).off(e);
		  return true;
		} else if (window.external && ('AddFavorite' in window.external)) {
		  // IE Favorites
		  window.external.AddFavorite(bookmarkURL, bookmarkTitle);
		} else {
		  // Other browsers (mainly WebKit & Blink - Safari, Chrome, Opera 15+)
		  alert('Press ' + (/Mac/i.test(navigator.userAgent) ? 'Cmd' : 'Ctrl') + '+D to bookmark this page.');
		}

		return false;
	  });
	});

    /* === Fidbits active === */

    (function () {
        // Target your .container, .wrapper, .post, etc.
        $(".blog-video").fitVids();
        
    }());


    /* === Homepage slide active === */

	(function () {
        $('#homepage-slider > .item:first-child').addClass('active');
    }());
    
    
    /* === Search button customization === */

    (function () {

        $("i.menu-search-icon").on('click', function(){
            $(".menu-search-bar").toggleClass('search-toggle');
        });



        $(".menu-search-bar i.fa-close").on('click', function(){
            $(".menu-search-bar").removeClass('search-toggle');
        });
        
        $(".top-bar-toggle").on('click', function(){
            $(".top-bar-collapse").slideToggle();
        });

	}());	
		
});


