<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

$tt_slides = "";

if (function_exists('rwmb_meta')) :
    $tt_slides = rwmb_meta('paprika_post_gallery','type=image_advanced');
endif;

$thumb_size = 'paprika-blog-thumbnail';
if(is_single()){
    $thumb_size = 'paprika-single-post-thumbnail';
}

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('post-wrapper'); ?>>
    <?php if ($tt_slides) : ?>
        <header class="featured-wrapper">
            <div class="post-thumbnail blog-gallery">
                <?php if(count($tt_slides) > 0) : ?>
                    <div class="carousel slide blog-carousel">
                        <div class="carousel-inner">
                            <?php 
                                $carousel_count = 1; 
                                foreach( $tt_slides as $slide ) : ?>
                                    <div class="item <?php if($carousel_count == 1) echo 'active'; ?>">
                                        
                                        <?php $images_src = wp_get_attachment_image_src( $slide['ID'], $thumb_size); ?>
                                        <img class="img-responsive" src="<?php echo esc_url($images_src[0]); ?>" alt="<?php get_the_title();?>">
                                        
                                        <?php if ( paprika_option( 'post-lightbox-visibility' )) : ?>
                                            <div class="post-overlay">
                                                <?php $tt_full_image = wp_get_attachment_image_src( $slide['ID'], 'full' ); ?>

                                                <a href="<?php echo esc_url( $tt_full_image[ 0 ] ); ?>" class="blog-popup" ><i class="fa fa-expand"></i></a>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php
                                $carousel_count++;
                                endforeach;
                            ?>
                        </div> <!-- .carousel-inner -->
                        
                        <!-- Controls -->
                        <a class="left carousel-control" href=".blog-carousel" data-slide="prev"><i class="fa fa-angle-left"></i></a>
                        <a class="right carousel-control" href=".blog-carousel" data-slide="next"><i class="fa fa-angle-right"></i></a>
                    </div> <!-- .blog-carousel -->

                <?php endif; ?> 
            </div> <!-- .blog-gallery -->

            <?php if (! is_single()) : ?>
                <ul class="post-meta list-inline">
                    <?php if ( paprika_option( 'tt-post-meta', 'post-author', TRUE ) ) : ?>
                        <li>
                        <span class="author vcard">
                            <i class="fa fa-user"></i><?php printf('<a class="url fn n" href="%1$s">%2$s</a>',
                                esc_url(get_author_posts_url(get_the_author_meta('ID'))),
                                esc_html(get_the_author())
                            ) ?>
                        </span>
                        </li>
                    <?php endif; ?>

                    <li>
                        <span class="post-comments">
                            <?php
                                comments_popup_link(
                                    esc_html__('0', 'materialize'),
                                    esc_html__('1', 'materialize'),
                                    esc_html__('%', 'materialize'), '',
                                    esc_html__('0', 'materialize')
                                ); 
                            ?>
                        </span>
                    </li>

                    <?php if(function_exists('paprika_get_post_views')) : ?>
                        <li>
                            <span class="post-view">
                                <i class="fa fa-eye"></i> <?php echo paprika_get_post_views(get_the_ID()) ?>
                            </span>
                        </li>
                    <?php endif; ?>
                </ul>
            <?php endif; ?>
        </header><!-- .entry-header -->
    <?php endif; ?> <!-- $tt_slides -->

    <div class="blog-content">
       <div class="entry-header">
           <?php 
               paprika_postmeta();
               the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
           ?>

           <?php if ( is_single() ) : 
               paprika_single_postmeta();
           endif; ?>
       </div><!-- /.entry-header -->

        <div class="entry-content">
            <?php 
                the_content( '<span class="readmore">' . esc_html__( 'Read More', 'paprika' ) . '</span>' );

                wp_link_pages(array(
                    'before'      => '<div class="page-pagination"><span class="page-links-title">' . esc_html__('Pages:', 'paprika') . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                ));
            ?>
        </div><!-- .entry-content -->
    </div><!-- /.blog-content -->
</article>