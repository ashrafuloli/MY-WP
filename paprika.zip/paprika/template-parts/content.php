<?php if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif; 

$thumb_size = 'paprika-blog-thumbnail';
$not_single = "";

if( is_single()){
    $thumb_size = 'paprika-sitcky-post-thumbnail';
    $not_single = ' not-single';
}

$post_class = array();
$post_class[] = 'post-wrapper';

if(is_sticky()){
	$post_class[] = 'sticky';
	$thumb_size = 'paprika-sitcky-post-thumbnail';
}

?>

<article id="post-<?php the_ID(); ?>" <?php post_class($post_class); ?>>
    <?php if ( has_post_thumbnail() ) : ?>
        <header class="featured-wrapper">
	        <div class="post-thumbnail">
	        	<?php do_action( 'paprika_before_post_thumbnail');
                    the_post_thumbnail($thumb_size, array('alt' => get_the_title(), 'class' => 'img-responsive'));
                ?>   
	            <?php do_action( 'paprika_after_post_thumbnail'); ?>
	        </div><!-- .post-thumbnail -->
        </header><!-- /.featured-wrapper -->
    <?php endif; ?>
    
    <div class="blog-content">
        <div class="entry-header">
       		<?php 
       			//post meta
       			paprika_postmeta(); 
       			
       			//post title
       			the_title( sprintf( '<h2 class="entry-title'.$not_single.'"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
       		
	       		if ( is_single() ) : 
					paprika_single_postmeta();
	            endif; 
            ?>

        </div><!-- /.entry-header -->

        <div class="entry-content">

			<?php 
				//post content
				the_content( '<span class="readmore">' . esc_html__( 'CONTINUE READING', 'paprika' ) . '</span>' );
                //post pagination
				wp_link_pages(array(
		            'before'      => '<div class="page-pagination"><span class="page-links-title">' . esc_html__('Pages:', 'paprika') . '</span>',
		            'after'       => '</div>',
		            'link_before' => '<span>',
		            'link_after'  => '</span>',
		        ));
			?>

	    </div><!-- .entry-content -->

        <?php if (is_single()): ?>
            <footer class="entry-footer">
				<div class="content-bottom-meta">
					<?php paprika_post_share_button(); ?>
					<br>
					<?php if( has_tag() ): ?>
						<div class="tag-in">
							<h3 class="tag-in-title">Tagged in</h3>
							<?php the_tags( '', '', ''); ?>
						</div>
					<?php endif; ?>
				</div>
            </footer>
        <?php endif; ?>

    </div><!-- /.blog-content -->
</article>