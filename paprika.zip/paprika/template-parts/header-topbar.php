<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;
?>

<div class="header-top-wrapper">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php if (paprika_option('header-contact')) : ?>
                    <div class="contact-info pull-left">
                        <?php echo wp_kses(paprika_option('header-contact', false, true), array(
                            'a'  => array(
                                'href'   => array(),
                                'title'  => array(),
                                'target' => array()
                            ),
                            'br' => array(),
                            'i'  => array('class' => array()),
                            'ul' => array('class' => array()),
                            'li' => array(),
                        )); ?>
                    </div>
                <?php endif; ?>

                <?php if (paprika_option('header-social-button')): ?>
                    <div class="social-links-wrap text-right pull-right">
                        <?php get_template_part('template-parts/social', 'icons');?>
                    </div> <!-- /social-links-wrap -->
                <?php endif ?>
            </div> <!-- .col-md-12 -->
        </div> <!-- .row -->
    </div> <!-- .container -->
</div> <!-- .header-top-wrapper -->