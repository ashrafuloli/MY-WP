<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

$video_mp4 = "";
$video_webm = "";
$video_ogv = "";
$embed_video = "";

if (function_exists('rwmb_meta')) :
    $video_mp4 = rwmb_meta( 'paprika_featured_mp4', 'type=file_input' );
    $video_webm = rwmb_meta( 'paprika_featured_webm', 'type=file_input' );
    $video_ogv = rwmb_meta( 'paprika_featured_ogv', 'type=file_input' );
    $embed_video = rwmb_meta( 'paprika_embed_video');
endif;

?>

<article id="post-<?php the_ID(); ?>" <?php post_class('post-wrapper'); ?>>
    <?php if ($embed_video || $video_mp4 || $video_webm || $video_ogv ) : ?>
        <header class="featured-wrapper">
            <?php if (function_exists('rwmb_meta')) :
                $video_mp4 = rwmb_meta( 'paprika_featured_mp4', 'type=file_input' );
                $video_webm = rwmb_meta( 'paprika_featured_webm', 'type=file_input' );
                $video_ogv = rwmb_meta( 'paprika_featured_ogv', 'type=file_input' );
                // $embed_video = rwmb_meta( 'paprika_embed_video', 'type=oembed' );
                $embed_video = rwmb_meta( 'paprika_embed_video');
                        
                if ( !empty($embed_video) or !empty($video_mp4) or !empty($video_webm) or !empty($video_ogv) ) : ?>
                    <div class="post-thumbnail blog-video">
                            <?php
                                if ($embed_video and (empty($video_mp4) or empty($video_webm) or empty($video_ogv))) :

                                    echo rwmb_meta( 'paprika_embed_video');

                                elseif (!empty($video_mp4) or !empty($video_webm) or !empty($video_ogv)) : ?>
                                    <video preload="auto" controls="controls">
                                        <?php if (!empty($video_mp4)) : ?>
                                            <source src="<?php echo esc_url($video_mp4); ?>" type="video/mp4"/>
                                        <?php endif; ?>

                                        <?php if (!empty($video_webm)) : ?>
                                            <source src="<?php echo esc_url($video_webm); ?>" type="video/webm"/>
                                        <?php endif; ?>

                                        <?php if (!empty($video_ogv)) : ?>
                                            <source src="<?php echo esc_url($video_ogv); ?>" type="video/ogv"/>
                                        <?php endif; ?>
                                    </video>
                                <?php 
                                endif; 
                            ?>
                    </div>
                <?php endif; 
            endif;
            ?>

        </header><!-- .entry-header -->

    <?php endif; ?> <!-- $embed_video -->

    <div class="blog-content">
        <div class="entry-header">
            <?php 
                paprika_postmeta();
                the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );    
            ?>
            
            <?php if ( is_single() ) : 
                paprika_single_postmeta();
            endif; ?>
        </div><!-- /.entry-header -->

        <div class="entry-content">
            <?php 
                the_content( '<span class="readmore">' . esc_html__( 'Read More', 'paprika' ) . '</span>' );

                wp_link_pages(array(
                    'before'      => '<div class="page-pagination"><span class="page-links-title">' . esc_html__('Pages:', 'paprika') . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                ));
            ?>
        </div><!-- .entry-content -->
    </div><!-- /.blog-content -->

</article>