	<!--homepage slider v2-->
	<div class="homepage-slider-v2">
		<div class="container">
			<div class="row">
				<div class="col-md-12 slider-v2-owl-carousel">
				
					<?php 
						$args  = array(
							'post_type'      => 'post',
							'post_status'    => 'publish'
						);
						
						if (paprika_option('post-source') == 'selected-post') {
							$args = wp_parse_args(
								array(
									'post__in' => paprika_option('post-lists'),
								)
							, $args );
						}

						if (paprika_option('post-source') == 'latest-post' || paprika_option('post-source') == 'category-post') {
							$args = wp_parse_args(
								array(
									'posts_per_page' => paprika_option('post-limit', false, 5),
								)
							, $args );
						}

						if (paprika_option('post-source') == 'category-post') {
							$args = wp_parse_args(
								array(
									'cat' => paprika_option('category-lists')
								)
							, $args );
						}
						
						$homepage_slider2 = new WP_Query( $args ); 
					?>
					
					<?php
						while( $homepage_slider2 -> have_posts() ) : $homepage_slider2 -> the_post();
						if( has_post_thumbnail() ) :
					?>
					
						<!--slide item-->
						<div class="slider-v2-wrapper">
							<div class="slider-v2-img">
								<?php the_post_thumbnail('paprika-slider-v2-thumbnail'); ?>
							</div>
							<div class="slider-v2-meta">
								<div class="entry-header">
									<ul class="entry-meta list-inline clearfix">
										<li>
											<?php echo get_the_category_list(esc_html_x(', ', 'Used between list items, there is a space after the comma.', 'paprika'));?>
										</li>
									</ul>
									<h2 class="entry-title">

										<a href="<?php the_permalink(); ?>">
											<?php echo wp_trim_words( get_the_title(), 3, '...' )?>
										</a>
									</h2>        
								</div>
							</div>

							<div class="slider-v2-wrapper-overlay"></div>
						</div><!--/.slide item-->
						
					<?php 
					endif;
					endwhile; 
					?>
					<?php wp_reset_postdata(); ?>
				
				</div>
			</div>
		</div>
	</div><!--/.homepage slider v2-->

	