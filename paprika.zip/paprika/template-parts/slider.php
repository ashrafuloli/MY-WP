<div class="homepage-slider">
	<div class="container">
		<div id="carousel-example-generic" class="carousel slide" data-ride="carousel">
			
			<!-- Wrapper for slides -->
			<div id="homepage-slider" class="carousel-inner" role="listbox">
			
				<?php 
					$args  = array(
						'post_type'      => 'post',
						'post_status'    => 'publish'
					);
					
					if (paprika_option('post-source') == 'selected-post') {
						$args = wp_parse_args(
							array(
								'post__in' => paprika_option('post-lists'),
							)
						, $args );
					}

					if (paprika_option('post-source') == 'latest-post' || paprika_option('post-source') == 'category-post') {
						$args = wp_parse_args(
							array(
								'posts_per_page' => paprika_option('post-limit', false, 5),
							)
						, $args );
					}

					if (paprika_option('post-source') == 'category-post') {
						$args = wp_parse_args(
							array(
								'cat' => paprika_option('category-lists')
							)
						, $args );
					}
					
					$homepage_slider = new WP_Query( $args ); 
				?>
				
				<?php while( $homepage_slider -> have_posts() ) : $homepage_slider -> the_post();
					if( has_post_thumbnail() ) : ?>
			
					<div class="item">
						<?php the_post_thumbnail('paprika-single-post-thumbnail'); ?>
						<div class="carousel-caption text-left">
							<p><?php echo get_the_category_list(esc_html_x(', ', 'Used between list items, there is a space after the comma.', 'paprika'));
							?></p>
							<h2><?php echo wp_trim_words( get_the_title(), 6, '...' )?></h2>
							<p><?php the_time( get_option( 'date_format' ) ); ?></p>
							<p>
								<?php
									comments_popup_link(
										esc_html__('No Comments', 'paprika'),
										esc_html__('One Comments', 'paprika'),
										esc_html__('% Comments', 'paprika'), '',
										esc_html__('Comments Disable', 'paprika')
									); 
								?>
							</p>
							<a href="<?php the_permalink(); ?>" class="btn btn-primary">READ MORE</a>
						</div>
						<div class="slider-overlay"></div>
					</div>
				<?php endif; 
				endwhile; ?>
				<?php wp_reset_postdata(); ?>
			</div>
			
			<!-- Controls -->
			<a class="left carousel-control" href="#carousel-example-generic" role="button" data-slide="prev">
				<span class="fa fa-arrow-left" aria-hidden="true"></span>
			</a>
			<a class="right carousel-control" href="#carousel-example-generic" role="button" data-slide="next">
				<span class="fa fa-arrow-right" aria-hidden="true"></span>
			</a>
		</div>
	</div>
</div>

