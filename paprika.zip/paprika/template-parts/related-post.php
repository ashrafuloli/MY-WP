<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;
?>

<div class="related-post-wrapper">

    <div class="related-pos-intro text-center">
        <h2><?php esc_html_e( 'You might also like', 'paprika' ); ?></h2>
    </div>

    <?php       
        $tt_post_cat = wp_get_object_terms( $post->ID, 'category', array('fields' => 'ids') );
        // arguments
        $args = array(
        'post_type' => 'post',
        'post_status' => 'publish',
        'posts_per_page' => 3, // you may edit this number
        'orderby' => 'rand',
        'tax_query' => array(
            array(
              'taxonomy' => 'category',
              'field' => 'id',
              'terms' => $tt_post_cat
            )
        ),
        'post__not_in' => array ($post->ID),
        );
        $related_post = new WP_Query( $args ); ?>

        <?php if ( $related_post->have_posts() ) : ?>

            <?php do_action('paprika_before_related_post');?>

            <div class="clearfix">
				<div class="row">
                <?php /* Start the Loop */ ?>
                <?php while ( $related_post->have_posts() ) : $related_post->the_post(); ?>
                    
						<div class="col-md-4 col-sm-6 col-xs-12">
							<div class="related-post">
								<?php
									echo get_the_post_thumbnail( get_the_ID(), 'paprika-related-post-thumb', array( 'class' => 'img-responsive', 'alt' => get_the_title()));
								?>
								<h3><a href="<?php the_permalink(); ?>"> <?php the_title(); ?></a></h3>
							</div>
						</div>
                    

                <?php endwhile; ?>
				</div>
            </div><!-- related-post -->

            <?php do_action('paprika_after_related_post');?>

        <?php endif; ?>

        <?php wp_reset_postdata(); 
    ?>
</div>