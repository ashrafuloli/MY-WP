<!-- Instagram photo -->
<?php 
	
	if( paprika_option('instagram-limit') == 4 ){
		$instagram_limit = 'instagram_four';
	}elseif( paprika_option('instagram-limit') == 8 ){
		$instagram_limit = 'instagram_eight';
	}elseif( paprika_option('instagram-limit') == 10 ){
		$instagram_limit = 'instagram_ten';
	}else{
		$instagram_limit = 'instagram_six';
	}
?>

<div class="instagram-feed">
	<a href="https://www.instagram.com/<?php echo paprika_option('instagram-user-name'); ?>" class="btn-instagram">
		<?php echo esc_html__('FOLLOW ME @ INSTAGRAM', 'paprika'); ?>
	</a>
	<div id="myinstafeed" class="<?php echo $instagram_limit; ?>">
		 <!-- html code injected via javascript -->
	</div>
</div><!-- /.instagram photo -->