<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('post-wrapper'); ?>>
    <header class="entry-header">
        <?php if (function_exists('rwmb_meta')) :
            $quote = rwmb_meta( 'paprika_qoute' );
            $author_url = rwmb_meta( 'paprika_qoute_author_url' );

            if ($quote) : ?>
            
                <div class="post-thumbnail blog-quote">
                    <blockquote>
                        <p><?php echo esc_html($quote);?></p>
                        
                        <?php 
                            if ($author_url) : ?>
                                <small><a href="<?php echo esc_url($author_url)?>"><?php echo esc_html(rwmb_meta( 'paprika_qoute_author' )); ?></a></small>
                                <?php else : ?>
                                    <small><?php echo esc_html(rwmb_meta( 'paprika_qoute_author' )); ?></small>
                                <?php 
                            endif;
                        ?>
                        
                    </blockquote>
                </div>
            <?php endif; 
        endif;
        ?>
    </header><!-- .entry-header -->

    <div class="blog-content">
        <div class="entry-header">
            <?php 
                //post meta
                paprika_postmeta(); 
                //post title
                the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' ); 
            ?>

            <?php if ( is_single() ) : 
                paprika_single_postmeta();
            endif; ?>

        </div><!-- /.entry-header -->

        <div class="entry-content">
            <?php 
                if (is_single() || !has_excerpt()) :
                    the_content( '<span class="readmore">' . esc_html__( 'Read More', 'paprika' ) . '</span>' );
                else :
                    the_excerpt();
                endif;

                wp_link_pages(array(
                    'before'      => '<div class="page-pagination"><span class="page-links-title">' . esc_html__('Pages:', 'paprika') . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                ));
            ?>
        </div><!-- .entry-content -->
    </div><!-- /.blog-content -->

</article>