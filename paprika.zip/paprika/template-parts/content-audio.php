<?php
    if ( ! defined( 'ABSPATH' ) ) :
        exit; // Exit if accessed directly
    endif;

    $audio_mp3 = "";
    $audio_ogg = "";
    $audio_wav = "";
    $embed_audio = "";

    if (function_exists('rwmb_meta')) :
        $audio_mp3 = rwmb_meta( 'paprika_featured_mp3', 'type=file_input' );
        $audio_ogg = rwmb_meta( 'paprika_featured_ogg', 'type=file_input' );
        $audio_wav = rwmb_meta( 'paprika_featured_wav', 'type=file_input' );
        $embed_audio = rwmb_meta( 'paprika_embed_audio', 'type=oembed' );
    endif;
?>

<article id="post-<?php the_ID(); ?>" <?php post_class('post-wrapper'); ?>>
    <?php if ($embed_audio || $audio_mp3 || $audio_ogg || $audio_wav ) : ?>
        <header class="featured-wrapper audio-header">

        
            <?php if (function_exists('rwmb_meta')) :
                $audio_mp3 = rwmb_meta( 'paprika_featured_mp3', 'type=file_input' );
                $audio_ogg = rwmb_meta( 'paprika_featured_ogg', 'type=file_input' );
                $audio_wav = rwmb_meta( 'paprika_featured_wav', 'type=file_input' );
                $embed_audio = rwmb_meta( 'paprika_embed_audio', 'type=oembed', true );
                        
                if ( !empty($embed_audio) or !empty($audio_mp3) or !empty($audio_ogg) or !empty($audio_wav) ) : ?>
                    <div class="post-thumbnail blog-audio">
                        
                        <?php  
                            if ( !empty($audio_mp3) or !empty($audio_ogg) or !empty($audio_wav) ){?>
                                <audio preload="auto" controls="controls">

                                    <?php if (!empty($audio_mp3)) : ?>
                                        <source src="<?php echo esc_url($audio_mp3); ?>" type="audio/mpeg"/>
                                    <?php endif; ?>

                                    <?php if (!empty($audio_ogg)) : ?>
                                        <source src="<?php echo esc_url($audio_ogg); ?>" type="audio/ogg"/>
                                    <?php endif; ?>

                                    <?php if (!empty($audio_wav)) : ?>
                                        <source src="<?php echo esc_url($audio_wav); ?>" type="audio/wav"/>
                                    <?php endif; ?>
                                    
                                </audio>
                            <?php }else{
                                echo rwmb_meta( 'paprika_embed_audio', 'type=oembed' );
                            }
                        ?>

                    </div> <!-- .blog-audio -->
                <?php endif;
            endif;
            ?>

        </header><!-- .entry-header -->
    <?php endif; ?> <!-- $embed_audio -->

    <div class="blog-content">
        <div class="entry-header">
            <?php 
                paprika_postmeta();
                the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );
            ?>

            <?php if ( is_single() ) : 
                paprika_single_postmeta();
            endif; ?>
        </div><!-- /.entry-header -->

        <div class="entry-content">

            <?php 
                //post content
                the_content( '<span class="readmore">' . esc_html__( 'CONTINUE READING', 'paprika' ) . '</span>' );
                //post pagination
                wp_link_pages(array(
                    'before'      => '<div class="page-pagination"><span class="page-links-title">' . esc_html__('Pages:', 'paprika') . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                ));
            ?>

        </div><!-- .entry-content -->

        <?php if (is_single()): ?>
            <footer class="entry-footer">

                <div class="content-bottom-meta">
                    <?php paprika_post_share_button(); ?>
                    <br>
                    <?php if( has_tag() ): ?>
                        <div class="tag-in">
                            <h3 class="tag-in-title">Tagged in</h3>
                            <?php the_tags( '', '', ''); ?>
                        </div>
                    <?php endif; ?>
                </div>

            </footer>
        <?php endif; ?>
    </div><!-- /.blog-content -->
</article>