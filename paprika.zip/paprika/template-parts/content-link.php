<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;
?>
<article id="post-<?php the_ID(); ?>" <?php post_class('post-wrapper'); ?>>
    <header class="entry-header">
        <?php if (function_exists('rwmb_meta')) :
            $a_text = rwmb_meta( 'paprika_link_text' );
            $a_href = rwmb_meta( 'paprika_link', 'type=url' );
            $a_target = rwmb_meta( 'paprika_link_target' );
            $a_title = rwmb_meta( 'paprika_link_title' );

            if ($a_href) : ?>
            
                <div class="post-thumbnail blog-link">
                    <a href="<?php echo esc_url($a_href); ?>" title="<?php echo esc_attr($a_title); ?>" target="<?php echo esc_attr($a_target); ?>">
                        <?php 
                            if ($a_text) :
                                echo esc_html($a_text);
                            else : 
                                echo esc_html($a_href);
                            endif; 
                        ?>
                    </a>
                </div>
            <?php endif; 
        endif;
        ?>
    </header><!-- .entry-header -->

    <div class="blog-content">
        <div class="entry-header">
            <?php 
                paprika_postmeta();
                the_title( sprintf( '<h2 class="entry-title"><a href="%s" rel="bookmark">', esc_url( get_permalink() ) ), '</a></h2>' );    
            ?>
            
            <?php if ( is_single() ) : 
                paprika_single_postmeta();
            endif; ?>
        </div><!-- /.entry-header -->

        <div class="entry-content">
            <?php 
                the_content( '<span class="readmore">' . esc_html__( 'Read More', 'paprika' ) . '</span>' );

                wp_link_pages(array(
                    'before'      => '<div class="page-pagination"><span class="page-links-title">' . esc_html__('Pages:', 'paprika') . '</span>',
                    'after'       => '</div>',
                    'link_before' => '<span>',
                    'link_after'  => '</span>',
                ));
            ?>
        </div><!-- .entry-content -->
    </div><!-- /.blog-content -->
</article>