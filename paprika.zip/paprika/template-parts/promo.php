

<!--homepage promotion-->
<div class="home-page-promo">
	<div class="container">
		<div class="row">
		
			<?php $about_us_photo = esc_url(paprika_option('about-us-photo', 'url')); 
			if ($about_us_photo) : ?>
			<!--promotion item one-->
			<div class="col-sm-4">
				<a href="<?php echo paprika_option('about-url'); ?>">
					<div class="promo-item">
						<div class="promo-overlay"></div>
						<div class="promo-thumb">
							<img class="img-responsive" src="<?php echo esc_url(paprika_option('about-us-photo', 'url')); ?>" alt="<?php esc_attr('About us photo', 'paprika'); ?>" />
						</div>
						
						<?php $about_us_btn = paprika_option('about-me-title'); 
						if ($about_us_btn) : ?>
						<div class="promo-btn">
							<a href="<?php echo paprika_option('about-url'); ?>" >
								<?php echo paprika_option('about-me-title'); ?>
								<i class="fa fa-arrow-right"></i>
							</a>
						</div>
						<?php endif; ?>
					</div>
				</a>
			</div>
			<?php endif; ?>
			
			<?php $instagram_photo = esc_url(paprika_option('instagram-photo', 'url')); 
			if ( $instagram_photo ) : ?>
			<!--promotion item one-->
			<div class="col-sm-4">
				<a href="<?php echo paprika_option('instagram-url'); ?>">
					<div class="promo-item">
						<div class="promo-overlay"></div>
						<div class="promo-thumb">
							<img src="<?php echo esc_url(paprika_option('instagram-photo', 'url')); ?>" alt="" />
						</div>
						
						<?php $instagram_title = paprika_option('instagram-btn-text'); 
							if ( $instagram_title ) :
						?>
						<div class="promo-btn">
							<a href="<?php echo paprika_option('instagram-url'); ?>" >
								<?php echo paprika_option('instagram-btn-text'); ?>
								<i class="fa fa-arrow-right"></i>
							</a>
						</div>
						<?php endif; ?>
					</div>
				</a>
			</div>
			<?php endif; ?>
			
			<?php $custom_photo = esc_url(paprika_option('instagram-photo', 'url')); 
			if ( $custom_photo ) : ?>
			<!--promotion item one-->
			<div class="col-sm-4">
				<a href="<?php echo paprika_option('custom-link-photo-url'); ?>">
					<div class="promo-item">
						<div class="promo-overlay"></div>
						<div class="promo-thumb">
							<img src="<?php echo esc_url(paprika_option('custom-link-photo', 'url')); ?>" alt="" />
						</div>
						<?php $custom_title = paprika_option('custom-link-photo-btn-text'); 
						if( $custom_title ) : ?>
						<div class="promo-btn">
							<a href="<?php echo paprika_option('custom-link-photo-url'); ?>" >
								<?php echo paprika_option('custom-link-photo-btn-text'); ?>
								<i class="fa fa-arrow-right"></i>
							</a>
						</div>
						<?php endif; ?>
					</div>
				</a>
			</div>
			<?php endif; ?>
		
		</div>
	</div>
</div><!--/.homepage promotion-->

