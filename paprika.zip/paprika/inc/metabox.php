<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Register meta boxes
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if (! function_exists('paprika_register_meta_boxes')) :

	function paprika_register_meta_boxes( $meta_boxes ) {
		/**
		 * Prefix of meta keys (optional)
		 */

		$prefix = 'paprika_';

		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for post format quote
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

		$meta_boxes[] = array(
			'id' => 'tt-post-format-quote',

			// Meta box title - Will appear at the drag and drop handle bar. Required.
			'title' => esc_html__( 'Post Quote Settings', 'paprika' ),

			// Post types, accept custom post types as well - DEFAULT is array('post'). Optional.
			'pages' => array( 'post'),

			// Where the meta box appear: normal (default), advanced, side. Optional.
			'context' => 'normal',

			// Order of meta box: high (default), low. Optional.
			'priority' => 'high',

			// Auto save: true, false (default). Optional.
			'autosave' => true,

			// List of meta fields
			'fields' => array(
				array(
					// Field name - Will be used as label
					'name'  => esc_html__( 'Qoute Text', 'paprika' ),
					// Field ID, i.e. the meta key
					'id'    => "{$prefix}qoute",
					'desc'  => esc_html__( 'Write Your Qoute Here', 'paprika' ),
					'type'  => 'textarea',
					// Default value (optional)
					'std'   => ''
				),
				array(
					// Field name - Will be used as label
					'name'  => esc_html__( 'Qoute Author/Company', 'paprika' ),
					// Field ID, i.e. the meta key
					'id'    => "{$prefix}qoute_author",
					'desc'  => esc_html__( 'Write Qoute Author or Company name', 'paprika' ),
					'type'  => 'text',
					// Default value (optional)
					'std'   => ''
				),
				array(
					// Field name - Will be used as label
					'name'  => esc_html__( 'Author/Company URL', 'paprika' ),
					// Field ID, i.e. the meta key
					'id'    => "{$prefix}qoute_author_url",
					'desc'  => esc_html__( 'Write Qoute Author or Company URL', 'paprika' ),
					'type'  => 'text',
					// Default value (optional)
					'std'   => ''
				)
			)
		);


		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for post format link
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'tt-post-format-link',
			'title' => esc_html__( 'Post Link Settings', 'paprika' ),
			'pages' => array( 'post'),
			'context' => 'normal',
			'priority' => 'high',
			'autosave' => true,
			'fields' => array(
				array(
					'name'  => esc_html__( 'Link text', 'paprika' ),
					'id'    => "{$prefix}link_text",
					'desc'  => esc_html__( 'Write Your Link Text, leave blank to show only url', 'paprika' ),
					'type'  => 'text',
					'std'   => ''
				),

				array(
					'name'  => esc_html__( 'Link URL*', 'paprika' ),
					'id'    => "{$prefix}link",
					'desc'  => esc_html__( 'Write Your Link, e.g: http://yourlink.com', 'paprika' ),
					'type'  => 'text',
					'std'   => ''
				),

				array(
					'name'     => esc_html__( 'Link title', 'paprika' ),
					'id'       => "{$prefix}link_title",
					'desc'     => esc_html__( 'Write link title, appear as link title attribute', 'paprika' ),
					'type'     => 'text',
					'std'      => ''
				),

				array(
					'name'     => esc_html__( 'Link target', 'paprika' ),
					'id'       => "{$prefix}link_target",
					'type'     => 'select',
					'options'  => array(
						'_self' => esc_html__( 'Self', 'paprika' ),
						'_blank' => esc_html__( 'New Window', 'paprika' )
					),
					'std'         => 'self'
				)
			)
		);

		
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for post format audio
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'tt-post-format-audio',
			'title' => esc_html__( 'Post Audio Settings', 'paprika' ),
			'pages' => array( 'post'),
			'context' => 'normal',
			'priority' => 'high',
			'autosave' => true,
			'fields' => array(
				array(
					'name'  => esc_html__( 'Featured Audio (.mp3)', 'paprika' ),
					'id'    => "{$prefix}featured_mp3",
					'desc'  => esc_html__( 'Upload Audio like: your-file-name.mp3', 'paprika' ),
					'type'  => 'file_input',
					'std'   => ''
				),

				array(
					'name'  => esc_html__( 'Featured Audio (.ogg)', 'paprika' ),
					'id'    => "{$prefix}featured_ogg",
					'desc'  => esc_html__( 'Upload Audio like: your-file-name.ogg', 'paprika' ),
					'type'  => 'file_input',
					'std'   => ''
				),

				array(
					'name'  => esc_html__( 'Featured Audio (.wav)', 'paprika' ),
					'id'    => "{$prefix}featured_wav",
					'desc'  => esc_html__( 'Upload Audio like: your-file-name.wav', 'paprika' ),
					'type'  => 'file_input',
					'std'   => ''
				),

				array(
					'name'  => esc_html__( 'Embed Audio', 'paprika' ),
					'id'    => "{$prefix}embed_audio",
					'desc'  => esc_html__( 'Input URL for sounds, audios from Youtube, Soundcloud and all supported sites by WordPress, Supported list: http://codex.wordpress.org/Embeds', 'paprika' ),
					'type'  => 'oembed',
					'std'   => null,
				)
			)
		);


		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for post format video
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'tt-post-format-video',
			'title' => esc_html__( 'Post Video Settings', 'paprika' ),
			'pages' => array( 'post'),
			'context' => 'normal',
			'priority' => 'high',
			'autosave' => true,
			'fields' => array(
				array(
					'name'  => esc_html__( 'Featured Video (.mp4)', 'paprika' ),
					'id'    => "{$prefix}featured_mp4",
					'desc'  => esc_html__( 'Upload Video like: your-file-name.mp4', 'paprika' ),
					'type'  => 'file_input',
					'std'   => ''
				),

				array(
					'name'  => esc_html__( 'Featured Video (.webm)', 'paprika' ),
					'id'    => "{$prefix}featured_webm",
					'desc'  => esc_html__( 'Upload Video like: your-file-name.webm', 'paprika' ),
					'type'  => 'file_input',
					'std'   => ''
				),

				array(
					'name'  => esc_html__( 'Featured Video (.ogv)', 'paprika' ),
					'id'    => "{$prefix}featured_ogv",
					'desc'  => esc_html__( 'Upload Video like: your-file-name.ogv', 'paprika' ),
					'type'  => 'file_input',
					'std'   => ''
				),

				array(
					'name'  => esc_html__( 'Embed Video', 'paprika' ),
					'id'    => "{$prefix}embed_video",
					'desc'  => esc_html__( 'Enter embed code here.', 'paprika' ),
					//'type'  => 'oembed',
					'type'  => 'textarea',
					'std'   => ''
				)	
			)
		);


		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for post format gallery
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'tt-post-format-gallery',
			'title' => esc_html__( 'Post Gallery Settings', 'paprika' ),
			'pages' => array( 'post'),
			'context' => 'normal',
			'priority' => 'high',
			'autosave' => true,
			'fields' => array(
				array(
					'name'             => esc_html__( 'Upload image from media library', 'paprika' ),
					'id'               => "{$prefix}post_gallery",
					'type'             => 'image_advanced',
					'max_file_uploads' => 6,
				)			
			)
		);



		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for portfolio gallery
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'portfolio-gallery-settings',
			'title' => esc_html__( 'Portfolio Gallery', 'paprika' ),
			'pages' => array('tt-portfolio'),
			'context' => 'side',
			'priority' => 'low',
			'fields' => array(
				
				array(
					'name'             => esc_html__( 'Portfolio Gallery', 'paprika' ),
					'id'               => "{$prefix}portfolio_gallery",
					'type'             => 'image_advanced',
					'max_file_uploads' => 5,
					'desc'  => esc_html__( 'Upload gallery image to show gallery on single portfolio', 'paprika' ),
				)
			)
		);


		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for portfolio
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'portfolio-meta-settings',
			'title' => esc_html__( 'Portfolio Settings', 'paprika' ),
			'pages' => array('tt-portfolio'),
			'context' => 'normal',
			'priority' => 'high',
			'fields' => array(
				array(
					'name'        => esc_html__( 'Select single portfolio layout', 'paprika' ),
					'id'          => "{$prefix}portfolio_single_layout",
					'type'        => 'select_advanced',
					'options'     => array(
						'portfolio-layout-default' => esc_html__( 'Default layout', 'paprika' ),
						'portfolio-layout-sidebar' => esc_html__( 'Details on sidebar', 'paprika' ),
					),
					'multiple'    => false,
					'std'         => 'portfolio-layout-default', // Default value, optional
					'placeholder' => esc_html__( 'Select a layout', 'paprika' )
				),

				array(
					'name' 	=> esc_html__( 'Divider', 'paprika' ),
					'id'  	=> "{$prefix}portfolio_divider_one",
					'type' 	=> 'divider'
				),
				
                array(
					'name'    	=> esc_html__( 'Portfolio Overview', 'paprika' ),
					'id'   => "{$prefix}portfolio_overview",
					'type'    	=> 'text_list',
					// Number of rows
					'rows'    	=> 1,
					'options' 	=> array(
						'Label' => esc_html__( 'Label', 'paprika' ),
						'Value' => esc_html__( 'Value', 'paprika' )
					),
					'clone'		=> true,
				),

				array(
					'name' 	=> esc_html__( 'Divider', 'paprika' ),
					'id'  	=> "{$prefix}portfolio_divider_three",
					'type' 	=> 'divider'
				),

				array(
					'name'    	=> esc_html__( 'Show/hide social share button', 'paprika' ),
					'id'   		=> "{$prefix}portfolio_share",
					'type'    	=> 'radio',
					'options' 	=> array(
						'show_share' => esc_html__( 'Show', 'paprika' ),
						'hide_share' => esc_html__( 'Hide', 'paprika' )
					),
					'std'		=> 'show_share'
				),

				array(
					'name' 	=> esc_html__( 'Divider', 'paprika' ),
					'id'  	=> "{$prefix}portfolio_divider_four",
					'type' 	=> 'divider'
				),

				array(
					'name'    	=> esc_html__( 'Portfolio link text', 'paprika' ),
					'id'   		=> "{$prefix}portfolio_link_text",
					'type'    	=> 'text',
					'desc'     	=> esc_html__( 'Enter link text', 'paprika' ),
					
				),
				array(
					'name'    	=> esc_html__( 'Portfolio link', 'paprika' ),
					'id'   		=> "{$prefix}portfolio_link",
					'type'    	=> 'text',
					'desc'     	=> esc_html__( 'Enter portfolio link', 'paprika' ),
					
				)
			)
		);


		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for page logo
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'page-logo-settings',
			'title' => esc_html__( 'Page Logo Settings', 'materialize' ),
			'pages' => array( 'page', 'tt-portfolio'),
			'context' => 'normal',
			'priority' => 'high',
			'fields' => array(

				// logo
				array(
					'name'             => esc_html__( 'Page Logo', 'materialize' ),
					'id'               => "{$prefix}page_logo",
					'type'             => 'image_advanced',
					'max_file_uploads' => 1,
					'desc'  => esc_html__( 'This logo option only for this page, dimension: 210px &times; 50px', 'materialize' ),
				),

				// logo sticky
				array(
					'name'             => esc_html__( 'Page sticky Logo ', 'materialize' ),
					'id'               => "{$prefix}page_sticky_logo",
					'type'             => 'image_advanced',
					'max_file_uploads' => 1,
					'desc'  => esc_html__( 'This logo option only for this page, dimension: 210px &times; 50px', 'materialize' ),
				),

				// mobile logo
				array(
					'name'             => esc_html__( 'Page Mobile Logo', 'materialize' ),
					'id'               => "{$prefix}page_mobile_logo",
					'type'             => 'image_advanced',
					'max_file_uploads' => 1,
					'desc'  => esc_html__( 'This logo option only for this page, dimension: 210px &times; 50px', 'materialize' ),
				),

				// mobile logo
				array(
					'name'             => esc_html__( 'Page Mobile Sticky Logo', 'materialize' ),
					'id'               => "{$prefix}page_mobile_sticky_logo",
					'type'             => 'image_advanced',
					'max_file_uploads' => 1,
					'desc'  => esc_html__( 'This logo option only for this page, dimension: 210px &times; 50px', 'materialize' ),
				)
			)
		);


		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for page header
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'page-meta-settings',
			'title' => esc_html__( 'Page Settings', 'paprika' ),
			'pages' => array( 'page', 'tt-portfolio'),
			'context' => 'normal',
			'priority' => 'high',
			'fields' => array(

				// header visibility option
				array(
					'name'        => esc_html__( 'Enable/Disable Page Header', 'paprika' ),
					'id'          => "{$prefix}page_header_visibility",
					'type'        => 'select_advanced',
					// Array of 'value' => 'Label' pairs for select box
					'options'     => array(
						'header-section-show' => esc_html__( 'Header Section Show', 'paprika' ),
						'header-section-hide' => esc_html__( 'Header Section Hide', 'paprika' )
					),
					// Default selected value
					'std'         => 'header-section-show',
					// Placeholder
					'placeholder' => esc_html__( 'Select header visibility option', 'paprika' )
				),

				array(
					'name'             => esc_html__( 'Subtitle', 'paprika' ),
					'id'               => "{$prefix}page_subtitle",
					'type'             => 'text',
					'desc'  		   => esc_html__( 'Enter page subtitle', 'paprika' ),
				),

				// Divider
				array(
					'name'             => esc_html__( 'Divider', 'paprika' ),
					'id'               => "{$prefix}breadcumb_divider_one",
					'type'             => 'divider'
				),

				// Section padding
				array(
					'name'             => esc_html__( 'Padding top', 'paprika' ),
					'id'               => "{$prefix}header_padding_top",
					'type'             => 'text',
					'desc'  		   => esc_html__( 'Enter page header section top padding in px', 'paprika' ),
				),

				array(
					'name'             => esc_html__( 'Padding bottom', 'paprika' ),
					'id'               => "{$prefix}header_padding_bottom",
					'type'             => 'text',
					'desc'  => esc_html__( 'Enter page header section bottom padding in px', 'paprika' ),
				),

				// Divider
				array(
					'name'             => esc_html__( 'Divider', 'paprika' ),
					'id'               => "{$prefix}breadcumb_divider_two",
					'type'             => 'divider'
				),

				// Background image
				array(
					'name'             => esc_html__( 'Background image', 'paprika' ),
					'id'               => "{$prefix}page_header_image",
					'type'             => 'image_advanced',
					'max_file_uploads' => 1,
					'desc'  => esc_html__( 'Upload background image, dimension: 1920px x 450px', 'paprika' ),
				),

				// Parallax background
				array(
					'name'             	=> esc_html__( 'Parallax background', 'paprika' ),
					'id'               	=> "{$prefix}parallax_header_image",
					'type'             	=> 'radio',
					'options'     		=> array(
						'parallax_header_bg' => esc_html__( 'Enable', 'paprika' ),
						'default_header_bg' => esc_html__( 'Disable', 'paprika' )
					),
					'std'				=> 'default_header_bg',
					'desc'  => esc_html__( 'Select parallax background option', 'paprika' ),
				),

				// Background overlay option
				array(
					'name'             	=> esc_html__( 'Enable background overlay color', 'paprika' ),
					'id'               	=> "{$prefix}background_overlay",
					'type'             	=> 'radio',
					'options'     		=> array(
						'bg_overlay_enable' => esc_html__( 'Enable', 'paprika' ),
						'bg_overlay_disable' => esc_html__( 'Disable', 'paprika' )
					),
					'std'				=> 'bg_overlay_enable',
					'desc'  => esc_html__( 'Select background overlay option', 'paprika' ),
				),

				// Background color
				array(
					'name'             => esc_html__( 'Background color', 'paprika' ),
					'id'               => "{$prefix}page_header_color",
					'type'             => 'color',
					'desc'  => esc_html__( 'Select backgroud color if do not like to use background image', 'paprika' ),
				),

				// title color
				array(
					'name'             => esc_html__( 'Title color', 'paprika' ),
					'id'               => "{$prefix}header_content_color",
					'type'             => 'color',
					'desc'  => esc_html__( 'Select content color if needed', 'paprika' ),
				),

				// Divider
				array(
					'name'             => esc_html__( 'Divider', 'paprika' ),
					'id'               => "{$prefix}breadcumb_divider_three",
					'type'             => 'divider'
				),

				// Content alignment
				array(
					'name'        => esc_html__( 'Content alignment', 'paprika' ),
					'id'          => "{$prefix}breadcrumb_content_alignment",
					'type'        => 'select_advanced',
					// Array of 'value' => 'Label' pairs for select box
					'options'     => array(
						'text-center' => esc_html__( 'Content center', 'paprika' ),
						'text-left' => esc_html__( 'Content left', 'paprika' ),
						'text-right' => esc_html__( 'Content right', 'paprika' ),
						'title-left' => esc_html__( 'Title left', 'paprika' ),
						'title-right' => esc_html__( 'Title Right', 'paprika' )
					),
					// Default selected value
					'std'         => 'text-center',
					// Placeholder
					'placeholder' => esc_html__( 'Select breadcrumb alignment', 'paprika' ),
				),

				// Divider
				array(
					'name'             => esc_html__( 'Divider', 'paprika' ),
					'id'               => "{$prefix}breadcumb_divider_four",
					'type'             => 'divider'
				),

				// Hide breadcrumb
				array(
					'name'             	=> esc_html__( 'Show/hide breadcrumb', 'paprika' ),
					'id'               	=> "{$prefix}page_breadcrumb_show",
					'type'             	=> 'radio',
					'options'     		=> array(
						'page_breadcrumb_show' => esc_html__( 'Show', 'paprika' ),
						'page_breadcrumb_hide' => esc_html__( 'Hide', 'paprika' )
					),
					'std'				=> 'page_breadcrumb_hide',
					'desc'  => esc_html__( 'Select breadcrumb show/hide option', 'paprika' ),
				),

				// Divider
				array(
					'name'             => esc_html__( 'Divider', 'paprika' ),
					'id'               => "{$prefix}breadcumb_divider_five",
					'type'             => 'divider'
				),

				// Page Header Margin Bottom
				array(
					'name'             => esc_html__( 'Page Header Margin Bottom', 'paprika' ),
					'id'               => "{$prefix}page_header_margin_bottom",
					'type'             => 'text',
					'desc'  => esc_html__( 'Enter margin bottom value in px', 'paprika' ),
				)
			)
		);



		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for footer style
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'page-footer-style',
			'title' => esc_html__( 'Page Footer Styles', 'paprika' ),
			'pages' => array( 'page'),
			'context' => 'side',
			'priority' => 'low',
			'fields' => array(
				array(
					'name'        => esc_html__( 'Footer style', 'paprika' ),
					'id'          => "{$prefix}footer_style",
					'type'        => 'select_advanced',
					// Array of 'value' => 'Label' pairs for select box
					'options'     => array(
						'inherit-theme-option' => esc_html__( 'Inherit from theme option', 'paprika' ),
						'footer-default' => esc_html__( 'Footer default', 'paprika' ),
						'footer-three-column' => esc_html__( 'Footer three column', 'paprika' ),
						'footer-four-column' => esc_html__( 'Footer four column', 'paprika' )
					),
					// Default selected value
					'std'         => 'inherit-theme-option',
					// Placeholder
					'placeholder' => esc_html__( 'Select footer style', 'paprika' ),
					'desc'     => esc_html__( 'This settings apply only for this page', 'paprika' )
				)
			)
		);


		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for header topbar
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'page-header-topbar',
			'title' => esc_html__( 'Page Header Topbar', 'paprika' ),
			'pages' => array( 'page', 'tt-portfolio'),
			'context' => 'side',
			'priority' => 'low',
			'fields' => array(
				array(
					'name'        => esc_html__( 'Header topbar', 'paprika' ),
					'id'          => "{$prefix}header_topbar",
					'type'        => 'select_advanced',
					// Array of 'value' => 'Label' pairs for select box
					'options'     => array(
						'inherit-theme-option' => esc_html__( 'Inherit from theme option', 'paprika' ),
						'header-topbar-show' => esc_html__( 'Header topbar show', 'paprika' ),
						'header-topbar-hide' => esc_html__( 'Header topbar hide', 'paprika' )
					),
					// Default selected value
					'std'         => 'inherit-theme-option',
					// Placeholder
					'placeholder' => esc_html__( 'Select header topbar', 'paprika' ),
				)
			)
		);


		
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Meta for member post type
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'member-meta-settings',
			'title' => esc_html__( 'Team Member Settings', 'paprika' ),
			'pages' => array( 'tt-member'),
			'fields' => array(
				array(
					'name'     => esc_html__( 'Member Designation', 'paprika' ),
					'id'       => "{$prefix}member_designaion",
					'desc'     => esc_html__( 'Enter member designation', 'paprika' ),
					'type'     => 'text'
				),
				
				array(
					'name'     => esc_html__( 'Educational Qualification', 'paprika' ),
					'id'       => "{$prefix}educational_qualification",
					'desc'     => esc_html__( 'Enter educational qualification', 'paprika' ),
					'type'     => 'wysiwyg',
					'options'  => array(
						'editor_height' => 100
					)
				),

				array(
					'name'     => esc_html__( 'Address', 'paprika' ),
					'id'       => "{$prefix}member_address",
					'desc'     => esc_html__( 'Enter member address', 'paprika' ),
					'type'     => 'wysiwyg',
					'options'  => array(
						'editor_height' => 100
					)
				)
			)
		);

		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		// Member social settings
		//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
		$meta_boxes[] = array(
			'id' => 'member-social-settings',
			'title' => esc_html__( 'Member Social Settings', 'paprika' ),
			'pages' => array( 'tt-member'),
			'fields' => array(
				array(
					'name'     => esc_html__( 'Facebook Link', 'paprika' ),
					'id'       => "{$prefix}facebook_link",
					'desc'     => esc_html__( 'Enter facebook page or profile link', 'paprika' ),
					'type'     => 'text'
				),
				array(
					'name'     => esc_html__( 'Twitter Link', 'paprika' ),
					'id'       => "{$prefix}twitter_link",
					'desc'     => esc_html__( 'Enter twitter profile link', 'paprika' ),
					'type'     => 'text'
				),
				array(
					'name'     => esc_html__( 'Google Plus Link', 'paprika' ),
					'id'       => "{$prefix}google_plus_link",
					'desc'     => esc_html__( 'Enter google plus profile or page link', 'paprika' ),
					'type'     => 'text'
				),
				array(
					'name'     => esc_html__( 'Linkedin Link', 'paprika' ),
					'id'       => "{$prefix}linkedin_link",
					'desc'     => esc_html__( 'Enter linkedin profile link', 'paprika' ),
					'type'     => 'text'
				),
				array(
					'name'     => esc_html__( 'Flickr Link', 'paprika' ),
					'id'       => "{$prefix}flickr_link",
					'desc'     => esc_html__( 'Enter flickr profile link', 'paprika' ),
					'type'     => 'text'
				),
				array(
					'name'     => esc_html__( 'Youtube Link', 'paprika' ),
					'id'       => "{$prefix}youtube_link",
					'desc'     => esc_html__( 'Enter youtube channel link', 'paprika' ),
					'type'     => 'text'
				)
			)
		);

		return $meta_boxes;
	}

	add_filter( 'rwmb_meta_boxes', 'paprika_register_meta_boxes' );

endif;