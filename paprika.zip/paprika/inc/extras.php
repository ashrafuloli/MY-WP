<?php

if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Adds custom classes to the array of body classes.
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if ( ! function_exists( 'paprika_body_classes' ) ) :

	function paprika_body_classes( $classes ) {
		
		// footer style classes
		if (function_exists('rwmb_meta')) :
			$page_footer = rwmb_meta('paprika_footer_style');
			if ($page_footer == 'footer-default') :
				$classes[] = 'footer-default';
			elseif($page_footer == 'footer-three-column') :
				$classes[] = 'footer-three-column';
			elseif($page_footer == 'footer-four-column') :
				$classes[] = 'footer-four-column';
			elseif($page_footer == 'footer-onepage') :
				$classes[] = 'footer-onepage';
			else :
				$classes[] = paprika_option('footer-style', false, 'header-default');
			endif;
		endif;

		if (function_exists('rwmb_meta')) :
			$header_page_topbar = rwmb_meta('paprika_header_topbar');
			$header_option = paprika_option('header-top-visibility', false, false);

			if ($header_page_topbar == 'header-topbar-show' || $header_page_topbar == 'inherit-theme-option' && $header_option == true) :
				$classes[] = 'has-header-topbar';
			endif;
		endif;

		if (paprika_option('search-visibility', false, true)) :
			$classes[] = 'has-header-search';
		endif;

		$classes[] = paprika_option('footer-style', false, 'footer-multipage');

		// Adds a class of group-blog to blogs with more than 1 published author.
		if ( is_multi_author() ) :
			$classes[ ] = 'group-blog';
		endif;

		if (!is_page() && !is_singular('tt-portfolio') && !is_singular('tt-member')) :
			if(paprika_option('blog-logo', 'url')){
				$classes[] = 'has-site-logo';
			}
			if(paprika_option('blog-mobile-logo', 'url')){
				$classes[] = 'has-mobile-logo';
			}
			if(paprika_option('blog-sticky-logo', 'url')){
				$classes[] = 'has-sticky-logo';
			}
			if(paprika_option('blog-sticky-mobile-logo', 'url')){
				$classes[] = 'has-sticky-mobile-logo';
			}
		endif;

		if (paprika_option('logo', 'url') || function_exists('rwmb_meta') && rwmb_meta('paprika_page_logo', 'type=image_advanced')) {
			$classes[] = 'has-site-logo';
		}
		if (paprika_option('mobile-logo', 'url') || function_exists('rwmb_meta') && rwmb_meta('paprika_page_mobile_logo', 'type=image_advanced')) {
			$classes[] = 'has-mobile-logo';
		}
		if (paprika_option('sticky-logo', 'url') || function_exists('rwmb_meta') && rwmb_meta('paprika_page_sticky_logo', 'type=image_advanced')) {
			$classes[] = 'has-sticky-logo';
		}
		if (paprika_option('sticky-mobile-logo', 'url') || function_exists('rwmb_meta') && rwmb_meta('paprika_page_mobile_sticky_logo', 'type=image_advanced')) {
			$classes[] = 'has-sticky-mobile-logo';
		}
		return $classes;
	}
	add_filter( 'body_class', 'paprika_body_classes' );

endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Get our wp_nav_menu() fallback, wp_page_menu(), to show a home link.
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if ( ! function_exists( 'paprika_page_menu_args' ) ) :

	function paprika_page_menu_args( $args ) {

		$args[ 'show_home' ] = TRUE;

		return $args;
	}

	add_filter( 'wp_page_menu_args', 'paprika_page_menu_args' );

endif;



//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Sets the authordata global when viewing an author archive.
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if ( ! function_exists( 'paprika_setup_author' ) ) :
	function paprika_setup_author() {
		global $wp_query;

		if ( $wp_query->is_author() && isset( $wp_query->post ) ) {
			$GLOBALS[ 'authordata' ] = get_userdata( $wp_query->post->post_author );
		}
	}

	add_action( 'wp', 'paprika_setup_author' );

endif;



//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Page break button in editor
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if ( ! function_exists( 'paprika_wp_page_pagination' ) ) :

	function paprika_wp_page_pagination( $mce_buttons ) {
		if ( get_post_type() == 'post' or get_post_type() == 'page' ) {
			$pos = array_search( 'wp_more', $mce_buttons, TRUE );
			if ( $pos !== FALSE ) {
				$buttons     = array_slice( $mce_buttons, 0, $pos + 1 );
				$buttons[ ]  = 'wp_page';
				$mce_buttons = array_merge( $buttons, array_slice( $mce_buttons, $pos + 1 ) );
			}
		}

		return $mce_buttons;
	}

	add_filter( 'mce_buttons', 'paprika_wp_page_pagination' );

endif;



//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Extend user contact
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
if (!function_exists('paprika_extend_user_contact')) :
    function paprika_extend_user_contact( $paprika_user_contact) {
        
        $paprika_user_contact['facebook_profile'] = esc_html__('Facebook Profile URL', 'paprika');
        $paprika_user_contact['twitter_profile'] = esc_html__('Twitter Profile URL', 'paprika');
        $paprika_user_contact['google_profile'] = esc_html__('Google Profile URL', 'paprika');
        $paprika_user_contact['linkedin_profile'] = esc_html__('Linkedin Profile URL', 'paprika');
        $paprika_user_contact['instagram_profile'] = esc_html__('Instagram Profile URL', 'paprika');
        
        return $paprika_user_contact;
    }

    add_filter( 'user_contactmethods', 'paprika_extend_user_contact');

endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Set post view on single page
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if ( ! function_exists( 'paprika_put_post_view_function' ) ) :

    function paprika_put_post_view_function( $contents ) {
        if ( function_exists( 'paprika_set_post_views' ) and is_single() ) {
            paprika_set_post_views(get_the_ID());
        }

        return $contents;
    }

    add_filter( 'the_content', 'paprika_put_post_view_function', 9999 );

endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Get site url by replacing 'http://site_url/' for one page menu
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if ( ! function_exists( 'paprika_get_site_url' ) ) :

	function paprika_get_site_url($output) {

		global $post;
		$front_id = get_option('page_on_front');
		
		if(is_object($post)) :
			$output = str_replace( 'http://site_url/', get_permalink($front_id), $output);	
			$output = str_replace( get_permalink($post->ID).'#', '#', $output );
		endif;

	    return $output;
	}
	add_filter( 'walker_nav_menu_start_el', 'paprika_get_site_url', 10, 4);
endif;


//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Redux News Flash Remove 
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

if ( ! class_exists( 'reduxNewsflash' ) ):
	class reduxNewsflash {
		public function __construct( $parent, $params ) {

		}
	}
endif;

//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
// Redux Ads Remove
//-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-

	add_filter( 'redux/' . 'paprika_theme_option' . '/aURL_filter', '__return_empty_string' );