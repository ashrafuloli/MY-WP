<?php if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif; ?>

<footer class="footer-section footer-default-wrapper">
	
	<?php if ( class_exists( 'Redux' ) ) : ?>

		<div class="primary-footer">
		<div class="container">
			<div class="row">
				<div class="col-md-4">

					<div class="footer-logo">
						<a href="<?php echo esc_url(site_url('/')); ?>" title="<?php echo esc_attr(get_bloginfo('name')); ?>">
							<img src="<?php echo esc_url(paprika_option('footer-logo', 'url', get_template_directory_uri() . '/images/logo.png')); ?>" alt="<?php echo esc_attr(get_bloginfo('name')); ?>"/>
						</a>
					</div> <!-- .footer-logo -->

					<div class="footer-about-text">
						<?php echo wp_kses(paprika_option('footer-about-text'), array(
							'a'          => array(
								'href'   => array(),
								'title'  => array(),
								'target' => array()
							),
							'br'     => array(),
							'em'     => array(),
							'strong' => array(),
							'ul'     => array(),
							'li'     => array(),
							'p'      => array(),
							'span'   => array(
								'class' => array()
							)
						)); ?>
						
					</div>
					<div class="footer-social-icon">
					<?php 
						$footer_facebook = paprika_option('footer-facebook-link');
						$footer_twitter = paprika_option('footer-twitter-link');
						$footer_google_plus = paprika_option('footer-google-plus-link');
						$footer_youtube = paprika_option('footer-youtube-link');
						$footer_pinterest = paprika_option('footer-pinterest-link');
						$footer_flickr = paprika_option('footer-flickr-link');
						$footer_linkedin = paprika_option('footer-linkedin-link');
						$footer_vimeo = paprika_option('footer-vimeo-link');
						$footer_instagram = paprika_option('footer-instagram-link');
						$footer_dribbble = paprika_option('footer-dribbble-link');
						$footer_behance = paprika_option('footer-behance-link');
					?>
					
						<?php if( $footer_facebook ) : ?>
							<a href="<?php echo $footer_facebook; ?>"><i class="fa fa-facebook"></i></a>
						<?php endif; ?>
					
						<?php if( $footer_twitter ) : ?>
							<a href="<?php echo $footer_twitter; ?>"><i class="fa fa-twitter"></i></a>
						<?php endif; ?>
					
						<?php if( $footer_google_plus ) : ?>
							<a href="<?php echo $footer_google_plus; ?>"><i class="fa fa-google-plus"></i></a>
						<?php endif; ?>
					
						<?php if( $footer_youtube ) : ?>
							<a href="<?php echo $footer_youtube; ?>"><i class="fa fa-youtube"></i></a>
						<?php endif; ?>
					
						<?php if( $footer_pinterest ) : ?>
							<a href="<?php echo $footer_pinterest; ?>"><i class="fa fa-pinterest"></i></a>
						<?php endif; ?>
					
						<?php if( $footer_flickr ) : ?>
							<a href="<?php echo $footer_flickr; ?>"><i class="fa fa-flickr"></i></a>
						<?php endif; ?>
					
						<?php if( $footer_linkedin ) : ?>
							<a href="<?php echo $footer_linkedin; ?>"><i class="fa fa-linkedin"></i></a>
						<?php endif; ?>
					
						<?php if( $footer_vimeo ) : ?>
							<a href="<?php echo $footer_vimeo; ?>"><i class="fa fa-vimeo"></i></a>
						<?php endif; ?>
					
						<?php if( $footer_instagram ) : ?>
							<a href="<?php echo $footer_instagram; ?>"><i class="fa fa-instagram"></i></a>
						<?php endif; ?>
					
						<?php if( $footer_dribbble ) : ?>
							<a href="<?php echo $footer_dribbble; ?>"><i class="fa fa-dribbble"></i></a>
						<?php endif; ?>
					
						<?php if( $footer_behance ) : ?>
							<a href="<?php echo $footer_behance; ?>"><i class="fa fa-behance"></i></a>
						<?php endif; ?>
						
					</div>
					
				</div> <!-- .col-md-4 -->
				
				<div class="col-md-8">
					<?php if (is_active_sidebar('paprika-footer-three-column' )): ?>
					
					<div class="row tt-sidebar-wrapper footer-sidebar clearfix" role="complementary">
						<?php dynamic_sidebar('paprika-footer-three-column' );?>
					</div>
					<?php endif ?>
				</div>
				
			</div>
			</div>
		</div> <!-- .primary-footer -->
	<?php endif; ?>
   
    <div class="footer-copyright">
		<div class="container">

			<div class="row">
				<div class="col-sm-12 text-center bottom-top visible-xs">
					<a href="#." class="scrollup">
						<i class="fa fa-chevron-up"></i><br>
						<span>GO ON TOP</span>
					</a>
				</div>
				<div class="col-sm-5 text-left copyright-text">
					<?php if( paprika_option('copyright-text') ) : ?>
						<p><?php echo paprika_option('copyright-text') ?></p>
					<?php else : ?>
						<p>© TrendyTheme. All rights reserved.</p>
					<?php endif ?>
				</div>
				
				<div class="col-sm-2 text-center bottom-top hidden-xs">
					<a href="#." class="scrollup">
						<i class="fa fa-chevron-up"></i><br>
						<span>GO ON TOP</span>
					</a>
				</div>
				
				<div class="col-sm-5 text-right authorize-text">
					<?php if( paprika_option('authorize-text') ) : ?>
						<p><?php echo paprika_option('authorize-text') ?></p>
					<?php else : ?>
						<p>Carefully crafted by TrendyTheme</p>
					<?php endif ?>
				</div>
			</div>
		</div>
    </div> <!-- .footer-copyright -->
</footer> <!-- .footer-section -->

<?php wp_footer(); ?>

</body>
</html>