<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

$tt_atts = shortcode_atts( array(
	'icon' => '',
	'icon_size' => '',
	'icon_color' => ''
), $atts );

$color = '';
$size = '';

if ($tt_atts['icon_color']) {
	$color = 'color:'.$tt_atts['icon_color'].';';
}

if ($tt_atts['icon_size']) {
	$size = 'font-size:'.$tt_atts['icon_size'].';';
}

ob_start(); ?>

	<div class="icon-wrapper">
		<span style="<?php echo esc_attr($color.' '.$size); ?>"><i class="fa <?php echo esc_attr($tt_atts['icon']); ?>"></i></span>
	</div>

<?php echo ob_get_clean();