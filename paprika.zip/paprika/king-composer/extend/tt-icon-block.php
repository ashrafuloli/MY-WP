<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;


add_action('init', 'businesszone_icon_block', 99 );
 
function businesszone_icon_block() {
 
    if (function_exists('kc_add_map')) { 
        kc_add_map( array(

            'tt_icon_block' => array(
                'name' => 'TT Icon',
                'description' => esc_html__('Display single icon', 'KingComposer'),
                'icon' => 'sl-paper-plane',
                'category' => 'TT Elements',
                'params' => array(
                    array(
                        'name' => 'icon',
                        'label' => 'Select Icon',
                        'type' => 'icon_picker',
                        'admin_label' => true,
                    ),
                    array(
                        'name' => 'icon_size',
                        'label' => 'Icon Size',
                        'type' => 'text',
                        'admin_label' => true,
                        'description' => esc_html__('Enter font-size for icon such as: 15px, 1em ..etc..', 'KingComposer')
                    ),
                    array(
                        'name' => 'icon_color',
                        'label' => 'Icon Color',
                        'type' => 'color_picker',
                        'admin_label' => true,
                        'description' => esc_html__('Set color for icon', 'KingComposer')
                    )
                )
            ),
        )); // End add map
    } // End if
}