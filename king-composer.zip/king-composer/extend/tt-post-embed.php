<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;


add_action('init', 'maxrank_post_embed', 99 );
 
function maxrank_post_embed() {
 
    if (function_exists('kc_add_map')) { 
	
		function trendymag_post_category_slug(){
			$categories = get_categories(array('hide_empty' => false));
			$lists = array();
			foreach($categories as $category) {
				$lists[] = array(
					$category->slug => $category->name
				);
			}
			return $lists;
		}
	
        kc_add_map( array(
		
            'tt-post-embed' => array(
                'name' => 'TT Post embed',
                'description' => esc_html__('Post Embed', 'maxrank'),
                'icon' => 'sl-paper-plane',
                'category' => 'TT Elements',
                'params' => array(
				
					array(
                        'name' => 'posts_per_page',
                        'label' => 'Portfolio Number',
                        'type' => 'select',  
						'options' => array( 
							'3' => '3',
							'6' => '6',
							'9' => '9',
							'12' => '12',
						),
                        'value' => 3,
                        'admin_label' => true,
                    ),
					
					// category
					array(
                        'name' => 'category',
                        'label' => 'Category',
                        'type' => 'select',  
						'options' => trendymag_post_category_slug(),
                        'admin_label' => true,
                    ),
					
                    array(
                        'name' => 'order',
                        'label' => 'Order',
                        'type' => 'select',  
						'options' => array( 
							'title' => 'Title',
							'name' => 'Name',
							'date' => 'Date',
							'author' => 'Author',
							'rand' => 'Randomly',
						),
                        'admin_label' => true,
                    ),
					
                    array(
                        'name' => 'order_by',
                        'label' => 'Order By',
                        'type' => 'select',  
						'options' => array( 
							'ASC' => 'ASC',
							'DESC' => 'DESC',
							'rand' => 'Randomly',
						),
                        'admin_label' => true,
                    )
					
                )
            ),
        )); // End add map
    } // End if
}