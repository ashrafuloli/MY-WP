<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

add_action('init', 'maxrank_google_map', 99 );
 
function maxrank_google_map() {
 
    if (function_exists('kc_add_map')) { 
        kc_add_map( array(

            'tt-google-map' => array(
                'name' => 'TT Google Map',
                'description' => esc_html__('Add Google Map', 'maxrank'),
                'icon' => 'sl-paper-plane',
                'category' => 'TT Elements',
                'params' => array(
				
                    array(
                        'name' => 'latitude',
                        'label' => 'Map Latitude',
                        'type' => 'text',
                        'value' => '23.760961',
                        'admin_label' => true,
                    ),
					
                    array(
                        'name' => 'longitude',
                        'label' => 'Map longitude',
                        'type' => 'text',
                        'value' => '90.4344363',
                        'admin_label' => true,
                    ),
					
                    array(
                        'name' => 'google_api',
                        'label' => 'Google API',
                        'type' => 'text',
                        'value' => '',
                        'admin_label' => true,
                    ),
					
                    array(
                        'name' => 'marker',
                        'label' => 'Add map marker',
                        'type' => 'attach_image',
                        'admin_label' => true,
                    )
					
                )
            ),
        )); // End add map
    } // End if
}