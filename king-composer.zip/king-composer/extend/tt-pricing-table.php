<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

add_action('init', 'maxrank_pricing_table', 99 );
 
function maxrank_pricing_table() {
 
    if (function_exists('kc_add_map')) { 
        kc_add_map( array(

            'tt-pricing-table' => array(
                'name' => 'TT Pricing Table',
                'description' => esc_html__('Add Pricing Table', 'maxrank'),
                'icon' => 'sl-paper-plane',
                'category' => 'TT Elements',
                'params' => array(
				
                    'general'=>array(
						array(
							'name' => 'package_name',
							'label' => 'Package Name',
							'type' => 'text',
							'admin_label' => true,
						),
						
						array(
							'name' => 'currency',
							'label' => 'Currency',
							'type' => 'text',
							'admin_label' => true,
						),
						
						array(
							'name' => 'price',
							'label' => 'Price',
							'type' => 'text',
							'admin_label' => true,
						),
						
						array(
							'name' => 'price_cent',
							'label' => 'Price Cent',
							'type' => 'text',
							'admin_label' => true,
						),
						
						array(
							'name' => 'package_duration',
							'label' => 'Per',
							'type' => 'text',
							'admin_label' => true,
						),
						
						array(
							'name' => 'table_info',
							'label' => 'Package Info',
							'type' => 'editor',
							'admin_label' => true,
						),
						
						array(
							'name' => 'button_link',
							'label' => 'Service Title',
							'type' => 'text',
							'admin_label' => true,
						),
						
						array(
							'name' => 'future_package',
							'label' => 'Future Plan Enable',
							'type' => 'toggle',
							'value' => 'no',
							'admin_label' => true,
						),
						
						array(
							'name' => 'theme_color',
							'label' => 'Theme',
							'type' => 'select',  
							'options' => array( 
								'btn-green' => 'Green Button',
								'btn-blue' => 'Blue Button',
								'btn-orange' => 'Orange Button',
								'btn-red' => 'Red Button',
							),
							'admin_label' => true,
						)
						
					),
					
                )
            ),
        )); // End add map
    } // End if
}