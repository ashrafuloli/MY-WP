<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

add_action('init', 'maxrank_section_title', 99 );
 
function maxrank_section_title() {
 
    if (function_exists('kc_add_map')) { 
        kc_add_map( array(

            'tt-section-title' => array(
                'name' => 'TT Section Title',
                'description' => esc_html__('Add Section title', 'maxrank'),
                'icon' => 'sl-paper-plane',
                'category' => 'TT Elements',
                'params' => array(
				
				'general' => array(
					array(
                        'name' => 'title',
                        'label' => 'Section Title',
                        'type' => 'text',
                        'admin_label' => true,
                    ),
					
                    array(
                        'name' => 'sub_title',
                        'label' => 'Section sub-title',
                        'type' => 'textarea',
                        'admin_label' => true,
                    ),
				),
				
				'title style' => array(
					array(
						'name'		=> 'title_style',
						'type'		=> 'css',
						'options'	=> array(
							array(
								"screens" => "any,1024,999,767,479",
								'Typography' => array(
									array('property' => 'color', 'label' => 'Color', 'selector' => 'h2.section-title'),
									array('property' => 'font-family', 'label' => 'Font Family', 'selector' => 'h2.section-title'),
									array('property' => 'font-size', 'label' => 'Font Size', 'selector' => 'h2.section-title'),
									array('property' => 'line-height', 'label' => 'Line Height', 'selector' => 'h2.section-title'),
									array('property' => 'font-style', 'label' => 'Font Style', 'selector' => 'h2.section-title'),
									array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => 'h2.section-title'),
									array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => 'h2.section-title'),
									array('property' => 'text-align', 'label' => 'Text Align', 'selector' => 'h2.section-title'),
									array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => 'h2.section-title'),
								),
								'Box'    => array(
									array('property' => 'background', 'label' => 'Background', 'selector' => 'h2.section-title'),
									array('property' => 'width', 'label' => 'Width', 'selector' => 'h2.section-title'),
									array('property' => 'border', 'label' => 'Border', 'selector' => 'h2.section-title'),
									array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => 'h2.section-title'),
									array('property' => 'display', 'label' => 'Display', 'selector' => 'h2.section-title'),
									array('property' => 'padding', 'label' => 'Padding', 'selector' => 'h2.section-title'),
									array('property' => 'margin', 'label' => 'Margin', 'selector' => 'h2.section-title'),

								)
							)
						)
					)
				),
				
				'sub-title style' => array(
					array(
						'name'		=> 'sub_title_style',
						'type'		=> 'css',
						'options'	=> array(
							array(
								"screens" => "any,1024,999,767,479",
								'Typography' => array(
									array('property' => 'color', 'label' => 'Color', 'selector' => 'p.section-sub'),
									array('property' => 'font-family', 'label' => 'Font Family', 'selector' => 'p.section-sub'),
									array('property' => 'font-size', 'label' => 'Font Size', 'selector' => 'p.section-sub'),
									array('property' => 'line-height', 'label' => 'Line Height', 'selector' => 'p.section-sub'),
									array('property' => 'font-style', 'label' => 'Font Style', 'selector' => 'p.section-sub'),
									array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => 'p.section-sub'),
									array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => 'p.section-sub'),
									array('property' => 'text-align', 'label' => 'Text Align', 'selector' => 'p.section-sub'),
									array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => 'p.section-sub'),
								),
								'Box'    => array(
									array('property' => 'background', 'label' => 'Background', 'selector' => 'p.section-sub'),
									array('property' => 'width', 'label' => 'Width', 'selector' => 'p.section-sub'),
									array('property' => 'border', 'label' => 'Border', 'selector' => 'p.section-sub'),
									array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => 'p.section-sub'),
									array('property' => 'display', 'label' => 'Display', 'selector' => 'p.section-sub'),
									array('property' => 'padding', 'label' => 'Padding', 'selector' => 'p.section-sub'),
									array('property' => 'margin', 'label' => 'Margin', 'selector' => 'p.section-sub'),

								)
							)
						)
					)
				),
				
				'animate' => array(
					array(
						'name'    => 'animate',
						'type'    => 'animate'
					)
				)
					
                )
            ),
        )); // End add map
    } // End if
}