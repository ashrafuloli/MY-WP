<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

add_action('init', 'maxrank_service_box', 99 );
 
function maxrank_service_box() {
 
    if (function_exists('kc_add_map')) { 
        kc_add_map( array(

            'tt-service-box' => array(
                'name' => 'TT Features Box',
                'description' => esc_html__('Add Features box item', 'maxrank'),
                'icon' => 'sl-paper-plane',
                'category' => 'TT Elements',
                'params' => array(
				
					'general' => array(
					
	                    array(
	                        'name' => 'title',
	                        'label' => 'Service Title',
	                        'type' => 'text',
	                        'admin_label' => true,
	                    ),
						
	                    array(
	                        'name' => 'content',
	                        'label' => 'Service Content',
	                        'type' => 'textarea',
	                        'admin_label' => true,
	                    ),
						
						array(
	                        'name' => 'number',
	                        'label' => 'Background number',
	                        'type' => 'text',
	                        'admin_label' => true,
	                    ),
					),
					    
					'title style' => array(
						array(
							'name'		=> 'title_style',
							'type'		=> 'css',
							'options'	=> array(
								array(
									"screens" => "any,1024,999,767,479",
									'Typography' => array(
										array('property' => 'color', 'label' => 'Color', 'selector' => '.content h2'),
										array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.content h2'),
										array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.content h2'),
										array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.content h2'),
										array('property' => 'font-style', 'label' => 'Font Style', 'selector' => '.content h2'),
										array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.content h2'),
										array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.content h2'),
										array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.content h2'),
										array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.content h2'),
									),
									'Box'    => array(
										array('property' => 'background', 'label' => 'Background', 'selector' => '.content h2'),
										array('property' => 'width', 'label' => 'Width', 'selector' => '.content h2'),
										array('property' => 'border', 'label' => 'Border', 'selector' => '.content h2'),
										array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.content h2'),
										array('property' => 'display', 'label' => 'Display', 'selector' => '.content h2'),
										array('property' => 'padding', 'label' => 'Padding', 'selector' => '.content h2'),
										array('property' => 'margin', 'label' => 'Margin', 'selector' => '.content h2'),

									)
								)
							)
						)
					),
	                    
					'content style' => array(
						array(
							'name'		=> 'content_style',
							'type'		=> 'css',
							'options'	=> array(
								array(
									"screens" => "any,1024,999,767,479",
									'Typography' => array(
										array('property' => 'color', 'label' => 'Color', 'selector' => '.content p'),
										array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.content p'),
										array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.content p'),
										array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.content p'),
										array('property' => 'font-style', 'label' => 'Font Style', 'selector' => '.content p'),
										array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.content p'),
										array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.content p'),
										array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.content p'),
										array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.content p'),
									),
									'Box'    => array(
										array('property' => 'background', 'label' => 'Background', 'selector' => '.content p'),
										array('property' => 'width', 'label' => 'Width', 'selector' => '.content p'),
										array('property' => 'border', 'label' => 'Border', 'selector' => '.content p'),
										array('property' => 'border-radius', 'label' => 'Border Radius', 'selector' => '.content p'),
										array('property' => 'display', 'label' => 'Display', 'selector' => '.content p'),
										array('property' => 'padding', 'label' => 'Padding', 'selector' => '.content p'),
										array('property' => 'margin', 'label' => 'Margin', 'selector' => '.content p'),

									)
								)
							)
						)
					),
	                    
					'bg no style' => array(
						array(
							'name'		=> 'bg_style',
							'type'		=> 'css',
							'options'	=> array(
								array(
									"screens" => "any,1024,999,767,479",
									'Typography' => array(
										array('property' => 'color', 'label' => 'Color', 'selector' => '.service-num span'),
										array('property' => 'font-family', 'label' => 'Font Family', 'selector' => '.service-num span'),
										array('property' => 'font-size', 'label' => 'Font Size', 'selector' => '.service-num span'),
										array('property' => 'line-height', 'label' => 'Line Height', 'selector' => '.service-num span'),
										array('property' => 'font-style', 'label' => 'Font Style', 'selector' => '.service-num span'),
										array('property' => 'font-weight', 'label' => 'Font Weight', 'selector' => '.service-num span'),
										array('property' => 'text-transform', 'label' => 'Text Transform', 'selector' => '.service-num span'),
										array('property' => 'text-align', 'label' => 'Text Align', 'selector' => '.service-num span'),
										array('property' => 'letter-spacing', 'label' => 'Letter Spacing', 'selector' => '.service-num span'),
									)
								)
							)
						)
					)
                )
            )
        )); // End add map
    } // End if
}