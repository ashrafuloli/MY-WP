<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;


add_action('init', 'maxrank_testimonial', 99 );
 
function maxrank_testimonial() {
 
    if (function_exists('kc_add_map')) { 
        kc_add_map( array(

            'tt-testimonial' => array(
                'name' => 'TT Testimonial',
                'description' => esc_html__('Add Testimonial', 'maxrank'),
                'icon' => 'sl-paper-plane',
                'category' => 'TT Elements',
                'params' => array(
				
                    array(
						'type'			=> 'group',
						'label'			=> __(' Options', 'maxrank'),
						'name'			=> 'options',
						'description'	=> __( 'Repeat this fields with each item created, Each item corresponding processbar element.', 'maxrank' ),
						'options'		=> array('add_text' => __(' Add new progress bar', 'maxrank')),
						'params' => array(
							array(
								'type' => 'textarea',
								'label' => __( 'Content', 'maxrank' ),
								'name' => 'content',
								'admin_label' => true,
							),
							array(
								'type' => 'text',
								'label' => __( 'Author Name', 'maxrank' ),
								'name' => 'author_name',
								'admin_label' => true,
							),
							array(
								'type' => 'text',
								'label' => __( 'Author Designation', 'maxrank' ),
								'name' => 'author_designation',
								'admin_label' => true,
							)
						)
					)
                    
                )
            )
        )); // End add map	
    } // End if
}