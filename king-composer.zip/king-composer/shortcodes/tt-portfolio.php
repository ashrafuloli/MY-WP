<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

extract(shortcode_atts( array(
	'posts_per_page' => 6,
	'category' => '',
	'order_by' => '',
	'order' => '',
), $atts ));

ob_start(); ?>

<div class="row">
<?php
	$args = array(
		'post_type' => 'tt-portfolio',
		'posts_per_page' => $posts_per_page,
		'tax_query' => array(
			array(
				'taxonomy' => 'tt-portfolio-tax',
				'field'    => 'slug',
				'terms'    => array($category),
			),
		),
		//orderby
		'orderby' => $order_by,
		'order'   => $order, 
	);
	$wp_query = new WP_Query($args);

if ( $wp_query -> have_posts() ) : ?>
	<?php while( $wp_query -> have_posts() ) : $wp_query -> the_post(); ?>
		<div class="col-md-4 mb-30">
			<div class="portfolio-wrapper transition">
			
				<?php 
					the_post_thumbnail('maxrank_portfolio_thumb', ['class' => 'img-responsive']);
				?>

				<div class="portfolio-content">
					<div class="portfolio-caption">
						<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						
						<ul class="list-inline portfolio-tag">
							<?php maxrank_portfolio_cat(); ?>
						</ul>
					</div>
					
					<div class="portfolio-caption-link">
						<a href="<?php the_permalink(); ?>"><i class="fa fa-arrow-circle-o-right"></i></a>
					</div>
				</div><!-- /.portfolio-content -->
			</div><!-- /.portfolio-wrapper -->
		</div> <!-- /.col-md-4 -->
	<?php endwhile; ?>
<?php endif; ?>
</div> <!-- /.row -->

<?php echo ob_get_clean();