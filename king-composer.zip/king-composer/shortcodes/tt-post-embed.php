<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

extract(shortcode_atts( array(
	'posts_per_page' => 6,
	'category' => '',
	'order_by' => '',
	'order' => '',
), $atts ));

ob_start(); 

$args = array(
	'post_type' => 'post',
	'posts_per_page' => $posts_per_page,
	'category_name' => $category,
	
	//orderby
	'orderby' => $order_by,
	'order'   => $order, 
);

$wp_query = new WP_Query($args); ?>

<div class="row">
	<?php while ( $wp_query -> have_posts() ) :  $wp_query -> the_post(); ?>
	<div class="col-md-4">
		<article class="post-wrapper latest-blog-wrapper transition mb-40">
			
			<div class="blog-content transition">
				<div class="blog-date">
					<span><?php the_time('d M, Y') ?></span>
				</div>

				<div class="entry-header mb-20">
					<h2>
						<a href="<?php the_permalink(); ?>">
							<?php echo wp_trim_words( get_the_title(), 10, '...' ); ?>
						</a>
					</h2>
				</div>
				<div class="blog-autthor">
					<?php printf('<a class="url fn n" href="%1$s"><span>BY </span> %2$s</a>',
						esc_url(get_author_posts_url(get_the_author_meta('ID'))),
						esc_html(get_the_author())) ?>
				</div>
			</div>
		</article>
	</div> <!-- /.col-md-4 -->
	<?php endwhile; ?>

</div> <!-- /.row -->

<?php echo ob_get_clean();