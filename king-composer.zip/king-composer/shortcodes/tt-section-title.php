<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

extract(shortcode_atts( array(
	'title' => '',
	'sub_title' => '',
), $atts ));

ob_start(); 
$master_class = apply_filters( 'kc-el-class', $atts );
$master_class[] = 'tt-section-title';
?>

<div class="row">
	<div class="col-md-8 col-md-offset-2">
		<div class="section-title-wrapper text-center <?php echo esc_attr( implode( ' ', $master_class ) ) ?>">
			<?php if( $title ) : ?>
				<h2 class="section-title">
					<?php echo esc_html($title); ?>
				</h2>
			<?php endif; ?>
			
			<?php if( $sub_title ) : ?>
				<p class="section-sub">
					<?php echo esc_html($sub_title); ?>
				</p>
			<?php endif; ?>
		</div>
	</div>
</div>

<?php echo ob_get_clean();