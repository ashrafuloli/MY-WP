<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

extract(shortcode_atts( array(
	'package_name' => 'Starter',
	'currency' => '$',
	'price' => '29',
	'price_cent' => '.99',
	'package_duration' => 'month',
	
	//table info
	'table_info' => '',
	'button_link' => '',
	'future_package' => '',
	'theme_color' => '',
	
), $atts ));

ob_start(); 

	if($theme_color == 'btn-green'){
		$package_color = '#01a23c';
	} elseif($theme_color == 'btn-blue'){
		$package_color = '#0083ff';
	} elseif($theme_color == 'btn-orange'){
		$package_color = '#FF6600';
	} elseif($theme_color == 'btn-red'){
		$package_color = '#ff3133';
	} else{
		$package_color = '#000';
	}

?>
	<div class="pricing-table-wrapper transition text-center <?php echo esc_attr(($future_package == 'yes' ? 'futured-pricing-table' : '')); ?>">

		<div class="table-header">
			<span class="package-name" style="color: <?php echo esc_attr($package_color); ?>"><?php echo esc_html($package_name) ?></span>
			<div class="package-price">
				<span class="currency-symbol"><?php echo esc_html($currency) ?></span>
				<span class="price"><?php echo esc_html($price) ?></span>
				<span class="price-cent"><?php echo esc_html($price_cent) ?></span>
				<span class="currency-code">Per <?php echo esc_html($package_duration) ?></span>
			</div>
		</div>

		<div class="table-info tt-pricing-table">
			<?php  
				echo wp_kses($table_info, array(
					'a'          => array(
						'href'   => array(),
						'title'  => array(),
						'target' => array()
					),
					'br'     => array(),
					'del'     => array(),
					'em'     => array(),
					'strong' => array(),
					'ul'     => array(),
					'li'     => array(),
					'p'      => array(),
					'span'   => array(
						'class' => array()
					)
				)); 
			?>
		</div>

		<div class="table-footer">
			<div class="purchase-button">
				<a href="<?php echo esc_url($button_link) ?>" class="btn btn-round <?php echo esc_attr($theme_color) ?>">Order Now</a>
			</div>
		</div>

	</div> <!-- /.prining-table-wrapper -->
	
<?php echo ob_get_clean();