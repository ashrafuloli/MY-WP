<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

extract(shortcode_atts( array(
	'latitude' => '23.760961',
	'longitude' => '90.4344363',
	'marker' => '',
	'google_api' => '',
), $atts ));



$marker_thumb = wp_get_attachment_image_src($marker, '');


ob_start(); ?>
	

<!-- map-section -->
<section id="myMap" style="height: 450px; width: 100%;"></section>
<!-- /.map-section -->


  <script async defer src="https://maps.googleapis.com/maps/api/js?key=<?php echo $google_api; ?>&callback=initMap"
  type="text/javascript"></script>

<!-- Google Map Customization  -->
<script type="text/javascript">
	jQuery(document).ready(function() {

		//set your google maps parameters
		var $latitude = <?php echo $latitude ?>, //Visit http://www.latlong.net/convert-address-to-lat-long.html for generate your Lat. Long.
			$longitude = <?php echo $longitude ?>,
			$map_zoom = 17 /* ZOOM SETTING */

		//google map custom marker icon 
		var $marker_url = '<?php echo $marker_thumb[0] ?>';

		//we define here the style of the map
		var style = [{
			"stylers": [{
				"hue": "#A1CAFE"
			}, {
				"saturation": 10
			}, {
				"gamma": 0
			}, {
				"lightness": -5
			}]
		}];

		//set google map options
		var map_options = {
			center: new google.maps.LatLng($latitude, $longitude),
			zoom: $map_zoom,
			panControl: true,
			zoomControl: true,
			mapTypeControl: true,
			streetViewControl: true,
			mapTypeId: google.maps.MapTypeId.ROADMAP,
			scrollwheel: false,
			styles: style
		}
		//inizialize the map
		var map = new google.maps.Map(document.getElementById('myMap'), map_options);
		//add a custom marker to the map                
		var marker = new google.maps.Marker({
			position: new google.maps.LatLng($latitude, $longitude),
			map: map,
			visible: true,
			icon: $marker_url
		});

		var contentString = '<div id="mapcontent">' + '<p>TrhendyTheme, 5th floor, House 3, Road 4, Block F, <br> Banasree, Rampura. Dhaka 1219, Bangladesh</p></div>';
		var infowindow = new google.maps.InfoWindow({
			maxWidth: 320,
			content: contentString
		});

		google.maps.event.addListener(marker, 'click', function() {
			infowindow.open(map, marker);
		});
	});
</script>


<?php echo ob_get_clean();