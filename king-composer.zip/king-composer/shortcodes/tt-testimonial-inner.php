<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

extract(shortcode_atts( array(
	'content' => '',
	'author_name' => '',
	'author_designation' => '',
), $atts ));

ob_start(); ?>

<div class="item">
	<div class="testimonial-content">
	  <p><?php echo esc_html($content); ?></p>
	</div>
	<div class="testimonial-meta">
	   <h3><?php echo esc_html($author_name); ?></h3>
	   <span><?php echo esc_html($author_designation); ?></span>
	</div>
</div>

<?php echo ob_get_clean();