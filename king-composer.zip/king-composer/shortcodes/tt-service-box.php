<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

extract(shortcode_atts( array(
	'number' => '01',
	'title' => '',
	'content' => ''
), $atts ));

ob_start(); 
$master_class = apply_filters( 'kc-el-class', $atts );
$master_class[] = 'tt-service-box';
?>
	
	<!-- service Box -->
	<div class="service-box-wrapper <?php echo esc_attr( implode( ' ', $master_class ) ) ?>">
		
		<div class="service-num">
			<span>
				<?php echo esc_html($number); ?>
			</span>
		</div>
		
		<div class="content">
			<h2>
				<?php echo esc_html($title); ?>
			</h2>
			<p>
				<?php echo esc_html($content); ?>
			</p>
		</div>
		
	</div><!-- service Box -->

<?php echo ob_get_clean();