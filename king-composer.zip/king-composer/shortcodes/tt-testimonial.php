<?php
if ( ! defined( 'ABSPATH' ) ) :
    exit; // Exit if accessed directly
endif;

extract($atts);

ob_start();?>
	
<div id="testimonial-carousel" class="carousel slide" data-ride="carousel">

	<!-- Wrapper for slides -->
	<div class="carousel-inner" role="listbox">

		<?php $options_val = $options; 
		foreach($options_val as $option){
			$content = !empty($option->content) ? $option->content : "";
			$author_name = !empty($option->author_name) ? $option->author_name : "";
			$author_designation = !empty($option->author_designation) ? $option->author_designation : "";
		?>

		<div class="item">
			<div class="testimonial-content">
				<p><?php echo esc_html($content); ?></p>
			</div>
			<div class="testimonial-meta">
			   <h3><?php echo esc_html($author_name); ?></h3>
			   <span><?php echo esc_html($author_designation); ?></span>
			</div>
		</div>
			
		<?php } ?>

	</div>

	<!-- Controls -->
	<a class="left carousel-control" href="#testimonial-carousel" role="button" data-slide="prev">
		<span class="fa fa-long-arrow-right" aria-hidden="true"></span>
		<span class="sr-only">Previous</span>
	</a>
	<a class="right carousel-control" href="#testimonial-carousel" role="button" data-slide="next">
		<span class="fa fa-long-arrow-left" aria-hidden="true"></span>
		<span class="sr-only">Next</span>
	</a>
</div>

<?php echo ob_get_clean();