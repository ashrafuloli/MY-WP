<?php
	if ( ! defined( 'ABSPATH' ) ) :
        exit; // Exit if accessed directly
    endif;

	// KC Custom shortcode dir
	function businesszone_kc_shortcode_path(){
		global $kc;
		$kc->set_template_path( get_template_directory().'/king-composer/shortcodes/' );
	}
	add_action('init', 'businesszone_kc_shortcode_path', 99 );

	// VC Admin element stylesheet
	if ( ! function_exists( 'businesszone_kc_admin_styles' ) ) :
		function businesszone_kc_admin_styles() {
			wp_enqueue_style( 'businesszone_kc_admin_style', get_template_directory_uri() . '/king-composer/assets/css/kc-element-style.css', array(), time(), 'all' );
		}
		add_action( 'admin_enqueue_scripts', 'businesszone_kc_admin_styles' );
	endif;

	// include vc extend file
	
	require get_template_directory() . "/king-composer/extend/tt-section-title.php";
	require get_template_directory() . "/king-composer/extend/tt-service-box.php";
	require get_template_directory() . "/king-composer/extend/tt-google-map.php";
	require get_template_directory() . "/king-composer/extend/tt-portfolio.php";
	require get_template_directory() . "/king-composer/extend/tt-pricing-table.php";
	require get_template_directory() . "/king-composer/extend/tt-post-embed.php";
	require get_template_directory() . "/king-composer/extend/tt-testimonial.php";

	// include custom param
	// require get_template_directory() . "/king-composer/params/kc_custom_params.php";