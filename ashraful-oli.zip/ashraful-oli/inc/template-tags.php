<?php
/**
 * Custom template tags for this theme
 *
 * Eventually, some of the functionality here could be replaced by core features.
 *
 * @package Ashraful_Oli
 */

//========================================================================================
//  Blog
//=======================================================================================

if (!function_exists('ashraful_oli_posted_on')) :
	function ashraful_oli_posted_on() { ?>

		<ul class="meta-left">
			<li class="author">
                <span class="author vcard">
                    <i class="fa fa-user"></i><?php printf('<a class="url fn n" href="%1$s">%2$s</a>',
	                    esc_url(get_author_posts_url(get_the_author_meta('ID'))),
	                    esc_html(get_the_author())
                    ) ?>
                </span>
			</li>

			<li class="category">
                <span class="posted-in">
                    <i class="fa fa-folder-open"></i><?php echo get_the_category_list(esc_html_x(' , ', 'Used between list items, there is a space after the comma.', 'ashraful-oli'));
                    ?>
                </span>
			</li>

			<li class="comments">
                <span class="post-comments">
                    <i class="fa fa-comments"></i>
                    <?php comments_popup_link(
                        esc_html__('0', 'ashraful-oli'),
                        esc_html__('1', 'ashraful-oli'),
                        esc_html__('%', 'ashraful-oli'), '',
                        esc_html__('0', 'ashraful-oli')
                    ); ?>
                </span>
			</li>
		</ul>
		<?php
	}
endif;

if ( ! function_exists( 'ashraful_oli_posted_time' ) ) :
	/**
	 * Prints HTML with meta information for the current author.
	 */
	function ashraful_oli_posted_time() { ?>

		<ul class="meta-right float-right">

			<?php echo edit_post_link(esc_html__(' ', 'ashraful-oli'), '<li class="edit-link">', '</li>' , null, 'fa fa-pencil-square-o') ?>

			<li class="date">
				<a href="<?php echo esc_url( get_permalink() ) ?>" rel="bookmark"><?php the_time( get_option( 'date_format' ) ); ?></a>
			</li>
		</ul>

		<?php
	}
endif;

if ( ! function_exists( 'ashraful_oli_entry_footer' ) ) :
	/**
	 * Prints HTML with meta information for the categories, tags and comments.
	 */
	function ashraful_oli_entry_footer() {
		// Hide category and tag text for pages.

		?>

		<ul class="meta-right social-share">
			<li>
				<span class="social-title">Share : </span>
			</li>
			<li>
				<a class="tt-animate btt" href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title(); ?>" title="<?php esc_attr_e('Share on Facebook.', 'paprika'); ?>"><i class="fa fa-facebook"></i></a>
			</li>
			<li>
				<a class="tt-animate btt" href="http://twitter.com/home/?status=<?php the_title(); ?> - <?php the_permalink(); ?>" title="<?php esc_attr_e('Tweet this!', 'paprika')?>"><i class="fa fa-twitter"></i></a>
			</li>
			<li>
				<a class="tt-animate btt" title="<?php esc_attr_e('Share on Google+', 'paprika'); ?>" href="https://plus.google.com/share?url=<?php the_permalink(); ?>" onclick="javascript:window.open(this.href, '', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><i class="fa fa-google"></i></a>
			</li>
			<li>
				<a class="tt-animate btt" href="http://www.linkedin.com/shareArticle?mini=true&amp;title=<?php the_title(); ?>&amp;url=<?php the_permalink(); ?>" title="<?php esc_attr_e('Share on LinkedIn', 'paprika'); ?>"><i class="fa fa-linkedin"></i></a>
			</li>
			<li>
				<a class="tt-animate btt" title="<?php esc_attr_e('Share on Pinterest', 'paprika'); ?>" href="http://pinterest.com/pin/create/button/?url=<?php the_permalink(); ?>&media=<?php $url = wp_get_attachment_url( get_post_thumbnail_id($post->ID) ); echo $url; ?>"><i class="fa fa-pinterest-p"></i></a>
			</li>
		</ul>

		<ul class="meta-right float-right">

			<li class="tags">
				<i class="fa fa-tags"></i>
				<?php
					/* translators: used between list items, there is a space after the comma */
					$tags_list = get_the_tag_list( '', esc_html_x( ' , ', 'list item separator', 'ashraful-oli' ) );
					if ( $tags_list ) {
						/* translators: 1: list of tags. */
						printf( '<span class="tags-links">' . esc_html__( ' %1$s', 'ashraful-oli' ) . '</span>', $tags_list ); // WPCS: XSS OK.
					}
				?>
			</li>

		</ul>

		<?php
	}
endif;

if ( ! function_exists( 'ashraful_oli_post_thumbnail' ) ) :
	/**
	 * Displays an optional post thumbnail.
	 *
	 * Wraps the post thumbnail in an anchor element on index views, or a div
	 * element when on single views.
	 */
	function ashraful_oli_post_thumbnail() {
		if ( post_password_required() || is_attachment() || ! has_post_thumbnail() ) {
			return;
		}

		if ( is_singular() ) :
			?>

			<div class="post-thumbnail">
				<?php the_post_thumbnail('full'); ?>
			</div><!-- .post-thumbnail -->

		<?php else : ?>

		<a class="post-thumbnail" href="<?php the_permalink(); ?>" aria-hidden="true" tabindex="-1">
			<?php
			the_post_thumbnail( 'blog-thumbnail', array(
				'class' => 'img-fluid',
				'alt' => the_title_attribute( array(
					'echo' => false,
				) ),
			) );
			?>
		</a>

		<?php
		endif; // End is_singular().
	}
endif;

