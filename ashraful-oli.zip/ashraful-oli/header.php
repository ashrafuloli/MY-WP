<?php
/**
 * The header for our theme
 *
 * This is the template that displays all of the <head> section and everything up until <div id="content">
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Ashraful_Oli
 */

?>
<!doctype html>
<html <?php language_attributes(); ?>>
<head>
	<meta charset="<?php bloginfo( 'charset' ); ?>">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="profile" href="https://gmpg.org/xfn/11">

	<?php wp_head(); ?>
</head>

<body <?php body_class(); ?>>
<div id="page" class="site">
	<a class="skip-link screen-reader-text" href="#content"><?php esc_html_e( 'Skip to content', 'ashraful-oli' ); ?></a>

	<div class="site-wrapper">
		<div class="container">
			<div class="row sticky-main">
				<div class="col-xl-3">
					<header class="site-header">
						<div class="sticky-sidebar">
							<div class="site-branding">
								<?php
								$custom_logo_id = get_theme_mod('custom_logo');
								if (!empty($custom_logo_id)): the_custom_logo();
								else: ?>
									<h2><a href="<?php echo esc_url( home_url( '/' ) ); ?>" rel="home"><?php bloginfo( 'name' ); ?></a></h2>
								<?php endif; ?>
							</div><!-- .site-branding -->

							<form class="header-search-form" role="search" method="get" action="<?php echo esc_url( home_url( '/'  ) ); ?>">
								<div class="form-group">
									<label class="screen-reader-text" for="header-search-field"><?php esc_html_e( 'Search for:', 'ashraful-oli' ); ?></label>
									<input type="search" id="header-search-field" class="form-control" placeholder="<?php echo esc_attr_x( 'Search', 'placeholder', 'ashraful-oli' ); ?>" value="<?php echo get_search_query(); ?>" name="s" autofocus/>
									<button type="submit"><i class="fa fa-search"></i></button>
									<input type="hidden" value="post" name="post_type" />
								</div>
							</form>

							<nav class="site-menu">
								<button class="menu-toggle" aria-controls="primary-menu" aria-expanded="false"><?php esc_html_e( 'Primary Menu', 'ashraful-oli' ); ?></button>
								<?php
								wp_nav_menu( array(
									'theme_location' => 'menu-1',
									'menu_id' => 'primary-menu',
									'container' => '',
								) );
								?>
							</nav><!-- #site-navigation -->
						</div>
					</header><!-- #masthead -->
				</div>
				<div class="col-xl-9">
					<div id="content" class="site-content">
