<?php
/**
 * Ashraful Oli functions and definitions
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package Ashraful_Oli
 */

if ( ! function_exists( 'ashraful_oli_setup' ) ) :
	/**
	 * Sets up theme defaults and registers support for various WordPress features.
	 *
	 * Note that this function is hooked into the after_setup_theme hook, which
	 * runs before the init hook. The init hook is too late for some features, such
	 * as indicating support for post thumbnails.
	 */
	function ashraful_oli_setup() {
		/*
		 * Make theme available for translation.
		 * Translations can be filed in the /languages/ directory.
		 * If you're building a theme based on Ashraful Oli, use a find and replace
		 * to change 'ashraful-oli' to the name of your theme in all the template files.
		 */
		load_theme_textdomain( 'ashraful-oli', get_template_directory() . '/languages' );

		// Add default posts and comments RSS feed links to head.
		add_theme_support( 'automatic-feed-links' );

		/*
		 * Let WordPress manage the document title.
		 * By adding theme support, we declare that this theme does not use a
		 * hard-coded <title> tag in the document head, and expect WordPress to
		 * provide it for us.
		 */
		add_theme_support( 'title-tag' );

		/*
		 * Enable support for Post Thumbnails on posts and pages.
		 *
		 * @link https://developer.wordpress.org/themes/functionality/featured-images-post-thumbnails/
		 */
		add_theme_support( 'post-thumbnails' );

		// This theme uses wp_nav_menu() in one location.
		register_nav_menus( array(
			'menu-1' => esc_html__( 'Primary', 'ashraful-oli' ),
		) );

		/**
		 * Enable support for Post Formats.
		 * See: https://codex.wordpress.org/Post_Formats
		 */
		add_theme_support('post-formats', array('aside', 'status', 'image', 'audio', 'video', 'gallery', 'quote', 'link', 'chat' ));

		/*
		 * Switch default core markup for search form, comment form, and comments
		 * to output valid HTML5.
		 */
		add_theme_support( 'html5', array(
			'search-form',
			'comment-form',
			'comment-list',
			'gallery',
			'caption',
		) );

		// Set up the WordPress core custom background feature.
		add_theme_support( 'custom-background', apply_filters( 'ashraful_oli_custom_background_args', array(
			'default-color' => 'ffffff',
			'default-image' => '',
		) ) );

		// Add theme support for selective refresh for widgets.
		add_theme_support( 'customize-selective-refresh-widgets' );

		/**
		 * Add support for core custom logo.
		 *
		 * @link https://codex.wordpress.org/Theme_Logo
		 */
		add_theme_support( 'custom-logo', array(
			'height'      => 250,
			'width'       => 250,
			'flex-width'  => true,
			'flex-height' => true,
		) );

		add_image_size( 'blog-thumbnail', 860 , 400 , true);
		add_image_size( 'portfolio-thumbnail', 400 , 350 , true);
		add_image_size( 'testimonial-thumbnail', 100 , 100 , true);
	}
endif;
add_action( 'after_setup_theme', 'ashraful_oli_setup' );

/**
 * Set the content width in pixels, based on the theme's design and stylesheet.
 *
 * Priority 0 to make it available to lower priority callbacks.
 *
 * @global int $content_width
 */
function ashraful_oli_content_width() {
	// This variable is intended to be overruled from themes.
	// Open WPCS issue: {@link https://github.com/WordPress-Coding-Standards/WordPress-Coding-Standards/issues/1043}.
	// phpcs:ignore WordPress.NamingConventions.PrefixAllGlobals.NonPrefixedVariableFound
	$GLOBALS['content_width'] = apply_filters( 'ashraful_oli_content_width', 640 );
}
add_action( 'after_setup_theme', 'ashraful_oli_content_width', 0 );

/**
 * Register widget area.
 *
 * @link https://developer.wordpress.org/themes/functionality/sidebars/#registering-a-sidebar
 */
function ashraful_oli_widgets_init() {
	register_sidebar( array(
		'name'          => esc_html__( 'Sidebar', 'ashraful-oli' ),
		'id'            => 'sidebar-1',
		'description'   => esc_html__( 'Add widgets here.', 'ashraful-oli' ),
		'before_widget' => '<section id="%1$s" class="widget %2$s">',
		'after_widget'  => '</section>',
		'before_title'  => '<h2 class="widget-title">',
		'after_title'   => '</h2>',
	) );
}
add_action( 'widgets_init', 'ashraful_oli_widgets_init' );

/**
 * Enqueue scripts and styles.
 */
function ashraful_oli_scripts() {
	wp_enqueue_style( 'google-fonts', '//fonts.googleapis.com/css?family=Roboto:300,400,400i,500,700' );
	wp_enqueue_style( 'fontawesome', get_template_directory_uri(). '/assets/css/font-awesome.min.css' );
	wp_enqueue_style( 'bootstrap', get_template_directory_uri(). '/assets/css/bootstrap.min.css' );
	wp_enqueue_style( 'owl-carousel', get_template_directory_uri(). '/assets/css/owl.carousel.min.css' );
	wp_enqueue_style( 'ashraful-oli-style', get_stylesheet_uri() );

	wp_enqueue_script( 'popper', get_template_directory_uri() . '/assets/js/popper.min.js', array('jquery'), '20151215', true );
	wp_enqueue_script( 'bootstrap', get_template_directory_uri() . '/assets/js/bootstrap.min.js', array('jquery'), '20151215', true );
	wp_enqueue_script( 'jquery-nav', get_template_directory_uri() . '/assets/js/jquery.nav.js', array('jquery'), '20151215', true );
	wp_enqueue_script( 'ashraful-oli-skip-link-focus-fix', get_template_directory_uri() . '/assets/js/skip-link-focus-fix.js', array(), '20151215', true );
	wp_enqueue_script( 'sticky-sidebar', get_template_directory_uri() . '/assets/js/sticky-sidebar.min.js', array('jquery'), '20151215', true );
	wp_enqueue_script( 'isotope', get_template_directory_uri() . '/assets/js/isotope.pkgd.min.js', array('jquery'), '20151215', true );
	wp_enqueue_script( 'owl-carousel', get_template_directory_uri() . '/assets/js/owl.carousel.min.js', array('jquery'), '20151215', true );
	wp_enqueue_script( 'main', get_template_directory_uri() . '/assets/js/main.js', array('jquery'), '20151215', true );

	if ( is_singular() && comments_open() && get_option( 'thread_comments' ) ) {
		wp_enqueue_script( 'comment-reply' );
	}
}
add_action( 'wp_enqueue_scripts', 'ashraful_oli_scripts' );

/**
 * tgm
 */
require get_template_directory() . '/inc/tgm.php';

/**
 * Implement the Custom Header feature.
 */
require get_template_directory() . '/inc/custom-header.php';

/**
 * Custom template tags for this theme.
 */
require get_template_directory() . '/inc/template-tags.php';

/**
 * Functions which enhance the theme by hooking into WordPress.
 */
require get_template_directory() . '/inc/template-functions.php';

/**
 * Customizer additions.
 */
require get_template_directory() . '/inc/customizer.php';

/**
 * Load Jetpack compatibility file.
 */
if ( defined( 'JETPACK__VERSION' ) ) {
	require get_template_directory() . '/inc/jetpack.php';
}

/**
 * Load WooCommerce compatibility file.
 */
if ( class_exists( 'WooCommerce' ) ) {
	require get_template_directory() . '/inc/woocommerce.php';
}

/**
 * Codestar PLUGIN
 */
if ( class_exists( 'CSF' ) ) {
	require get_template_directory() . '/lib/theme-options.php';
}


/**
 * CMD2 PLUGIN
 */
if (class_exists('CMB2_Bootstrap_260')){
	require get_template_directory() . '/lib/metaboxes/portfolio.php';
	require get_template_directory() . '/lib/metaboxes/sections-type.php';
	require get_template_directory() . '/lib/metaboxes/section-bio.php';
	require get_template_directory() . '/lib/metaboxes/section-skill.php';
	require get_template_directory() . '/lib/metaboxes/section-experience.php';
	require get_template_directory() . '/lib/metaboxes/section-education.php';
	require get_template_directory() . '/lib/metaboxes/section-portfolio.php';
	require get_template_directory() . '/lib/metaboxes/section-testimonial.php';
	require get_template_directory() . '/lib/metaboxes/section-service.php';
	require get_template_directory() . '/lib/metaboxes/section-blog.php';
	require get_template_directory() . '/lib/metaboxes/section-pricing.php';
	require get_template_directory() . '/lib/metaboxes/section-interest.php';
	require get_template_directory() . '/lib/metaboxes/section-contact.php';
	require get_template_directory() . '/lib/metaboxes/landing-page.php';
}

/**
 * One Page Menu
 */

function ashraful_oli_change_nav_menu($menus)
{
	$string_to_replace = get_permalink("/") . "section/";


	foreach ($menus as $menu) {
		$new_url = str_replace($string_to_replace, "#", $menu->url);
		//$new_url = str_replace( $string_to_replace, home_url('/#'), $menu->url);

		if ($new_url != $menu->url) {
			$new_url = rtrim($new_url, "/");
		}
		$menu->url = $new_url;
	}

	return $menus;
}

add_filter('wp_nav_menu_objects', 'ashraful_oli_change_nav_menu');

/**
 * Post Type
 */

function ashraful_oli_register_cpts() {

	/**
	 * Post Type: Sections.
	 */

	$labels = array(
		"name" => __( "Sections", "ashraful-oli" ),
		"singular_name" => __( "Section", "ashraful-oli" ),
		"menu_name" => __( "Sections", "ashraful-oli" ),
		"all_items" => __( "All Sections", "ashraful-oli" ),
		"add_new" => __( "Add New", "ashraful-oli" ),
		"add_new_item" => __( "Add New Section", "ashraful-oli" ),
		"edit_item" => __( "Edit Section", "ashraful-oli" ),
		"new_item" => __( "New Section", "ashraful-oli" ),
		"view_item" => __( "View Section", "ashraful-oli" ),
		"view_items" => __( "View Sections", "ashraful-oli" ),
		"search_items" => __( "Search Section", "ashraful-oli" ),
		"not_found" => __( "No Sections Found", "ashraful-oli" ),
		"not_found_in_trash" => __( "No Sections Found in Trash", "ashraful-oli" ),
		"parent_item_colon" => __( "Parent Section", "ashraful-oli" ),
		"featured_image" => __( "Featured Image for this section", "ashraful-oli" ),
		"set_featured_image" => __( "Set featured image for this section", "ashraful-oli" ),
		"remove_featured_image" => __( "Remove featured image for this section", "ashraful-oli" ),
		"use_featured_image" => __( "Use as featured image for this section", "ashraful-oli" ),
		"archives" => __( "Sections archive", "ashraful-oli" ),
		"insert_into_item" => __( "Insert into sections", "ashraful-oli" ),
		"uploaded_to_this_item" => __( "Uploaded to this sections", "ashraful-oli" ),
		"filter_items_list" => __( "Filter section list", "ashraful-oli" ),
		"items_list_navigation" => __( "Section list navigation", "ashraful-oli" ),
		"items_list" => __( "Section list", "ashraful-oli" ),
		"attributes" => __( "Section Attributes", "ashraful-oli" ),
		"parent_item_colon" => __( "Parent Section", "ashraful-oli" ),
	);

	$args = array(
		"label" => __( "Sections", "ashraful-oli" ),
		"labels" => $labels,
		"description" => "One Page Sections",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "section", "with_front" => true ),
		"query_var" => true,
		"menu_position" => 5,
		"menu_icon" => "dashicons-media-document",
		"supports" => array( "title", "editor", "thumbnail" ),
	);

	register_post_type( "section", $args );

	/**
	 * Post Type: Portfolios.
	 */

	$labels = array(
		"name" => __( "Portfolios", "ashraful-oli" ),
		"singular_name" => __( "Portfolio", "ashraful-oli" ),
	);

	$args = array(
		"label" => __( "Portfolios", "ashraful-oli" ),
		"labels" => $labels,
		"description" => "",
		"public" => true,
		"publicly_queryable" => true,
		"show_ui" => true,
		"delete_with_user" => false,
		"show_in_rest" => true,
		"rest_base" => "",
		"rest_controller_class" => "WP_REST_Posts_Controller",
		"has_archive" => false,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"exclude_from_search" => false,
		"capability_type" => "post",
		"map_meta_cap" => true,
		"hierarchical" => false,
		"rewrite" => array( "slug" => "portfolio", "with_front" => true ),
		"query_var" => true,
		"supports" => array( "title", "editor", "thumbnail" ),
	);

	register_post_type( "portfolio", $args );
}

add_action( 'init', 'ashraful_oli_register_cpts' );


/**
 * Taxonomy
 */

function ashraful_oli_register_taxes() {

	/**
	 * Taxonomy: Portfolio Categories.
	 */

	$labels = array(
		"name" => __( "Portfolio Categories", "ashraful-oli" ),
		"singular_name" => __( "Portfolio Category", "ashraful-oli" ),
	);

	$args = array(
		"label" => __( "Portfolio Categories", "ashraful-oli" ),
		"labels" => $labels,
		"public" => true,
		"publicly_queryable" => true,
		"hierarchical" => true,
		"show_ui" => true,
		"show_in_menu" => true,
		"show_in_nav_menus" => true,
		"query_var" => true,
		"rewrite" => array( 'slug' => 'portfolio-category', 'with_front' => true, ),
		"show_admin_column" => true,
		"show_in_rest" => true,
		"rest_base" => "portfolio_cat",
		"rest_controller_class" => "WP_REST_Terms_Controller",
		"show_in_quick_edit" => false,
	);
	register_taxonomy( "portfolio_cat", array( "portfolio" ), $args );
}
add_action( 'init', 'ashraful_oli_register_taxes' );
