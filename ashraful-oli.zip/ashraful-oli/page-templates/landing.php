<?php
/**
 * Template Name: Landing Page
 */

get_header();
?>

	<div id="primary" class="content-area">
		<main id="main" class="site-main">

			<?php

			$ashraful_oli_current_page_id = get_the_ID();

			$ashraful_oli_page_sections = get_post_meta( $ashraful_oli_current_page_id , 'ashraful_oli_section', true);

			foreach ($ashraful_oli_page_sections as $ashraful_oli_page_section) {

				$ashraful_oli_section_id = $ashraful_oli_page_section; // select page section id in landing page

				$ashraful_oli_section_meta = get_post_meta($ashraful_oli_section_id, 'ashraful_oli_section_type', true);

				$ashraful_oli_section_type = $ashraful_oli_section_meta; // select section type in metabox

				get_template_part("section-templates/{$ashraful_oli_section_type}");

			}


			?>

		</main><!-- #main -->
	</div><!-- #primary -->

<?php
get_footer();
