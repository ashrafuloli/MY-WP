<?php

global $ashraful_oli_section_id;

$ashraful_oli_section = get_post($ashraful_oli_section_id);

$ashraful_oli_section_title = $ashraful_oli_section->post_title; // select post title

$ashraful_oli_meta_section_type = get_post_meta($ashraful_oli_section_id,'ashraful_oli_section_type', true);


if (!empty($ashraful_oli_meta_blog_items)){
	$ashraful_oli_meta_blog_items = get_post_meta($ashraful_oli_section_id,'ashraful_oli_blog_items', true);
}else{
	$ashraful_oli_meta_blog_items = 1;
}

?>

<?php if ('blog' == $ashraful_oli_meta_section_type): ?>

	<h2 class="section-title"><?php echo esc_html($ashraful_oli_section_title); ?></h2>

	<div class="section-service" id="<?php echo get_post_field('post_name', $ashraful_oli_section_id); ?>">
		<div class="row">
			<?php
			$args = array(
				'post_type' => 'post',
				'posts_per_page' => $ashraful_oli_meta_blog_items,
			);
			$portfolio = new WP_Query( $args );

			?>
			<?php while ( $portfolio->have_posts() ) : $portfolio->the_post(); ?>
				<div class="col-xl-12">
					<?php get_template_part( 'template-parts/content', get_post_type() ); ?>
				</div>
			<?php endwhile; ?>
		</div>
	</div>
<?php endif; ?>
