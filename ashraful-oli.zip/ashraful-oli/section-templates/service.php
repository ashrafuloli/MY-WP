<?php

global $ashraful_oli_section_id;

$ashraful_oli_section = get_post($ashraful_oli_section_id);

$ashraful_oli_section_title = $ashraful_oli_section->post_title; // select post title

$ashraful_oli_meta_section_type = get_post_meta($ashraful_oli_section_id,'ashraful_oli_section_type', true);
$ashraful_oli_meta_services = get_post_meta($ashraful_oli_section_id,'ashraful_oli_service', true);

?>

<?php if ('service' == $ashraful_oli_meta_section_type): ?>

	<h2 class="section-title"><?php echo esc_html($ashraful_oli_section_title); ?></h2>

	<div class="section-wrapper section-service" id="<?php echo get_post_field('post_name', $ashraful_oli_section_id); ?>">
		<div class="row">
			<?php if(!empty($ashraful_oli_meta_author_image)): ?>
				<div class="col-xl-5">
					<div class="bio-thumbnail">
						<img src="<?php echo esc_url($ashraful_oli_meta_author_image[0]); ?>" alt="<?php echo esc_attr($ashraful_oli_section_title); ?>" class="img-fluid">
					</div>
				</div>
			<?php endif; ?>
			<?php foreach ($ashraful_oli_meta_services as $ashraful_oli_meta_service): ?>
			<div class="col-xl-6">
				<div class="service-wrapper">
					<div class="service-head">
						<div class="service-icon">
							<i class="<?php echo esc_html($ashraful_oli_meta_service['icon']); ?>"></i>
						</div>
						<div class="service-heading">
							<h5><?php echo esc_html($ashraful_oli_meta_service['sub_title']); ?></h5>
							<h3><?php echo esc_html($ashraful_oli_meta_service['title']); ?></h3>
						</div>
					</div>
					<div class="service-content">
						<?php echo apply_filters('the_content', $ashraful_oli_meta_service['description']); ?>
					</div>
				</div>
			</div>
			<?php endforeach; ?>
		</div>
	</div>
<?php endif; ?>
