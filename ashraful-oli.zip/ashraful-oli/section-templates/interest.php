<?php

global $ashraful_oli_section_id;

$ashraful_oli_section = get_post($ashraful_oli_section_id);

$ashraful_oli_section_title = $ashraful_oli_section->post_title; // select post title

$ashraful_oli_meta_section_type = get_post_meta($ashraful_oli_section_id,'ashraful_oli_section_type', true);
$ashraful_oli_meta_interesting = get_post_meta($ashraful_oli_section_id,'ashraful_oli_interest', true);


?>

<?php if ('interest' == $ashraful_oli_meta_section_type): ?>
	<h2 class="section-title"><?php echo esc_html($ashraful_oli_section_title); ?></h2>

	<div class="section-wrapper section-interest" id="<?php echo get_post_field('post_name', $ashraful_oli_section_id); ?>">
		<div class="row no-gutters interest-tab-wrapper">
			<div class="col-xl-12">
				<ul class="nav" id="interestTab" role="tablist">
					<?php
					if (!empty($ashraful_oli_meta_interesting)):
						foreach ($ashraful_oli_meta_interesting as $ashraful_oli_meta_interest_key => $ashraful_oli_meta_interest_value):
							if (0 == $ashraful_oli_meta_interest_key) {
								$active = 'active';
								$open = 'true';
							} else {
								$active = '';
								$open = 'false';
							}
							?>

							<li class="col">
								<a class="<?php echo esc_attr($active); ?>" id="tab-0" data-toggle="tab"
								   href="#tabs-<?php echo esc_attr($ashraful_oli_meta_interest_key); ?>" role="tab"
								   aria-controls="tab-<?php echo esc_attr($ashraful_oli_meta_interest_key); ?>"
								   aria-selected="<?php echo esc_attr($open); ?>">
									<i class="<?php echo esc_attr($ashraful_oli_meta_interest_value['icon']) ?>"></i>
								</a>
							</li>
						<?php
						endforeach;
					endif;
					?>
				</ul>
			</div>
			<div class="col-xl-12">
				<div class="tab-content" id="interestTabContent">
					<?php
					if (!empty($ashraful_oli_meta_interesting)):
						foreach ($ashraful_oli_meta_interesting as $ashraful_oli_meta_interest_key => $ashraful_oli_meta_interest_value):
							if (0 == $ashraful_oli_meta_interest_key){
								$active = 'active';
								$open = 'show';
							}else{
								$active = '';
								$open = '';
							}
							?>
							<div class="tab-pane fade <?php echo esc_attr($active) .' '. esc_attr($open); ?>" id="tabs-<?php echo esc_attr($ashraful_oli_meta_interest_key); ?>" role="tabpanel" aria-labelledby="tab-<?php echo esc_attr($ashraful_oli_meta_interest_key); ?>">
								<?php echo apply_filters('the_content', $ashraful_oli_meta_interest_value['content']); ?>
							</div>
						<?php
						endforeach;
					endif;
					?>
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>
