<?php

global $ashraful_oli_section_id;

$ashraful_oli_section = get_post($ashraful_oli_section_id);

$ashraful_oli_section_title = $ashraful_oli_section->post_title; // select post title

$ashraful_oli_meta_section_type = get_post_meta($ashraful_oli_section_id,'ashraful_oli_section_type', true);
$ashraful_oli_meta_experiences = get_post_meta($ashraful_oli_section_id,'ashraful_oli_experience', true);

?>

<?php if ('experience' == $ashraful_oli_meta_section_type): ?>
	<h2 class="section-title"><?php echo esc_html($ashraful_oli_section_title); ?></h2>

	<div class="timeline-wrapper" id="<?php echo get_post_field('post_name', $ashraful_oli_section_id); ?>">
		<div class="row">
			<div class="col-xl-12">
				<ul class="experience-timeline">
				<?php
				if (!empty($ashraful_oli_meta_experiences)):
					foreach ($ashraful_oli_meta_experiences as $ashraful_oli_meta_experience):
						?>
						<li class="experience-wrapper">
							<div class="timeline-marker"></div>

							<?php if (!empty($ashraful_oli_meta_experience['designation']) || !empty($ashraful_oli_meta_experience['company'])): ?>
							<div class="heading">

								<?php if (!empty($ashraful_oli_meta_experience['designation'])): ?>
								<h4><?php echo esc_html($ashraful_oli_meta_experience['designation']); ?></h4>
								<?php endif; ?>

								<?php if (!empty($ashraful_oli_meta_experience['designation']) && !empty($ashraful_oli_meta_experience['company'])): ?>
								<span class="separator-date">-</span>
								<?php endif; ?>

								<?php if (!empty($ashraful_oli_meta_experience['company'])): ?>
								<h4><?php echo esc_html($ashraful_oli_meta_experience['company']); ?></h4>
								<?php endif; ?>

							</div>
							<?php endif; ?>

							<?php if (!empty($ashraful_oli_meta_experience['join_date']) || !empty($ashraful_oli_meta_experience['end_date'])): ?>
							<div class="date-area">
								<?php if (!empty($ashraful_oli_meta_experience['join_date'])): ?>
								<time datetime="<?php echo esc_attr($ashraful_oli_meta_experience['join_date']); ?>">
									<?php echo esc_html($ashraful_oli_meta_experience['join_date']); ?>
								</time>
								<?php endif; ?>

								<?php if (!empty($ashraful_oli_meta_experience['join_date']) && !empty($ashraful_oli_meta_experience['end_date'])): ?>
									<span class="separator-date">-</span>
								<?php endif; ?>

								<?php if (!empty($ashraful_oli_meta_experience['end_date'])): ?>
								<time datetime="<?php echo esc_attr($ashraful_oli_meta_experience['end_date']); ?>">
									<?php echo esc_html($ashraful_oli_meta_experience['end_date']); ?>
								</time>
								<?php endif; ?>
							</div>
							<?php endif; ?>

							<div class="description">
								<?php echo apply_filters('the_content', $ashraful_oli_meta_experience['job_description']); ?>
							</div>
						</li>
					<?php
					endforeach;
				endif;
				?>
				</ul>
			</div>
		</div>
	</div>
<?php endif; ?>
