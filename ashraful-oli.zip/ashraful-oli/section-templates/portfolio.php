<?php

global $ashraful_oli_section_id;

$ashraful_oli_section = get_post($ashraful_oli_section_id);

$ashraful_oli_section_title = $ashraful_oli_section->post_title; // select post title

$ashraful_oli_meta_section_type = get_post_meta($ashraful_oli_section_id,'ashraful_oli_section_type', true);
$ashraful_oli_meta_portfolio_items = get_post_meta($ashraful_oli_section_id,'ashraful_oli_portfolio_items', true);

?>

<?php if ('portfolio' == $ashraful_oli_meta_section_type): ?>
	<h2 class="section-title"><?php echo esc_html($ashraful_oli_section_title); ?></h2>

	<div class="section-wrapper" id="<?php echo get_post_field('post_name', $ashraful_oli_section_id); ?>">
		<div class="row">
			<div class="col-xl-12">

				<?php

				// get portfolio cat
				$ashraful_oli_categories = get_terms('portfolio_cat');

				?>

				<div class="row">
					<div class="col-lg-12 text-center">
						<div class="portfolio-menu">
							<button data-filter="*" class="active">All</button>
							<?php
								if (!empty($ashraful_oli_categories) && ! is_wp_error( $ashraful_oli_categories )){
									foreach ($ashraful_oli_categories as $category){
										echo '<button data-filter=".'.esc_attr($category->slug).'">'.esc_html($category->name).'</button>';
									}
								}
							?>
						</div>
					</div>
				</div>

				<div class="row portfolio-active">
					<?php
					$args = array(
						'post_type' => 'portfolio',
						'posts_per_page' => $ashraful_oli_meta_portfolio_items,
					);
					$portfolio = new WP_Query( $args );

					?>
					<?php while ( $portfolio->have_posts() ) : $portfolio->the_post();

						// get meta link
						$ashraful_oli_portfolio_link = get_post_meta(get_the_ID() , 'ashraful_oli_portfolio_link' , true);

						// category portfolio

						$portfolio_categories = get_the_terms(get_the_ID(), 'portfolio_cat'); // get portfolio cat list

						if (!empty($portfolio_categories) && ! is_wp_error( $portfolio_categories )){

							$portfolio_category_list = array(); // assign portfolio cat
							$portfolio_category_link = array(); // assign portfolio cat


							foreach ($portfolio_categories as $category){
								$portfolio_category_list[] = $category->slug;

								$portfolio_category_link[] = '<li><a href="'.get_term_link($category->slug, 'portfolio_cat').'">'.$category->name.'</a></li>';

							}

							$portfolio_assigned_cat = join( " ", $portfolio_category_list );

							$portfolio_display_cat = join( "<span>,</span>", $portfolio_category_link );

						}else{
							$portfolio_assigned_cat = ''; // fix error
							$portfolio_display_cat = ''; // fix error
						}
						?>

						<div class="col-lg-6 col-md-6 grid-item <?php echo $portfolio_assigned_cat; ?>">
							<div class="portfolio-single">
								<div class="portfolio-thumb">
									<img src="<?php echo get_the_post_thumbnail_url(get_the_ID(), 'portfolio-thumbnail') ?>"
									     alt="<?php echo get_the_title(); ?>" class="img-fluid">
									<div class="portfolio-hover text-center">
										<div class="intro">
											<div class="table-row">
												<div class="table-cell">
													<ul class="category">
														<?php echo wp_kses_post($portfolio_display_cat); ?>
													</ul>
													<h3>
														<a href="<?php echo get_the_permalink(); ?>"><?php echo get_the_title(); ?></a>
													</h3>
													<div class="action-btn">
														<a href="<?php echo esc_url($ashraful_oli_portfolio_link); ?>">
															<i class="fa fa-plus"></i>
														</a>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					<?php endwhile; wp_reset_postdata(); ?>

				</div>

			</div>
		</div>
	</div>
<?php endif; ?>
