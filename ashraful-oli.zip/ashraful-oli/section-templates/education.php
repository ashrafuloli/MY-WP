<?php

global $ashraful_oli_section_id;

$ashraful_oli_section = get_post($ashraful_oli_section_id);

$ashraful_oli_section_title = $ashraful_oli_section->post_title; // select post title

$ashraful_oli_meta_section_type = get_post_meta($ashraful_oli_section_id,'ashraful_oli_section_type', true);
$ashraful_oli_meta_educations = get_post_meta($ashraful_oli_section_id,'ashraful_oli_education', true);

?>

<?php if ('education' == $ashraful_oli_meta_section_type): ?>
	<h2 class="section-title"><?php echo esc_html($ashraful_oli_section_title); ?></h2>

	<div class="timeline-wrapper education-timeline" id="<?php echo get_post_field('post_name', $ashraful_oli_section_id); ?>">
		<div class="row">
			<div class="col-xl-12">
				<ul class="experience-timeline">
					<?php
					if (!empty($ashraful_oli_meta_educations)):
						foreach ($ashraful_oli_meta_educations as $ashraful_oli_meta_education):
							?>
							<li class="education-wrapper">
								<div class="timeline-marker"></div>
								<?php if (!empty($ashraful_oli_meta_education['join_date']) || !empty($ashraful_oli_meta_education['end_date'])): ?>
								<div class="date-area">
									<time datetime="<?php echo esc_attr($ashraful_oli_meta_education['join_date']); ?>">
										<?php echo esc_html($ashraful_oli_meta_education['join_date']); ?>
									</time>
									<span class="separator-date">-</span>
									<time datetime="<?php echo esc_attr($ashraful_oli_meta_education['end_date']); ?>">
										<?php echo esc_html($ashraful_oli_meta_education['end_date']); ?>
									</time>
								</div>
								<?php endif; ?>

								<?php if (!empty($ashraful_oli_meta_education['istitute']) || !empty($ashraful_oli_meta_education['degree'])): ?>
									<div class="heading">
										<h4><?php echo esc_html($ashraful_oli_meta_education['istitute']); ?></h4>
										<h5><?php echo esc_html($ashraful_oli_meta_education['degree']); ?></h5>
									</div>
								<?php endif; ?>

								<?php if (!empty($ashraful_oli_meta_education['education_description'])): ?>
								<div class="description">
									<?php echo apply_filters('the_content', $ashraful_oli_meta_education['education_description']); ?>
								</div>
								<?php endif; ?>

							</li>
						<?php
						endforeach;
					endif;
					?>
				</ul>
			</div>
		</div>
	</div>
<?php endif; ?>
