<?php

global $ashraful_oli_section_id;

$ashraful_oli_section = get_post($ashraful_oli_section_id);

$ashraful_oli_section_title = $ashraful_oli_section->post_title; // select post title

$ashraful_oli_meta_section_type = get_post_meta($ashraful_oli_section_id,'ashraful_oli_section_type', true);
$ashraful_oli_meta_bio_slogan = get_post_meta($ashraful_oli_section_id,'ashraful_oli_bio_slogan', true);
$ashraful_oli_meta_author_name = get_post_meta($ashraful_oli_section_id,'ashraful_oli_bio_author_name', true);
$ashraful_oli_meta_author_designation = get_post_meta($ashraful_oli_section_id,'ashraful_oli_bio_author_designation', true);
$ashraful_oli_meta_author_description = get_post_meta($ashraful_oli_section_id,'ashraful_oli_bio_author_description', true);
$ashraful_oli_meta_author_image_id = get_post_meta($ashraful_oli_section_id,'ashraful_oli_bio_author_image_id', true);
$ashraful_oli_meta_author_download_link = get_post_meta($ashraful_oli_section_id,'ashraful_oli_bio_author_download_link', true);
$ashraful_oli_meta_author_download_text = get_post_meta($ashraful_oli_section_id,'ashraful_oli_bio_author_download_text', true);

$ashraful_oli_meta_author_image =  wp_get_attachment_image_src( $ashraful_oli_meta_author_image_id ,'large' );

$ashraful_oli_bio_col = !empty($ashraful_oli_meta_author_image) ? $width = 'col-xl-7' : $width = 'col-xl-12' ;

?>

<?php if ('bio' == $ashraful_oli_meta_section_type): ?>
<div class="section-wrapper section-bio" id="<?php echo get_post_field('post_name', $ashraful_oli_section_id); ?>">
	<div class="row">
		<?php if(!empty($ashraful_oli_meta_author_image)): ?>
		<div class="col-xl-5">
			<div class="bio-thumbnail">
				<img src="<?php echo esc_url($ashraful_oli_meta_author_image[0]); ?>" alt="<?php echo esc_attr($ashraful_oli_section_title); ?>" class="img-fluid">
			</div>
		</div>
		<?php endif; ?>
		<div class="<?php echo esc_attr($ashraful_oli_bio_col); ?>">
			<div class="bio-text">
				<?php if(
						!empty($ashraful_oli_meta_bio_slogan) ||
						!empty($ashraful_oli_meta_author_name) ||
						!empty($ashraful_oli_meta_author_designation)
				): ?>
					<div class="entry-heading">

						<?php if(!empty($ashraful_oli_meta_bio_slogan)): ?>
						<h2 class="slogan"><?php echo esc_html($ashraful_oli_meta_bio_slogan); ?></h2>
						<?php endif; ?>

						<?php if(!empty($ashraful_oli_meta_author_name)): ?>
						<h2 class="title"><?php echo esc_html($ashraful_oli_meta_author_name); ?></h2>
						<?php endif; ?>

						<?php if(!empty($ashraful_oli_meta_author_designation)): ?>
						<h4 class="designation"><?php echo esc_html($ashraful_oli_meta_author_designation); ?></h4>
						<?php endif; ?>

					</div>
				<?php endif; ?>

				<?php if( !empty($ashraful_oli_meta_author_description) || !empty($ashraful_oli_meta_author_download_link) ): ?>
					<div class="entry-content">

						<?php echo apply_filters('the_content', $ashraful_oli_meta_author_description); ?>

						<?php if( !empty($ashraful_oli_meta_author_download_text) ): ?>
						<a href="<?php echo esc_url($ashraful_oli_meta_author_download_link); ?>" class="btn btn-primary"><?php echo esc_html($ashraful_oli_meta_author_download_text); ?></a>
						<?php endif; ?>

					</div>
				<?php endif; ?>
			</div>
		</div>
	</div>
</div>
<?php endif; ?>
