<?php

global $ashraful_oli_section_id;

$ashraful_oli_section = get_post($ashraful_oli_section_id);

$ashraful_oli_section_title = $ashraful_oli_section->post_title; // select post title

$ashraful_oli_meta_section_type = get_post_meta($ashraful_oli_section_id,'ashraful_oli_section_type', true);
$ashraful_oli_meta_pricing_list = get_post_meta($ashraful_oli_section_id,'ashraful_oli_pricing', true);


?>

<?php if ('pricing' == $ashraful_oli_meta_section_type): ?>
	<h2 class="section-title"><?php echo esc_html($ashraful_oli_section_title); ?></h2>

	<div class=" section-pricing" id="<?php echo get_post_field('post_name', $ashraful_oli_section_id); ?>">
		<div class="row no-gutters">
			<?php
			if (!empty($ashraful_oli_meta_pricing_list)):
				foreach ($ashraful_oli_meta_pricing_list as $ashraful_oli_meta_pricing):
					?>
					<div class="col-xl-4">
						<div class="pricing-wrapper">
							<div class="pricing-head">
								<h2 class="card-price">$<?php echo esc_html($ashraful_oli_meta_pricing['price_money']); ?></h2>
								<h6 class="card-title"><?php echo esc_html($ashraful_oli_meta_pricing['title']); ?></h6>
							</div>
							<ul class="pricing-body">
								<?php
									$ashraful_oli_meta_pricing_list_contents = $ashraful_oli_meta_pricing['list'];
									foreach ( $ashraful_oli_meta_pricing_list_contents as $ashraful_oli_meta_pricing_list_content){
										echo '<li>' . $ashraful_oli_meta_pricing_list_content . '</li>';
									}
								?>
							</ul>
							<div class="pricing-footer">
								<a href="<?php echo esc_html($ashraful_oli_meta_pricing['button_link']); ?>"
								   class="btn btn-primary"><?php echo esc_html($ashraful_oli_meta_pricing['button_text']); ?></a>
							</div>
						</div>
					</div>
				<?php
				endforeach;
			endif;
			?>
		</div>
	</div>
<?php endif; ?>
