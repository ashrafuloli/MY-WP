<?php

global $ashraful_oli_section_id;

$ashraful_oli_section = get_post($ashraful_oli_section_id);

$ashraful_oli_section_title = $ashraful_oli_section->post_title; // select post title

$ashraful_oli_meta_section_type = get_post_meta($ashraful_oli_section_id,'ashraful_oli_section_type', true);

$ashraful_oli_meta_contact_form = get_post_meta($ashraful_oli_section_id,'ashraful_oli_contact', true);
$ashraful_oli_meta_contact_description = get_post_meta($ashraful_oli_section_id,'ashraful_oli_contact_description', true);
$ashraful_oli_meta_contact_address = get_post_meta($ashraful_oli_section_id,'ashraful_oli_contact_address', true);
$ashraful_oli_meta_contact_email = get_post_meta($ashraful_oli_section_id,'ashraful_oli_contact_email', true);
$ashraful_oli_meta_contact_phone = get_post_meta($ashraful_oli_section_id,'ashraful_oli_contact_phone', true);

?>

<?php if ('contact' == $ashraful_oli_meta_section_type): ?>

	<h2 class="section-title"><?php echo esc_html($ashraful_oli_section_title); ?></h2>

	<div class="section-wrapper" id="<?php echo get_post_field('post_name', $ashraful_oli_section_id); ?>">
		<div class="row">
			<div class="col-xl-6">
				<div class="contact-form-wrapper">
					<?php echo do_shortcode($ashraful_oli_meta_contact_form); ?>
				</div>
			</div>
			<div class="col-xl-6">
				<div class="contact-info-wrapper">
					<div class="contact-content">
						<?php echo apply_filters('the_content', $ashraful_oli_meta_contact_description); ?>
					</div>
					<ul class="info">
						<li>
							<i class="fa fa-map-marker"></i>
							<h6><?php _e('ADDRESS', 'ashraful-oli') ?></h6>
							<p><?php echo esc_html($ashraful_oli_meta_contact_address); ?></p>
						</li>
						<li>
							<i class="fa fa-envelope"></i>
							<h6><?php _e('Email', 'ashraful-oli') ?></h6>
							<p><?php echo esc_html($ashraful_oli_meta_contact_email); ?></p>
						</li>
						<li>
							<i class="fa fa-phone"></i>
							<h6><?php _e('Phone', 'ashraful-oli') ?></h6>
							<p><?php echo esc_html($ashraful_oli_meta_contact_phone); ?></p>
						</li>
					</ul>
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>
