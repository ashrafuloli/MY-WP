<?php

global $ashraful_oli_section_id;

$ashraful_oli_section = get_post($ashraful_oli_section_id);

$ashraful_oli_section_title = $ashraful_oli_section->post_title; // select post title

$ashraful_oli_meta_section_type = get_post_meta($ashraful_oli_section_id,'ashraful_oli_section_type', true);

$ashraful_oli_meta_testimonials = get_post_meta($ashraful_oli_section_id,'ashraful_oli_testimonial', true);

?>

<?php if ('testimonial' == $ashraful_oli_meta_section_type): ?>

	<h2 class="section-title"><?php echo esc_html($ashraful_oli_section_title); ?></h2>

	<div class="section-testimonial" id="<?php echo get_post_field('post_name', $ashraful_oli_section_id); ?>">
		<div class="row">
			<div class="col-xl-12">
				<div class="testimonial-slider owl-carousel">
					<?php
					if (!empty($ashraful_oli_meta_testimonials)):
						foreach ($ashraful_oli_meta_testimonials as $ashraful_oli_meta_testimonial):
							$ashraful_oli_meta_testimonial_image_id = $ashraful_oli_meta_testimonial['image_id'];
							$ashraful_oli_meta_testimonial_image =  wp_get_attachment_image_src( $ashraful_oli_meta_testimonial_image_id ,'testimonial-thumbnail' );
							?>
							<div class="single-testimonial">
								<div class="author-area">
									<div class="author-img">
										<img src="<?php echo esc_url($ashraful_oli_meta_testimonial_image[0]); ?>" alt="<?php echo esc_attr($ashraful_oli_section_title); ?>" class="img-fluid">
									</div>
									<div class="author-title">
										<h3><?php echo esc_html($ashraful_oli_meta_testimonial['name'])?></h3>
										<p><?php echo esc_html($ashraful_oli_meta_testimonial['designation'])?></p>
										<div class="rating">
											<?php
											$x = 1;
											$count = esc_html($ashraful_oli_meta_testimonial['rating']);
											while ( $x <= $count) {
												echo '<i class="fa fa-star"></i>';
												$x++;
											}
											?>
										</div>
									</div>
								</div>
								<div class="author-content">
									<?php echo apply_filters('the_content', $ashraful_oli_meta_testimonial['description']); ?>
								</div>
							</div>
						<?php
						endforeach;
					endif;
					?>
				</div>
			</div>
		</div>
	</div>
<?php endif; ?>
