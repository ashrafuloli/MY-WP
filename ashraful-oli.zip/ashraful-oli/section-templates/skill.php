<?php

global $ashraful_oli_section_id;

$ashraful_oli_section = get_post($ashraful_oli_section_id);

$ashraful_oli_section_title = $ashraful_oli_section->post_title; // select post title

$ashraful_oli_meta_section_type = get_post_meta($ashraful_oli_section_id,'ashraful_oli_section_type', true);
$ashraful_oli_meta_skill_bars = get_post_meta($ashraful_oli_section_id,'ashraful_oli_skill_bar', true);

?>

<?php if ('skill' == $ashraful_oli_meta_section_type): ?>
<h2 class="section-title"><?php echo esc_html($ashraful_oli_section_title); ?></h2>

<div class="section-wrapper" id="<?php echo get_post_field('post_name', $ashraful_oli_section_id); ?>">
	<div class="row">
		<div class="col-xl-12">
			<?php
			if (!empty($ashraful_oli_meta_skill_bars)):
				foreach ($ashraful_oli_meta_skill_bars as $ashraful_oli_meta_skill_bar):
					?>
					<div class="progress-wrapper">

						<?php if (!empty($ashraful_oli_meta_skill_bar['title'])): ?>
							<div class="progress-title">
								<h5><?php echo esc_html($ashraful_oli_meta_skill_bar['title']); ?></h5>
							</div>
						<?php endif; ?>

						<?php if (!empty($ashraful_oli_meta_skill_bar['point'])): ?>
							<div class="progress">
								<div class="progress-bar progress-bar-striped progress-bar-animated" role="progressbar"
								     style="width: <?php echo esc_attr($ashraful_oli_meta_skill_bar['point']); ?>%; background-color: <?php echo esc_attr($ashraful_oli_meta_skill_bar['color']); ?>;"
								     aria-valuenow="<?php echo esc_attr($ashraful_oli_meta_skill_bar['point']); ?>"
								     aria-valuemin="0"
								     aria-valuemax="100">
									<span style="color: <?php echo esc_attr($ashraful_oli_meta_skill_bar['color']); ?>;"><?php echo esc_html($ashraful_oli_meta_skill_bar['point']); ?></span>
								</div>
							</div>
						<?php endif; ?>

					</div>
				<?php
				endforeach;
			endif;
			?>
		</div>
	</div>
</div>
<?php endif; ?>