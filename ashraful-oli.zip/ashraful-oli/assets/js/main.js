;(function ($) {
	'use strict';

	jQuery(document).ready(function () {
		/* ======= Back to Top ======= */
		(function () {
			$('#toTop').on('click', function () {
				$("html, body").animate({scrollTop: 0}, 600);
				return false;
			});

			var sidebar = new StickySidebar('.sticky-sidebar', {
				containerSelector: '.sticky-main',
				topSpacing: 20,
				resizeSensor: true,
			});

			/* === OnePageNav filter === */
			$('#primary-menu').onePageNav();

			/* === Portfolio filter === */
			if ($('.portfolio-active').length > 0) {
				// init Isotope
				var $grid = $('.portfolio-active').isotope({
					itemSelector: '.grid-item',
					percentPosition: true,
					masonry: {
						// use outer width of grid-sizer for columnWidth
						columnWidth: '.grid-item'
					}
				});
				// isotop active
				$('.portfolio-menu').on('click', 'button', function () {
					var filterValue = $(this).attr('data-filter');
					$grid.isotope({ filter: filterValue });
				});
				//for menu active class
				$('.portfolio-menu').on('click', 'button', function (event) {
					$(this).siblings('.active').removeClass('active');
					$(this).addClass('active');
					event.preventDefault();
				});
			}

			if ( $('.testimonial-slider').length > 0) {
				$(".testimonial-slider").owlCarousel({
					items:2,
					margin:30,
					nav:true,
					navText:['<i class="fa fa-angle-left"></i>', '<i class="fa fa-angle-right"></i>']
				});
			}


		}());

	});

})(jQuery);