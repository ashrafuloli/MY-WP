<?php

/**
 * Section Bio
 */

function ashraful_oli_sections_skill_metabox() {

	$section_id = null;

	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$section_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	if ( 'section' != get_post_type( $section_id ) ) {
		return false;
	}

	$section_meta = get_post_meta( $section_id, 'ashraful_oli_section_type', true );
	$section_type = $section_meta;

	if ( 'skill' != $section_type ) {
		return false;
	}

	$prefix = 'ashraful_oli_';

	$cmb_sections = new_cmb2_box( array(
		'id'               => $prefix . 'skill',
		'title'            => __( 'Skill Sections', 'ashraful-oli' ),
		'object_types'     => array( 'section' ),
	) );

	$group_field_id = $cmb_sections->add_field( array(
		'id'          => $prefix . 'skill_bar',
		'type'        => 'group',
		'description' => __( 'Add Skills', 'ashraful-oli' ),
		'options'     => array(
			'group_title'       => __( 'Skill {#}', 'ashraful-oli' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'        => __( 'Add Another Skill', 'ashraful-oli' ),
			'remove_button'     => __( 'Remove Skill', 'ashraful-oli' ),
			'sortable'          => true,
			 'closed'         => true, // true to have the groups closed by default
			 'remove_confirm' => esc_html__( 'Are you sure you want to remove?', 'ashraful-oli' ), // Performs confirmation before removing group.
		),
	) );

	$cmb_sections->add_group_field(  $group_field_id, array(
		'name'              => __( 'Skill Name', 'ashraful-oli' ),
		'id'                => 'title',
		'type'              => 'text',
	) );

	$cmb_sections->add_group_field(  $group_field_id, array(
		'name'              => __( 'Skill Points', 'ashraful-oli' ),
		'desc'              => __( 'input max value 1 to 100', 'ashraful-oli' ),
		'id'                => 'point',
		'type'              => 'text',
	) );

	$cmb_sections->add_group_field(  $group_field_id, array(
		'name'              => __( 'Skill Bar Color', 'ashraful-oli' ),
		'id'                => 'color',
		'type'              => 'colorpicker',
		'options' => array(
			'alpha' => true,
		),
	) );


}

add_action( 'cmb2_admin_init', 'ashraful_oli_sections_skill_metabox' );
