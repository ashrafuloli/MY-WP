<?php

/**
 * Section Bio
 */

function ashraful_oli_sections_contact_metabox() {

	$section_id = null;

	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$section_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	if ( 'section' != get_post_type( $section_id ) ) {
		return false;
	}

	$section_meta = get_post_meta( $section_id, 'ashraful_oli_section_type', true );

	$section_type = $section_meta;

	if ( 'contact' != $section_type ) {
		return false;
	}

	$prefix = 'ashraful_oli_';

	$cmb_sections = new_cmb2_box( array(
		'id'               => $prefix . 'contacts',
		'title'            => __( 'Interest Sections', 'ashraful-oli' ),
		'object_types'     => array( 'section' ),
	) );

	$cmb_sections->add_field( array(
		'name'              => __( 'Contact Us', 'ashraful-oli' ),
		'desc'              => __( 'Input contact us shortcode', 'ashraful-oli' ),
		'id'                => $prefix . 'contact',
		'type'              => 'text',
	) );

	$cmb_sections->add_field( array(
		'name'              => __( 'Address', 'ashraful-oli' ),
		'desc'              => __( 'Input your address', 'ashraful-oli' ),
		'id'                => $prefix . 'contact_address',
		'type'              => 'text',
	) );

	$cmb_sections->add_field( array(
		'name'              => __( 'Email', 'ashraful-oli' ),
		'desc'              => __( 'Input your email', 'ashraful-oli' ),
		'id'                => $prefix . 'contact_email',
		'type'              => 'text_email',
	) );

	$cmb_sections->add_field( array(
		'name'              => __( 'Phone', 'ashraful-oli' ),
		'desc'              => __( 'Input your phone', 'ashraful-oli' ),
		'id'                => $prefix . 'contact_phone',
		'type'              => 'text',
	) );

	$cmb_sections->add_field( array(
		'name'              => __( 'Address Description', 'ashraful-oli' ),
		'desc'              => __( 'type your address description', 'ashraful-oli' ),
		'id'                => $prefix . 'contact_description',
		'type'              => 'textarea_small',
	) );


}

add_action( 'cmb2_admin_init', 'ashraful_oli_sections_contact_metabox' );
