<?php

/**
 * Section Bio
 */

function ashraful_oli_sections_testimonial_metabox() {

	$section_id = null;

	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$section_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	if ( 'section' != get_post_type( $section_id ) ) {
		return false;
	}

	$section_meta = get_post_meta( $section_id, 'ashraful_oli_section_type', true );
	$section_type = $section_meta;

	if ( 'testimonial' != $section_type ) {
		return false;
	}

	$prefix = 'ashraful_oli_';

	$cmb_sections = new_cmb2_box( array(
		'id'               => $prefix . 'testimonials',
		'title'            => __( 'Experience Sections', 'ashraful-oli' ),
		'object_types'     => array( 'section' ),
	) );

	$group_field_id = $cmb_sections->add_field( array(
		'id'          => $prefix . 'testimonial',
		'type'        => 'group',
		'description' => __( 'Add Testimonial', 'ashraful-oli' ),
		'options'     => array(
			'group_title'       => __( 'Testimonial {#}', 'ashraful-oli' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'        => __( 'Add Another Testimonial', 'ashraful-oli' ),
			'remove_button'     => __( 'Remove Testimonial', 'ashraful-oli' ),
			'sortable'          => true,
			'closed'         => true, // true to have the groups closed by default
			'remove_confirm' => esc_html__( 'Are you sure you want to remove?', 'ashraful-oli' ), // Performs confirmation before removing group.
		),
	) );

	$cmb_sections->add_group_field( $group_field_id, array(
		'name'              => __( 'Author Image', 'ashraful-oli' ),
		'desc'              => __( 'Select author image.', 'ashraful-oli' ),
		'id'                => 'image',
		'type'              => 'file',
		'options' => array(
			'url' => true,
		),
		'text'    => array(
			'add_upload_file_text' => 'Add Image'
		),
		'query_args' => array(
			'type' => array(
				'image/gif',
				'image/jpeg',
				'image/png',
			),
		),
		'preview_size' => 'thumbnail',
	) );

	$cmb_sections->add_group_field( $group_field_id, array(
		'name'              => __( 'Author Name', 'ashraful-oli' ),
		'desc'              => __( 'Type author name.', 'ashraful-oli' ),
		'id'                => 'name',
		'type'              => 'text',
	) );

	$cmb_sections->add_group_field( $group_field_id, array(
		'name'              => __( 'Author Designation', 'ashraful-oli' ),
		'desc'              => __( 'Type author designation.', 'ashraful-oli' ),
		'id'                => 'designation',
		'type'              => 'text',
	) );

	$cmb_sections->add_group_field( $group_field_id, array(
		'name'              => __( 'Rating Works', 'ashraful-oli' ),
		'desc'              => __( 'select start of rating.', 'ashraful-oli' ),
		'id'                => 'rating',
		'type'              => 'text',
		'type'             => 'select',
		'show_option_none' => true,
		'options'          => array(
			'1'       => __( 'One Start', 'ashraful-oli' ),
			'2'       => __( 'Two Start', 'ashraful-oli' ),
			'3'       => __( 'Three Start', 'ashraful-oli' ),
			'4'       => __( 'Four Start', 'ashraful-oli' ),
			'5'       => __( 'Five Start', 'ashraful-oli' ),
		),
	) );

	$cmb_sections->add_group_field( $group_field_id, array(
		'name'              => __( 'Testimonial Description', 'ashraful-oli' ),
		'desc'              => __( 'Type testimonial description.', 'ashraful-oli' ),
		'id'                => 'description',
		'type'              => 'textarea_small',
	) );


}

add_action( 'cmb2_admin_init', 'ashraful_oli_sections_testimonial_metabox' );
