<?php

/**
 * Section Bio
 */

function ashraful_oli_sections_blog_metabox() {

	$section_id = null;

	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$section_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	if ( 'section' != get_post_type( $section_id ) ) {
		return false;
	}

	$section_meta = get_post_meta( $section_id, 'ashraful_oli_section_type', true );

	$section_type = $section_meta;

	if ( 'blog' != $section_type ) {
		return false;
	}

	$prefix = 'ashraful_oli_';

	$cmb_sections = new_cmb2_box( array(
		'id'               => $prefix . 'blogs',
		'title'            => __( 'Blog Sections', 'ashraful-oli' ),
		'object_types'     => array( 'section' ),
	) );

	$cmb_sections->add_field( array(
		'name'             => esc_html__( 'Blog Shows', 'ashraful-oli' ),
		'desc'             => esc_html__( 'Select Blog Items.', 'ashraful-oli' ),
		'id'               => $prefix . 'blog_items',
		'type'             => 'select',
		'show_option_none' => true,
		'options'          => array(
			'2'       => __( '2 Items', 'ashraful-oli' ),
			'4'       => __( '4 Items', 'ashraful-oli' ),
			'6'       => __( '6 Items', 'ashraful-oli' ),
			'8'       => __( '8 Items', 'ashraful-oli' ),
			'10'       => __( '10 Items', 'ashraful-oli' ),
		),
	) );

}

add_action( 'cmb2_admin_init', 'ashraful_oli_sections_blog_metabox' );
