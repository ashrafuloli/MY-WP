<?php

/**
 * Sections Custom Post type
 */

function ashraful_oli_portfolio_metabox() {
	$prefix = 'ashraful_oli_';

	$cmb_portfolio = new_cmb2_box( array(
		'id'               => $prefix . 'portfolio',
		'title'            => esc_html__( 'Portfolio Link', 'ashraful-oli' ),
		'object_types'     => array( 'portfolio' ),
	) );

	$cmb_portfolio->add_field( array(
		'name'              => __( 'Portfolio Url', 'ashraful-oli' ),
		'desc'              => __( 'Input your portfolio url.', 'ashraful-oli' ),
		'id'                => $prefix . 'portfolio_link',
		'type'              => 'text_url',
		'attributes' => array(
			'placeholder'  => 'http://',
		)
	) );

}

add_action( 'cmb2_admin_init', 'ashraful_oli_portfolio_metabox' );
