<?php

/**
 * Sections Custom Post type
 */

function ashraful_oli_sections_page_metabox() {

	$page_id = 0;
	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$page_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	$current_page_template = get_post_meta( $page_id, '_wp_page_template', true );
	if ( ! in_array( $current_page_template, array( 'page-templates/landing.php' ) ) ) {
		return false;
	}

	$prefix = 'ashraful_oli_';


	/**
	 * Initiate the metabox
	 */
	$cmb_section = new_cmb2_box( array(
		'id'            => $prefix. 'section_fields',
		'title'            => esc_html__( 'All Sections', 'ashraful-oli' ),
		'object_types'  => array( 'page', ), // Post type
		'context'       => 'normal',
		'priority'      => 'high',
		'show_names'    => true, // Show field names on the left
	) );

	if( class_exists('WDS_CMB2_Attached_Posts_Field_127') ){
		$cmb_section->add_field( array(
			'name'    => __( 'Add Sections', 'ashraful-oli' ),
			'before'    => __( 'Drag section from the left column to the right column to attach them to this page.<br />You may rearrange the order of the posts in the right column by dragging and dropping.', 'ashraful-oli' ),
			'id'      => $prefix. 'section',
			'type'    => 'custom_attached_posts',
			'column'  => true,
			'options' => array(
				'show_thumbnails' => true,
				'filter_boxes'    => true,
				'query_args'      => array(
					'posts_per_page' => -1,
					'post_type'      => 'section',
				),
			),
		) );
	}else{
		$cmb_section->add_field( array(
			'name'              => __( 'Service Attached Posts', 'ashraful-oli' ),
			'desc'              => __( 'Install <a href="https://github.com/CMB2/cmb2-attached-posts" target="_blank">CMB2 Attached Posts</a>', 'ashraful-oli' ),
			'id'                =>  'install_plugin',
			'type'              => 'title',
		) );
	}





}

add_action( 'cmb2_admin_init', 'ashraful_oli_sections_page_metabox' );