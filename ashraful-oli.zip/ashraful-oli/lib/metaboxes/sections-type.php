<?php

/**
 * Sections Custom Post type
 */

function ashraful_oli_sections_metabox() {
	$prefix = 'ashraful_oli_';

	$cmb_sections = new_cmb2_box( array(
		'id'               => $prefix . 'sections',
		'title'            => esc_html__( 'Type Of Sections', 'ashraful-oli' ),
		'object_types'     => array( 'section' ),
	) );

	$cmb_sections->add_field( array(
		'name'             => esc_html__( 'Select Type', 'ashraful-oli' ),
		'desc'             => esc_html__( 'Select landing Page Sections.', 'ashraful-oli' ),
		'id'               => $prefix . 'section_type',
		'type'             => 'select',
		'show_option_none' => true,
		'options'          => array(
			'bio'       => __( 'My Bio', 'ashraful-oli' ),
			'skill'     => __( 'Work Skill', 'ashraful-oli' ),
			'experience'     => __( 'Work Experience', 'ashraful-oli' ),
			'education'     => __( 'My Education', 'ashraful-oli' ),
			'portfolio'     => __( 'Portfolio', 'ashraful-oli' ),
			'testimonial'     => __( 'Testimonials', 'ashraful-oli' ),
			'service'     => __( 'My Service', 'ashraful-oli' ),
			'blog'     => __( 'Blog', 'ashraful-oli' ),
			'pricing'     => __( 'Pricing', 'ashraful-oli' ),
			'interest'     => __( 'My Interest', 'ashraful-oli' ),
			'contact'     => __( 'Contact Us', 'ashraful-oli' ),
		),
	) );

}

add_action( 'cmb2_admin_init', 'ashraful_oli_sections_metabox' );
