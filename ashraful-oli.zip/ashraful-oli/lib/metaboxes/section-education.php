<?php

/**
 * Section Bio
 */

function ashraful_oli_sections_education_metabox() {

	$section_id = null;

	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$section_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	if ( 'section' != get_post_type( $section_id ) ) {
		return false;
	}

	$section_meta = get_post_meta( $section_id, 'ashraful_oli_section_type', true );
	$section_type = $section_meta;

	if ( 'education' != $section_type ) {
		return false;
	}

	$prefix = 'ashraful_oli_';

	$cmb_sections = new_cmb2_box( array(
		'id'               => $prefix . 'educations',
		'title'            => __( 'Experience Sections', 'ashraful-oli' ),
		'object_types'     => array( 'section' ),
	) );

	$group_field_id = $cmb_sections->add_field( array(
		'id'          => $prefix . 'education',
		'type'        => 'group',
		'description' => __( 'Add Education', 'ashraful-oli' ),
		'options'     => array(
			'group_title'       => __( 'Education {#}', 'ashraful-oli' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'        => __( 'Add Another Education', 'ashraful-oli' ),
			'remove_button'     => __( 'Remove Education', 'ashraful-oli' ),
			'sortable'          => true,
			'closed'         => true, // true to have the groups closed by default
			'remove_confirm' => esc_html__( 'Are you sure you want to remove?', 'ashraful-oli' ), // Performs confirmation before removing group.
		),
	) );

	$cmb_sections->add_group_field(  $group_field_id, array(
		'name'              => __( 'Institute Name', 'ashraful-oli' ),
		'desc'              => __( 'Type school, college or university name', 'ashraful-oli' ),
		'id'                => 'istitute',
		'type'              => 'text',
	) );

	$cmb_sections->add_group_field(  $group_field_id, array(
		'name'              => __( 'Degree Subject & GPA', 'ashraful-oli' ),
		'desc'              => __( 'Type your Degree , Subject - GPA ', 'ashraful-oli' ),
		'id'                => 'degree',
		'type'              => 'text',
	) );

	$cmb_sections->add_group_field(  $group_field_id, array(
		'name'              => __( 'Start Date', 'ashraful-oli' ),
		'desc'              => __( 'starting year', 'ashraful-oli' ),
		'id'                => 'join_date',
		'type'              => 'text_date',
		'date_format'       => 'Y',
	) );

	$cmb_sections->add_group_field(  $group_field_id, array(
		'name'              => __( 'End Date', 'ashraful-oli' ),
		'desc'              => __( 'Running year !', 'ashraful-oli' ),
		'id'                => 'end_date',
		'type'              => 'text_date',
		'date_format'       => 'Y',
	) );

	$cmb_sections->add_group_field(  $group_field_id, array(
		'name'              => __( 'Education Description', 'ashraful-oli' ),
		'id'                => 'education_description',
		'type'              => 'wysiwyg',
		'options'           => array(
			'wpautop' => true, // use wpautop?
			'media_buttons' => false, // show insert/upload button(s)
			'textarea_rows' => '10', // rows="..."
			'tabindex' => '',
			'editor_css' => '', // intended for extra styles for both visual and HTML editors buttons, needs to include the `<style>` tags, can use "scoped".
			'editor_class' => 'my-new-class', // add extra class(es) to the editor textarea
			'teeny' => false, // output the minimal editor config used in Press This
			'dfw' => false, // replace the default fullscreen with DFW (needs specific css)
			'tinymce' => true, // load TinyMCE, can be used to pass settings directly to TinyMCE using an array()
			'quicktags' => true // load Quicktags, can be used to pass settings directly to Quicktags using an array()
		),
	) );


}

add_action( 'cmb2_admin_init', 'ashraful_oli_sections_education_metabox' );
