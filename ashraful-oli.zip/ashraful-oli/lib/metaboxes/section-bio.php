<?php

/**
 * Section Bio
 */

function ashraful_oli_sections_bio_metabox() {

	$section_id = null;

	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$section_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	if ( 'section' != get_post_type( $section_id ) ) {
		return false;
	}

	$section_meta = get_post_meta( $section_id, 'ashraful_oli_section_type', true );

	$section_type = $section_meta;

	if ( 'bio' != $section_type ) {
		return false;
	}

	$prefix = 'ashraful_oli_';

	$cmb_sections = new_cmb2_box( array(
		'id'               => $prefix . 'bios',
		'title'            => __( 'Bio Sections', 'ashraful-oli' ),
		'object_types'     => array( 'section' ),
	) );

	$cmb_sections->add_field( array(
		'name'              => __( 'Slogan', 'ashraful-oli' ),
		'id'                => $prefix . 'bio_slogan',
		'type'              => 'text',
		'attributes' => array(
			'placeholder'  => 'Hello',
		)
	) );

	$cmb_sections->add_field( array(
		'name'              => __( 'Author Name', 'ashraful-oli' ),
		'desc'              => __( 'Type author name.', 'ashraful-oli' ),
		'id'                => $prefix . 'bio_author_name',
		'type'              => 'text',
		'attributes' => array(
			'placeholder'  => 'I’m ',
		)
	) );

	$cmb_sections->add_field( array(
		'name'              => __( 'Author Designation', 'ashraful-oli' ),
		'desc'              => __( 'Type author Designation.', 'ashraful-oli' ),
		'id'                => $prefix . 'bio_author_designation',
		'type'              => 'text',
		'attributes' => array(
			'placeholder'  => 'Web Developer',
		)
	) );

	$cmb_sections->add_field( array(
		'name'              => __( 'Author Description', 'ashraful-oli' ),
		'desc'              => __( 'Type author description.', 'ashraful-oli' ),
		'id'                => $prefix . 'bio_author_description',
		'type'              => 'textarea_small',
		'attributes' => array(
			'placeholder'  => 'Professional UI/UX designer and web developer based on London.',
		)
	) );

	$cmb_sections->add_field( array(
		'name'              => __( 'Author Image', 'ashraful-oli' ),
		'desc'              => __( 'Select author image.', 'ashraful-oli' ),
		'id'                => $prefix . 'bio_author_image',
		'type'              => 'file',
		'options' => array(
			'url' => true,
		),
		'text'    => array(
			'add_upload_file_text' => 'Add Image'
		),
		'query_args' => array(
			 'type' => array(
			     'image/gif',
			     'image/jpeg',
			     'image/jpg',
			     'image/png',
			 ),
		),
		'preview_size' => 'thumbnail',
	) );

	$cmb_sections->add_field( array(
		'name'              => __( 'Download Button Text', 'ashraful-oli' ),
		'desc'              => __( 'Change button text.', 'ashraful-oli' ),
		'id'                => $prefix . 'bio_author_download_text',
		'type'              => 'text',
		'attributes' => array(
			'placeholder'  => 'Download CV',
		)
	) );

	$cmb_sections->add_field( array(
		'name'              => __( 'Download Button Url', 'ashraful-oli' ),
		'desc'              => __( 'Change button url.', 'ashraful-oli' ),
		'id'                => $prefix . 'bio_author_download_link',
		'type'              => 'text_url',
		'attributes' => array(
			'placeholder'  => 'http://',
		)
	) );


}

add_action( 'cmb2_admin_init', 'ashraful_oli_sections_bio_metabox' );
