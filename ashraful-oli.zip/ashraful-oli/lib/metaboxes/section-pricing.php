<?php

/**
 * Section Bio
 */

function ashraful_oli_sections_pricing_metabox() {

	$section_id = null;

	if ( isset( $_REQUEST['post'] ) || isset( $_REQUEST['post_ID'] ) ) {
		$section_id = empty( $_REQUEST['post_ID'] ) ? $_REQUEST['post'] : $_REQUEST['post_ID'];
	}

	if ( 'section' != get_post_type( $section_id ) ) {
		return false;
	}

	$section_meta = get_post_meta( $section_id, 'ashraful_oli_section_type', true );
	$section_type = $section_meta;

	if ( 'pricing' != $section_type ) {
		return false;
	}

	$prefix = 'ashraful_oli_';

	$cmb_sections = new_cmb2_box( array(
		'id'               => $prefix . 'price',
		'title'            => __( 'Pricing Sections', 'ashraful-oli' ),
		'object_types'     => array( 'section' ),
	) );

	$group_field_id = $cmb_sections->add_field( array(
		'id'          => $prefix . 'pricing',
		'type'        => 'group',
		'description' => __( 'Add Pricing', 'ashraful-oli' ),
		'options'     => array(
			'group_title'       => __( 'Pricing {#}', 'ashraful-oli' ), // since version 1.1.4, {#} gets replaced by row number
			'add_button'        => __( 'Add Another Pricing', 'ashraful-oli' ),
			'remove_button'     => __( 'Remove Pricing', 'ashraful-oli' ),
			'sortable'          => true,
			'closed'         => true, // true to have the groups closed by default
			'remove_confirm' => esc_html__( 'Are you sure you want to remove?', 'ashraful-oli' ), // Performs confirmation before removing group.
		),
	) );

	$cmb_sections->add_group_field( $group_field_id, array(
		'name'              => __( 'Price Money', 'ashraful-oli' ),
		'desc'              => __( 'Type Price Money.', 'ashraful-oli' ),
		'id'                => 'price_money',
		'type'              => 'text',
		'before_field'      => '$',
	) );

	$cmb_sections->add_group_field( $group_field_id, array(
		'name'              => __( 'Price Title', 'ashraful-oli' ),
		'desc'              => __( 'Type price table title.', 'ashraful-oli' ),
		'id'                => 'title',
		'type'              => 'text',
	) );

	$cmb_sections->add_group_field( $group_field_id, array(
		'name'              => __( 'Add list', 'ashraful-oli' ),
		'desc'              => __( 'Add price list content.', 'ashraful-oli' ),
		'id'                => 'list',
		'type'              => 'text',
		'repeatable' => true,
	) );

	$cmb_sections->add_group_field( $group_field_id, array(
		'name'              => __( 'Button Text', 'ashraful-oli' ),
		'desc'              => __( 'Change button text.', 'ashraful-oli' ),
		'id'                => 'button_text',
		'type'              => 'text',
		'default'           => 'BUY NOW',
	) );

	$cmb_sections->add_group_field( $group_field_id, array(
		'name'              => __( 'Button Url', 'ashraful-oli' ),
		'desc'              => __( 'Change button url.', 'ashraful-oli' ),
		'id'                => 'button_link',
		'type'              => 'text_url',
		'attributes' => array(
			'placeholder'  => 'http://',
		)
	) );


}

add_action( 'cmb2_admin_init', 'ashraful_oli_sections_pricing_metabox' );
