<?php
// Control core classes for avoid errors
if ( class_exists( 'CSF' ) ) {

	// Set a unique slug-like ID
	$prefix = 'rrf_commerce';

	// Create options
	CSF::createOptions( $prefix, array(
		'menu_title' => 'Theme Options',
		'menu_slug'  => 'theme-options',
		'theme'  => 'light',
		'framework_title'  => 'RRF COMMERCE',
	) );

	// Header Settings
	CSF::createSection( $prefix, array(
		'title'  => 'Header Settings',
		'icon'   => 'fa fa-window-maximize',
		'fields' => array(

			// Header Social Visibility
			array(
				'id'         => 'header-logo',
				'type'       => 'switcher',
				'title'      => __( 'Header Logo', 'rrf-commerce' ),
				'subtitle'   => __( 'Visible or Hidden header Logo', 'rrf-commerce' ),
				'text_on'    => __( 'Visible', 'rrf-commerce' ),
				'text_off'   => __( 'Hidden', 'rrf-commerce' ),
				'default'    => false,
				'text_width' => 100,
			),

			// Header Social Visibility
			array(
				'id'         => 'header-search',
				'type'       => 'switcher',
				'title'      => __( 'Header Search', 'rrf-commerce' ),
				'subtitle'   => __( 'Visible or Hidden header search bar', 'rrf-commerce' ),
				'text_on'    => __( 'Visible', 'rrf-commerce' ),
				'text_off'   => __( 'Hidden', 'rrf-commerce' ),
				'default'    => false,
				'text_width' => 100,
			),

		)
	) );

	// Typography Settings
	CSF::createSection( $prefix, array(
		'title'  => 'Typography Settings',
		'icon'   => 'fa fa-font',
		'fields' => array(

			// Body Typography
			array(
				'id'             => 'body-typography',
				'type'           => 'typography',
				'title'          => __( 'Body Font', 'rrf-commerce' ),
				'subtitle'       => __( 'Specify the body font properties.', 'rrf-commerce' ),
				'subset'         => false,
				'text_align'     => false,
				'letter_spacing' => false,
				'text_transform' => false,
				'default'        => array(
					'color'       => '#999',
					'font-family' => 'Open Sans',
					'font-size'   => '16',
					'line-height' => '20',
					'unit'        => 'px',
					'type'        => 'google',
				),
			),

			// Heading Typography
			array(
				'id'             => 'heading-typography',
				'type'           => 'typography',
				'title'          => __( 'Heading Font', 'rrf-commerce' ),
				'subtitle'       => __( 'This settings for all heading font (h1, h2, h3, h4, h5, h6)', 'rrf-commerce' ),
				'subset'         => false,
				'font_size'      => false,
				'line_height'    => false,
				'text_align'     => false,
				'letter_spacing' => false,
				'text_transform' => false,
				'default'        => array(
					'color'       => '#000000',
					'font-family' => 'Raleway',
					'font-weight' => '700',
					'unit'        => 'px',
					'type'        => 'google',
				),
			),

			// H1 Typography
			array(
				'id'             => 'h1-typography',
				'type'           => 'typography',
				'title'          => __( 'H1 (Heading one)', 'rrf-commerce' ),
				'subtitle'       => __( 'This settings only for H1', 'rrf-commerce' ),
				'color'          => false,
				'font_family'    => false,
				'subset'         => false,
				'text_align'     => false,
				'text_transform' => false,
				'letter_spacing' => false,
				'default'        => array(
					'line-height' => '40',
					'font-size'   => '40',
					'unit'        => 'px',
				),
			),

			// H2 Typography
			array(
				'id'             => 'h2-typography',
				'type'           => 'typography',
				'title'          => __( 'H2 (Heading one)', 'rrf-commerce' ),
				'subtitle'       => __( 'This settings only for H1', 'rrf-commerce' ),
				'color'          => false,
				'font_family'    => false,
				'subset'         => false,
				'text_align'     => false,
				'text_transform' => false,
				'letter_spacing' => false,
				'default'        => array(
					'font-size'   => '20',
					'line-height' => '26',
					'unit'        => 'px',
				),
			),

			// H3 Typography
			array(
				'id'             => 'h3-typography',
				'type'           => 'typography',
				'title'          => __( 'H3 (Heading one)', 'rrf-commerce' ),
				'subtitle'       => __( 'This settings only for H1', 'rrf-commerce' ),
				'color'          => false,
				'font_family'    => false,
				'subset'         => false,
				'text_align'     => false,
				'text_transform' => false,
				'letter_spacing' => false,
				'default'        => array(
					'font-size'   => '18',
					'line-height' => '20',
					'unit'        => 'px',
				),
			),

			// H4 Typography
			array(
				'id'             => 'h4-typography',
				'type'           => 'typography',
				'title'          => __( 'H4 (Heading one)', 'rrf-commerce' ),
				'subtitle'       => __( 'This settings only for H1', 'rrf-commerce' ),
				'color'          => false,
				'font_family'    => false,
				'subset'         => false,
				'text_align'     => false,
				'text_transform' => false,
				'letter_spacing' => false,
				'default'        => array(
					'font-size'   => '16',
					'line-height' => '18',
					'unit'        => 'px',
				),
			),

			// H5 Typography
			array(
				'id'             => 'h5-typography',
				'type'           => 'typography',
				'title'          => __( 'H5 (Heading one)', 'rrf-commerce' ),
				'subtitle'       => __( 'This settings only for H1', 'rrf-commerce' ),
				'color'          => false,
				'font_family'    => false,
				'subset'         => false,
				'text_align'     => false,
				'text_transform' => false,
				'letter_spacing' => false,
				'default'        => array(
					'font-size'   => '14',
					'line-height' => '16',
					'unit'        => 'px',
				),
			),

			// H6 Typography
			array(
				'id'             => 'h6-typography',
				'type'           => 'typography',
				'title'          => __( 'H6 (Heading one)', 'rrf-commerce' ),
				'subtitle'       => __( 'This settings only for H1', 'rrf-commerce' ),
				'color'          => false,
				'font_family'    => false,
				'subset'         => false,
				'text_align'     => false,
				'text_transform' => false,
				'letter_spacing' => false,
				'default'        => array(
					'font-size'   => '12',
					'line-height' => '14',
					'unit'        => 'px',
				),
			),


		)
	) );

	// Blog Settings
	CSF::createSection( $prefix, array(
		'title'  => 'Blog Settings',
		'icon'   => 'fa fa-file-word-o',
		'fields' => array(

			// Post Meta
			array(
				'id'        => 'post-meta',
				'type'      => 'checkbox',
				'title'      => __( 'Post Meta Setting', 'rrf-commerce' ),
				'subtitle'      => __( 'Check to show post meta', 'rrf-commerce' ),
				'options'    => array(
					'post-date' => __( 'Post Date', 'rrf-commerce' ),
					'post-author' => __( 'Post Author', 'rrf-commerce' ),
					'post-category' => __( 'Post Category', 'rrf-commerce' ),
					'post-comment' => __( 'Post Comment', 'rrf-commerce' ),
				),
				'default'   => array( 'post-date', 'post-author', 'post-category', 'post-comment' )
			),

			// Share Button Visibility
			array(
				'id'         => 'share-button-visibility',
				'type'       => 'switcher',
				'title'      => __( 'Share Button Visibility', 'rrf-commerce' ),
				'subtitle'   => __( 'Show or Hidden share button in post', 'rrf-commerce' ),
				'text_on'    => __( 'Show', 'rrf-commerce' ),
				'text_off'   => __( 'Hidden', 'rrf-commerce' ),
				'default'    => true,
				'text_width' => 100,
			),

			// Share Button
			array(
				'id'       => 'share-button',
				'type'     => 'checkbox',
				'title'    => __( 'Post Share Button', 'rrf-commerce' ),
				'subtitle' => __( 'Check to show share button', 'rrf-commerce' ),
				'options'  => array(
					'facebook' => __( 'Facebook', 'rrf-commerce' ),
					'twitter'  => __( 'Twitter', 'rrf-commerce' ),
					'google'   => __( 'Google+', 'rrf-commerce' ),
					'linkedin' => __( 'Linkedin', 'rrf-commerce' ),
				),
				'default'  => array( 'facebook', 'twitter', 'google', 'linkedin' ),
				'dependency' => array( 'share-button-visibility', '==', 'true' ),
			),

			// Pagination or Navigation
			array(
				'id'         => 'blog-pagination',
				'type'       => 'radio',
				'title'      => __( 'Blog Pagination or Navigation', 'rrf-commerce' ),
				'subtitle'   => __( 'Blog pagination style, posts pagination or newer / older posts', 'rrf-commerce' ),
				'options'    => array(
					'pagination' => __( 'Pagination', 'rrf-commerce' ),
					'navigation' => __( 'Navigation', 'rrf-commerce' ),
				),
				'default'    => 'pagination'
			),

		)
	) );

	// Preloader Settings
	CSF::createSection( $prefix, array(
		'title'  => 'Preloader Settings',
		'icon'   => 'fa fa-repeat',
		'fields' => array(

			// Preloader Visibility
			array(
				'id'         => 'preloader-visibility',
				'type'       => 'switcher',
				'title'      => __( 'Page Preloader', 'rrf-commerce' ),
				'subtitle'   => __( 'You can enable or disable page preloader from here.', 'rrf-commerce' ),
				'text_on'    => __( 'Enable', 'rrf-commerce' ),
				'text_off'   => __( 'Disable', 'rrf-commerce' ),
				'default'    => true,
				'text_width' => 100,
			),

			// Preloader Background
			array(
				'id'         => 'preloader-background',
				'type'       => 'color',
				'title'      => __( 'Preloader Background Color', 'rrf-commerce' ),
				'subtitle'   => __( 'Pick color for preloader background (default: #ffffff).', 'rrf-commerce' ),
				'default'    => '#ffffff',
				'dependency' => array( 'preloader-visibility', '==', 'true' ),
			),

			// Preloader Animation
			array(
				'id'         => 'preloader-animation',
				'type'       => 'upload',
				'title'      => __( 'Animation file', 'rrf-commerce' ),
				'subtitle'   => __( 'Upload loader gif animation file', 'rrf-commerce' ),
				'dependency' => array( 'preloader-visibility', '==', 'true' ),
			),

		)
	) );

	// 404 Page
	CSF::createSection( $prefix, array(
		'title'  => '404 Page',
		'icon'   => 'fa fa-inbox',
		'fields' => array(

			// 404 text
			array(
				'id'         => 'error-text',
				'type'       => 'text',
				'title'      => __( '404 Text', 'rrf-commerce' ),
				'desc'   => __( 'Change 404 text', 'rrf-commerce' ),
				'default'    => '404',
			),

			// 404 SubText
			array(
				'id'         => 'error-sub-text',
				'type'       => 'text',
				'title'      => __( '404 Subtext', 'rrf-commerce' ),
				'desc'   => __( 'Change 404 subtext', 'rrf-commerce' ),
				'default'    => 'OOPS! PAGE NOT FOUND',
			),

			// 404 Description
			array(
				'id'         => 'error-desc',
				'type'       => 'textarea',
				'title'      => __( '404 Description', 'rrf-commerce' ),
				'desc'   => __( 'Change 404 description', 'rrf-commerce' ),
				'default'    => 'Sorry, we couldn\'t find the content you were looking for.',
			),

			// Button Text
			array(
				'id'         => 'error-btn',
				'type'       => 'text',
				'title'      => __( 'Button Text', 'rrf-commerce' ),
				'desc'   => __( 'Change button text, leave blank to hide button', 'rrf-commerce' ),
				'default'    => 'Go Back Home',
			),

		)
	) );

	// Social Icon
	CSF::createSection( $prefix, array(
		'title'  => 'Social Icon',
		'icon'   => 'fa fa-share-alt-square',
		'fields' => array(

			// Facebook
			array(
				'id'         => 'social-facebook',
				'type'       => 'text',
				'title'      => __( 'Facebook Link', 'rrf-commerce' ),
				'subtitle'   => __( 'Enter facebook page or profile link. Leave blank to hide icon.', 'rrf-commerce' ),
				'default'    => '#',
			),

			// Twitter
			array(
				'id'         => 'social-twitter',
				'type'       => 'text',
				'title'      => __( 'Twitter Link', 'rrf-commerce' ),
				'subtitle'   => __( 'Enter twitter page or profile link. Leave blank to hide icon.', 'rrf-commerce' ),
				'default'    => '#',
			),

			// Google Plus
			array(
				'id'         => 'social-google-plus',
				'type'       => 'text',
				'title'      => __( 'Google Plus Link', 'rrf-commerce' ),
				'subtitle'   => __( 'Enter google plus page or profile link. Leave blank to hide icon.', 'rrf-commerce' ),
				'default'    => '#',
			),

			// Youtube
			array(
				'id'         => 'social-youtube',
				'type'       => 'text',
				'title'      => __( 'Youtube Link', 'rrf-commerce' ),
				'subtitle'   => __( 'Enter Youtube page or profile link. Leave blank to hide icon.', 'rrf-commerce' ),
				'default'    => '#',
			),

			// Linkedin
			array(
				'id'         => 'social-linkedin',
				'type'       => 'text',
				'title'      => __( 'Linkedin Link', 'rrf-commerce' ),
				'subtitle'   => __( 'Enter Linkedin page or profile link. Leave blank to hide icon.', 'rrf-commerce' ),
			),

			// Flickr
			array(
				'id'         => 'social-flickr',
				'type'       => 'text',
				'title'      => __( 'Flickr Link', 'rrf-commerce' ),
				'subtitle'   => __( 'Enter Flickr page or profile link. Leave blank to hide icon.', 'rrf-commerce' ),
			),

			// Pinterest
			array(
				'id'         => 'social-pinterest',
				'type'       => 'text',
				'title'      => __( 'Pinterest Link', 'rrf-commerce' ),
				'subtitle'   => __( 'Enter Pinterest page or profile link. Leave blank to hide icon.', 'rrf-commerce' ),
			),

			// Instagram
			array(
				'id'         => 'social-instagram',
				'type'       => 'text',
				'title'      => __( 'Instagram Link', 'rrf-commerce' ),
				'subtitle'   => __( 'Enter Instagram page or profile link. Leave blank to hide icon.', 'rrf-commerce' ),
			),

			// Vimeo
			array(
				'id'         => 'social-vimeo',
				'type'       => 'text',
				'title'      => __( 'Vimeo Link', 'rrf-commerce' ),
				'subtitle'   => __( 'Enter Vimeo page or profile link. Leave blank to hide icon.', 'rrf-commerce' ),
			),

			// Dribbble
			array(
				'id'         => 'social-dribbble',
				'type'       => 'text',
				'title'      => __( 'Dribbble Link', 'rrf-commerce' ),
				'subtitle'   => __( 'Enter Dribbble page or profile link. Leave blank to hide icon.', 'rrf-commerce' ),
			),

			// Behance
			array(
				'id'         => 'social-behance',
				'type'       => 'text',
				'title'      => __( 'Behance Link', 'rrf-commerce' ),
				'subtitle'   => __( 'Enter Behance page or profile link. Leave blank to hide icon.', 'rrf-commerce' ),
			),


		)
	) );

	// Footer  Settings
	CSF::createSection( $prefix, array(
		'title'  => 'Footer Settings',
		'icon'   => 'fa fa-cube',
		'fields' => array(

			// Footer Social Visibility
			array(
				'id'         => 'back-to-top',
				'type'       => 'switcher',
				'title'      => __( 'Back-to-top button', 'rrf-commerce' ),
				'subtitle'   => __( 'Show or hide social icon from footer', 'rrf-commerce' ),
				'text_on'    => __( 'Show', 'rrf-commerce' ),
				'text_off'   => __( 'Hide', 'rrf-commerce' ),
				'default'    => true,
				'text_width' => 100,
			),

			// Footer Copyright
			array(
				'id'    => 'footer-copyright',
				'type'  => 'wp_editor',
				'title'      => __( 'Footer Copyright Text', 'rrf-commerce' ),
				'subtitle'   => __( 'Write footer copyright text here.', 'rrf-commerce' ),
				'default'    => '<div class="copyright">Copyright © 2019 | RRF Commerce Theme by <a href="http://ashrafuloli.com">AshrafulOli</a> | Powered by <a href="https://wordpress.org">WordPress</a></div>',
			),

		)
	) );

	// Backup  Settings
	CSF::createSection( $prefix, array(
		'title'  => 'Backup Settings',
		'icon'   => 'fa fa-shield',
		'fields' => array(

			// Backup
			array(
				'type' => 'backup',
			),

		)
	) );


}