<?php if(is_admin()) {
		
		include('includes/slider-revolution-auto-importer-admin.php');
	}
	define('RS_ZIP_FOLDER_PATH', plugin_dir_path(__FILE__));